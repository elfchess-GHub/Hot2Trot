@echo off
cd /d "%~dp0.."
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" shape_azoid.py
) else (
  python shape_azoid.py
)
pause
