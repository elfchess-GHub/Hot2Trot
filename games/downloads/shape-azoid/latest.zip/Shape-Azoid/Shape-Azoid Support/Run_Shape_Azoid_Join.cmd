@echo off
setlocal
cd /d "%~dp0"
set "SUPPORT_DIR=%~dp0Shape-Azoid Support"
if not exist "%SUPPORT_DIR%" set "SUPPORT_DIR=%~dp0"
if not exist "%SUPPORT_DIR%\.venv\Scripts\python.exe" (
  call "%~dp0Install_Shape_Azoid_Requirements.cmd"
  if errorlevel 1 exit /b 1
)
"%SUPPORT_DIR%\.venv\Scripts\python.exe" "%SUPPORT_DIR%\tools\run_shape_azoid_online_play.py" --mode join
