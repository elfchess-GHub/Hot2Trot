try:
    import asyncio
    from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
    from pydantic import BaseModel
except ImportError as exc:
    raise RuntimeError(
        "Shape-Azoid network server needs fastapi and pydantic. "
        "Install project requirements before starting the server."
    ) from exc

from .shape_azoid_room_service import ShapeAzoidRoomService


APP_TITLE = "Shape-Azoid Network Prototype"
APP_VERSION = "0.1"
WEBSOCKET_STREAM_INTERVAL = 1.0 / 30.0


class CreateRoomRequest(BaseModel):
    host_name: str | None = "Host"
    player_count: int | None = 2
    ai_players: list[int] | None = None
    start: bool = True


class JoinRoomRequest(BaseModel):
    player_name: str | None = None
    is_ai: bool = False
    seat_token: str | None = None


class UpdateSeatRequest(BaseModel):
    seat_token: str
    player_name: str | None = None
    color_index: int | None = None


class StartRoomRequest(BaseModel):
    seat_token: str


class CommandRequest(BaseModel):
    seat_token: str
    command: dict


service = ShapeAzoidRoomService()
app = FastAPI(title=APP_TITLE, version=APP_VERSION)


@app.on_event("startup")
def api_start_background_ticks() -> None:
    service.start_background_ticks()


@app.on_event("shutdown")
def api_stop_background_ticks() -> None:
    service.stop_background_ticks()


@app.get("/api/health")
def api_health() -> dict:
    return {"ok": True, "title": APP_TITLE, "version": APP_VERSION}


@app.get("/api/version")
def api_version() -> dict:
    return {"ok": True, "title": APP_TITLE, "version": APP_VERSION}


@app.post("/api/rooms")
def api_create_room(payload: CreateRoomRequest) -> dict:
    with service.lock:
        return service.create_room(
            host_name=payload.host_name or "Host",
            player_count=payload.player_count or 2,
            ai_players=payload.ai_players or [],
            start=payload.start,
        )


@app.get("/api/rooms")
def api_list_rooms(include_closed: bool = False) -> dict:
    with service.lock:
        return service.list_rooms(include_closed=include_closed)


@app.get("/api/rooms/{room_code}")
def api_room_snapshot(room_code: str, seat_token: str | None = None) -> dict:
    try:
        with service.lock:
            return service.snapshot(room_code, seat_token=seat_token)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.websocket("/ws/rooms/{room_code}")
async def ws_room_stream(websocket: WebSocket, room_code: str, seat_token: str | None = None) -> None:
    await websocket.accept()
    try:
        while True:
            try:
                with service.lock:
                    payload = service.stream_snapshot(room_code, seat_token=seat_token)
            except KeyError as exc:
                await websocket.send_json({"type": "error", "error": str(exc)})
                await websocket.close(code=1008)
                return
            payload["type"] = "room_snapshot"
            await websocket.send_json(payload)
            await asyncio.sleep(WEBSOCKET_STREAM_INTERVAL)
    except WebSocketDisconnect:
        return


@app.post("/api/rooms/{room_code}/join")
def api_join_room(room_code: str, payload: JoinRoomRequest) -> dict:
    try:
        with service.lock:
            result = service.join_room(
                room_code,
                player_name=payload.player_name,
                is_ai=payload.is_ai,
                seat_token=payload.seat_token,
            )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    if not result.get("ok"):
        raise HTTPException(status_code=400, detail=result.get("error", "Join failed."))
    return result


@app.post("/api/rooms/{room_code}/seat")
def api_update_seat(room_code: str, payload: UpdateSeatRequest) -> dict:
    try:
        with service.lock:
            result = service.update_seat(
                room_code,
                payload.seat_token,
                player_name=payload.player_name,
                color_index=payload.color_index,
            )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    if not result.get("ok"):
        raise HTTPException(status_code=400, detail=result.get("error", "Seat update failed."))
    return result


@app.post("/api/rooms/{room_code}/start")
def api_start_room(room_code: str, payload: StartRoomRequest) -> dict:
    try:
        with service.lock:
            result = service.start_room(room_code, payload.seat_token)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    if not result.get("ok"):
        message = result.get("error", "Start failed.")
        status_code = 403 if "host" in message.lower() else 400
        raise HTTPException(status_code=status_code, detail=message)
    return result


@app.post("/api/rooms/{room_code}/commands")
def api_apply_command(room_code: str, payload: CommandRequest) -> dict:
    try:
        with service.lock:
            result = service.apply_command(room_code, payload.seat_token, payload.command)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    if not result.get("ok"):
        message = result.get("error", "Command failed.")
        status_code = 403 if "token" in message.lower() or "turn" in message.lower() else 400
        raise HTTPException(status_code=status_code, detail=result)
    return result


@app.post("/api/rooms/{room_code}/save")
def api_save_room(room_code: str) -> dict:
    try:
        with service.lock:
            path = service.save_room(room_code)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"ok": True, "room_code": room_code.upper(), "path": str(path)}


@app.post("/api/rooms/{room_code}/load")
def api_load_room(room_code: str) -> dict:
    try:
        with service.lock:
            return service.load_room(room_code)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
