import json
import urllib.error
import urllib.parse
import urllib.request


class ShapeAzoidHttpError(RuntimeError):
    def __init__(self, status, payload):
        self.status = status
        self.payload = payload
        super().__init__(f"HTTP {status}: {payload}")


class ShapeAzoidHttpClient:
    def __init__(self, base_url, timeout=5.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def request_json(self, method, path, payload=None, query=None):
        url = f"{self.base_url}{path}"
        if query:
            url = f"{url}?{urllib.parse.urlencode(query)}"
        headers = {}
        body = None
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(url, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                raw = response.read().decode("utf-8")
                return json.loads(raw) if raw else None
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode("utf-8")
            try:
                parsed = json.loads(raw) if raw else raw
            except json.JSONDecodeError:
                parsed = raw
            raise ShapeAzoidHttpError(exc.code, parsed) from exc
        except TimeoutError as exc:
            raise TimeoutError(f"Connection timed out while contacting {self.base_url}.") from exc
        except urllib.error.URLError as exc:
            reason = getattr(exc, "reason", exc)
            parsed = urllib.parse.urlparse(self.base_url)
            host = (parsed.hostname or "").lower()
            if isinstance(reason, ConnectionRefusedError):
                if host in {"127.0.0.1", "localhost"}:
                    raise ConnectionError(
                        f"No Shape-Azoid server is running on this computer at {self.base_url}. "
                        "To join another player's game, use the host's LAN address from their Online screen."
                    ) from exc
                raise ConnectionError(
                    f"No Shape-Azoid server answered at {self.base_url}. "
                    "The host must click Create and keep the host game open."
                ) from exc
            raise ConnectionError(f"Could not reach {self.base_url}: {reason}") from exc

    def health(self):
        return self.request_json("GET", "/api/health")

    def version(self):
        return self.request_json("GET", "/api/version")

    def create_room(self, host_name="Host", player_count=2, ai_players=None, start=True):
        return self.request_json(
            "POST",
            "/api/rooms",
            {
                "host_name": host_name,
                "player_count": player_count,
                "ai_players": ai_players or [],
                "start": start,
            },
        )

    def list_rooms(self, include_closed=False):
        query = {"include_closed": "true"} if include_closed else None
        return self.request_json("GET", "/api/rooms", query=query)

    def join_room(self, room_code, player_name=None, is_ai=False, seat_token=None):
        return self.request_json(
            "POST",
            f"/api/rooms/{room_code}/join",
            {"player_name": player_name, "is_ai": is_ai, "seat_token": seat_token},
        )

    def update_seat(self, room_code, seat_token, player_name=None, color_index=None):
        return self.request_json(
            "POST",
            f"/api/rooms/{room_code}/seat",
            {"seat_token": seat_token, "player_name": player_name, "color_index": color_index},
        )

    def start_room(self, room_code, seat_token):
        return self.request_json(
            "POST",
            f"/api/rooms/{room_code}/start",
            {"seat_token": seat_token},
        )

    def snapshot(self, room_code, seat_token=None):
        query = {"seat_token": seat_token} if seat_token else None
        return self.request_json("GET", f"/api/rooms/{room_code}", query=query)

    def apply_command(self, room_code, seat_token, command):
        return self.request_json(
            "POST",
            f"/api/rooms/{room_code}/commands",
            {"seat_token": seat_token, "command": command},
        )

    def save_room(self, room_code):
        return self.request_json("POST", f"/api/rooms/{room_code}/save")

    def load_room(self, room_code):
        return self.request_json("POST", f"/api/rooms/{room_code}/load")
