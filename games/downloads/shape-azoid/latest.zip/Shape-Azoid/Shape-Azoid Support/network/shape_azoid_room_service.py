import json
import os
import secrets
import threading
import time
from pathlib import Path

from shape_azoid_core import PLAYER_COLORS, ShapeAzoidMatch, VERSION


ROOM_CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
DEFAULT_SAVE_DIR = Path(os.environ.get("SHAPE_AZOID_ROOM_SAVE_DIR") or (Path(__file__).resolve().parents[1] / "data" / "network_rooms"))


def generate_room_code(existing_codes):
    for _ in range(32):
        code = "".join(secrets.choice(ROOM_CODE_ALPHABET) for _ in range(5))
        if code not in existing_codes:
            return code
    raise RuntimeError("Could not generate a unique room code.")


def public_token(token):
    return f"{token[:6]}..." if token else None


def unique_name(existing_names, requested):
    base = str(requested or "Player").strip() or "Player"
    normalized = {str(name or "").strip().casefold() for name in existing_names}
    if base.casefold() not in normalized:
        return base
    suffix = 2
    while f"{base} {suffix}".casefold() in normalized:
        suffix += 1
    return f"{base} {suffix}"


class ShapeAzoidRoomService:
    def __init__(self, save_dir=None):
        self.rooms = {}
        self.save_dir = Path(save_dir) if save_dir else DEFAULT_SAVE_DIR
        self.max_ai_ticks_per_request = 2
        self.background_tick_hz = 60
        self.ai_tick_delay = 0.85
        self.lock = threading.RLock()
        self._tick_stop = threading.Event()
        self._tick_thread = None

    def start_background_ticks(self):
        if self._tick_thread is not None and self._tick_thread.is_alive():
            return
        self._tick_stop.clear()
        self._tick_thread = threading.Thread(target=self._background_tick_loop, name="ShapeAzoidRoomTicks", daemon=True)
        self._tick_thread.start()

    def stop_background_ticks(self):
        self._tick_stop.set()
        if self._tick_thread is not None:
            self._tick_thread.join(timeout=2.0)
        self._tick_thread = None

    def _background_tick_loop(self):
        interval = 1.0 / max(1, int(self.background_tick_hz))
        while not self._tick_stop.is_set():
            started_at = time.monotonic()
            with self.lock:
                self.tick_all_rooms(max_steps=1, force=True)
            elapsed = time.monotonic() - started_at
            self._tick_stop.wait(max(0.001, interval - elapsed))

    def next_available_color_index(self, room, ignore_index=None):
        used = {
            int(seat.get("color_index"))
            for idx, seat in enumerate(room.get("seat_configs", []))
            if idx != ignore_index
            and isinstance(seat.get("color_index"), int)
            and 0 <= int(seat.get("color_index")) < len(PLAYER_COLORS)
        }
        for color_index in range(len(PLAYER_COLORS)):
            if color_index not in used:
                return color_index
        return len(room.get("seat_configs", [])) % len(PLAYER_COLORS)

    def create_room(self, host_name="Host", player_count=2, ai_players=None, start=True):
        requested_count = max(1, min(6, int(player_count or 2)))
        player_count = requested_count if start else 1
        ai_set = set(ai_players or [])
        code = generate_room_code(self.rooms.keys())
        seat_configs = [
            {"name": host_name or "Host", "is_ai": False, "color_index": 0},
            *[
                {"name": f"Player {idx + 1}", "is_ai": idx in ai_set, "color_index": idx % len(PLAYER_COLORS)}
                for idx in range(1, player_count)
            ],
        ]
        game = None
        if start:
            game = ShapeAzoidMatch(
                player_count=player_count,
                ai_players={idx for idx in ai_set if idx < player_count},
                seat_configs=seat_configs,
            )
        seat_tokens = [secrets.token_urlsafe(24) for _ in range(player_count)]
        room = {
            "room_code": code,
            "host_name": host_name or "Host",
            "phase": "playing" if start else "lobby",
            "game": game,
            "seat_tokens": seat_tokens,
            "seat_configs": seat_configs,
            "closed": False,
            "last_tick_at": time.monotonic(),
            "next_ai_tick_at": 0.0,
        }
        self.configure_lobby_game(room)
        if start:
            game.start()
        self.rooms[code] = room
        return {
            "room_code": code,
            "host_name": room["host_name"],
            "phase": room["phase"],
            "seats": self.room_seats(room),
            "host_seat_token": seat_tokens[0],
        }

    def configure_lobby_game(self, room):
        game = room["game"]
        if game is None:
            return
        game.player_count = len(room["seat_tokens"])
        game.ai_players = {
            idx for idx, seat in enumerate(room.get("seat_configs", []))
            if seat.get("is_ai")
        }
        game.configure_players(room.get("seat_configs", []))

    def room_seats(self, room):
        game = room["game"]
        seats = []
        if game is None:
            for idx, seat in enumerate(room.get("seat_configs", [])):
                color_index = int(seat.get("color_index", idx % len(PLAYER_COLORS)))
                color_name = PLAYER_COLORS[color_index][0] if 0 <= color_index < len(PLAYER_COLORS) else "Color"
                seats.append({
                    "index": idx,
                    "name": seat.get("name") or f"Player {idx + 1}",
                    "color_name": color_name,
                    "color_index": color_index,
                    "is_ai": bool(seat.get("is_ai")),
                    "seat_token_preview": public_token(room["seat_tokens"][idx]),
                })
            return seats
        for idx, player in enumerate(game.players):
            seats.append({
                "index": idx,
                "name": player["name"],
                "color_name": player["color_name"],
                "color_index": player["color_index"],
                "is_ai": idx in game.ai_players,
                "seat_token_preview": public_token(room["seat_tokens"][idx]),
            })
        return seats

    def room_for_code(self, room_code):
        code = str(room_code or "").strip().upper()
        room = self.rooms.get(code)
        if not room:
            raise KeyError("Room not found.")
        return room

    def room_summary(self, room):
        game = room["game"]
        seats = self.room_seats(room)
        return {
            "room_code": room["room_code"],
            "host_name": room["host_name"],
            "phase": room["phase"],
            "closed": bool(room["closed"]),
            "player_count": game.player_count if game is not None else len(seats),
            "seat_count": len(room["seat_tokens"]),
            "max_seats": 6,
            "current_player": game.current_player if game is not None and room["phase"] == "playing" else 0,
            "state_revision": game.state_revision if game is not None else 0,
            "seats": seats,
        }

    def list_rooms(self, include_closed=False):
        self.tick_all_rooms(max_steps=1)
        rooms = [
            self.room_summary(room)
            for room in self.rooms.values()
            if include_closed or not room["closed"]
        ]
        rooms.sort(key=lambda item: item["room_code"])
        return {"ok": True, "rooms": rooms}

    def tick_room(self, room, max_steps=None, force=False):
        if room["closed"] or room["phase"] != "playing":
            return
        game = room["game"]
        steps = self.max_ai_ticks_per_request if max_steps is None else int(max_steps)
        now = time.monotonic()
        last_tick_at = float(room.get("last_tick_at", now))
        if not force and now - last_tick_at < 0.08:
            return
        room["last_tick_at"] = now
        def zoid_motion_state():
            return tuple(
                (
                    z.get("kind"),
                    z.get("owner"),
                    z.get("piece"),
                    round(float(z.get("pos", [0, 0])[0]), 2),
                    round(float(z.get("pos", [0, 0])[1]), 2),
                )
                for z in game.zoids
            )
        def ufo_state():
            active = game.active_ufo or {}
            return (
                game.next_ufo_at,
                game.ufo_flight_index,
                active.get("target_idx"),
                active.get("hit_done"),
                len(game.explosions),
            )
        for _ in range(max(1, steps)):
            now = time.monotonic()
            actor = game.current_player
            ai_result = None
            before = (
                game.current_player,
                len(game.deck),
                sum(len(hand) for hand in game.hands if isinstance(hand, list)),
                len(game.discard),
                len(game.pieces),
                len(game.zoids),
                zoid_motion_state(),
                ufo_state(),
                game.mode,
            )
            game.update_zoids()
            game.update_ufo()
            if game.current_is_ai() and now >= float(room.get("next_ai_tick_at", 0.0)):
                ai_result = game.maybe_ai_turn()
                room["next_ai_tick_at"] = time.monotonic() + self.ai_tick_delay
            if game.mode == "score":
                break
            after = (
                game.current_player,
                len(game.deck),
                sum(len(hand) for hand in game.hands if isinstance(hand, list)),
                len(game.discard),
                len(game.pieces),
                len(game.zoids),
                zoid_motion_state(),
                ufo_state(),
                game.mode,
            )
            if after == before:
                break
            if ai_result is not None and actor in game.ai_players:
                game.record_action(actor, "ai_tick", {"current_player": game.current_player})
                break

    def tick_all_rooms(self, max_steps=None, force=False):
        for room in list(self.rooms.values()):
            self.tick_room(room, max_steps=max_steps, force=force)

    def player_index_for_token(self, room, seat_token):
        for idx, token in enumerate(room["seat_tokens"]):
            if token == seat_token:
                return idx
        return None

    def join_room(self, room_code, player_name=None, is_ai=False, seat_token=None):
        room = self.room_for_code(room_code)
        if room["closed"]:
            return {"ok": False, "error": "Room is closed."}
        if room["phase"] != "lobby":
            return {"ok": False, "error": "Room is not in lobby phase."}
        existing_idx = self.player_index_for_token(room, seat_token) if seat_token else None
        if existing_idx is not None:
            if player_name:
                other_names = [
                    seat.get("name")
                    for idx, seat in enumerate(room.get("seat_configs", []))
                    if idx != existing_idx
                ]
                room["seat_configs"][existing_idx]["name"] = unique_name(other_names, player_name)
            self.configure_lobby_game(room)
            return {
                "ok": True,
                "room_code": room["room_code"],
                "phase": room["phase"],
                "seat_index": existing_idx,
                "seat_token": seat_token,
                "seats": self.room_seats(room),
            }
        if len(room["seat_tokens"]) >= 6:
            return {"ok": False, "error": "Room is full."}
        seat_index = len(room["seat_tokens"])
        token = secrets.token_urlsafe(24)
        existing_names = [seat.get("name") for seat in room.get("seat_configs", [])]
        assigned_name = unique_name(existing_names, player_name or f"Player {seat_index + 1}")
        room["seat_tokens"].append(token)
        room["seat_configs"].append({
            "name": assigned_name,
            "is_ai": bool(is_ai),
            "color_index": self.next_available_color_index(room),
        })
        self.configure_lobby_game(room)
        return {
            "ok": True,
            "room_code": room["room_code"],
            "phase": room["phase"],
            "seat_index": seat_index,
            "seat_token": token,
            "seats": self.room_seats(room),
        }

    def update_seat(self, room_code, seat_token, player_name=None, color_index=None):
        room = self.room_for_code(room_code)
        if room["closed"]:
            return {"ok": False, "error": "Room is closed."}
        if room["phase"] != "lobby":
            return {"ok": False, "error": "Seat colors can only change before the room starts."}
        seat_index = self.player_index_for_token(room, seat_token)
        if seat_index is None:
            return {"ok": False, "error": "Seat token did not match this room."}
        seat = room["seat_configs"][seat_index]
        if player_name:
            other_names = [
                existing.get("name")
                for idx, existing in enumerate(room.get("seat_configs", []))
                if idx != seat_index
            ]
            seat["name"] = unique_name(other_names, player_name)
        if color_index is not None:
            try:
                next_color = int(color_index)
            except (TypeError, ValueError):
                return {"ok": False, "error": "Color was not valid."}
            if not (0 <= next_color < len(PLAYER_COLORS)):
                return {"ok": False, "error": "Color was not valid."}
            for idx, existing in enumerate(room.get("seat_configs", [])):
                if idx != seat_index and existing.get("color_index") == next_color:
                    return {"ok": False, "error": f"{PLAYER_COLORS[next_color][0]} is already taken."}
            seat["color_index"] = next_color
        self.configure_lobby_game(room)
        return {
            "ok": True,
            "room_code": room["room_code"],
            "phase": room["phase"],
            "seat_index": seat_index,
            "seat_token": seat_token,
            "seats": self.room_seats(room),
        }

    def start_room(self, room_code, seat_token):
        room = self.room_for_code(room_code)
        if room["closed"]:
            return {"ok": False, "error": "Room is closed."}
        if room["phase"] != "lobby":
            return {"ok": False, "error": "Room is not in lobby phase."}
        if not room["seat_tokens"] or room["seat_tokens"][0] != seat_token:
            return {"ok": False, "error": "Only the host can start this room."}
        if room["game"] is None:
            room["game"] = ShapeAzoidMatch(
                player_count=len(room["seat_tokens"]),
                seat_configs=room.get("seat_configs", []),
            )
        self.configure_lobby_game(room)
        room["game"].start()
        room["phase"] = "playing"
        return {
            "ok": True,
            "room_code": room["room_code"],
            "phase": room["phase"],
            "state": room["game"].state_snapshot(viewer_player=0),
        }

    def lobby_state(self, room, viewer):
        seats = self.room_seats(room)
        return {
            "version": VERSION,
            "state_revision": room["game"].state_revision if room["game"] is not None else 0,
            "mode": "lobby",
            "player_count": len(seats),
            "current_player": 0,
            "players": [
                {
                    "name": seat["name"],
                    "color_name": seat["color_name"],
                    "color_index": seat["color_index"],
                    "is_ai": seat["is_ai"],
                    "score_total": 0,
                    "score_round": 0,
                }
                for seat in seats
            ],
            "deck_count": 0,
            "discard": [],
            "hands": [{"count": 0} for _ in seats],
            "pieces": [],
            "zoids": [],
            "open_walls": [],
            "round_slots": [],
            "round_wild_kind": None,
            "cards_used_this_turn": 0,
            "last_card_drawn": False,
            "no_discard_turns_after_empty": 0,
            "action_log": [],
            "message": "Waiting for the host to start.",
        }

    def snapshot(self, room_code, seat_token=None):
        room = self.room_for_code(room_code)
        self.tick_room(room, max_steps=1)
        viewer = self.player_index_for_token(room, seat_token)
        game = room["game"]
        state = self.lobby_state(room, viewer) if room["phase"] == "lobby" else game.state_snapshot(viewer_player=viewer)
        return {
            "room_code": room["room_code"],
            "host_name": room["host_name"],
            "phase": room["phase"],
            "viewer_player": viewer,
            "seats": self.room_seats(room),
            "state": state,
        }

    def stream_snapshot(self, room_code, seat_token=None):
        room = self.room_for_code(room_code)
        viewer = self.player_index_for_token(room, seat_token)
        game = room["game"]
        state = self.lobby_state(room, viewer) if room["phase"] == "lobby" else game.state_snapshot(viewer_player=viewer, live=True)
        return {
            "room_code": room["room_code"],
            "host_name": room["host_name"],
            "phase": room["phase"],
            "viewer_player": viewer,
            "seats": self.room_seats(room),
            "state": state,
            "server_time": int(time.monotonic() * 1000),
        }

    def apply_command(self, room_code, seat_token, command):
        room = self.room_for_code(room_code)
        if room["closed"]:
            return {"ok": False, "error": "Room is closed."}
        if room["phase"] != "playing":
            return {"ok": False, "error": "Room has not started."}
        actor = self.player_index_for_token(room, seat_token)
        if actor is None:
            return {"ok": False, "error": "Seat token did not match this room."}
        command_type = command.get("type") if isinstance(command, dict) else None
        if command_type == "next_round":
            if room["game"].mode != "score":
                return {"ok": False, "error": "The round has not been scored yet."}
            result = room["game"].start_next_round()
            if result.get("ok"):
                room["game"].record_action(actor, "next_round", {})
            state = room["game"].state_snapshot(viewer_player=actor)
            return {
                **result,
                "room_code": room["room_code"],
                "phase": room["phase"],
                "viewer_player": actor,
                "seats": self.room_seats(room),
                "state": state,
                "state_revision": room["game"].state_revision,
            }
        self.tick_room(room, max_steps=1)
        if actor != room["game"].current_player:
            return {"ok": False, "error": "It is not that player's turn."}
        result = room["game"].apply_player_command(command, actor=actor)
        self.tick_room(room, max_steps=1, force=True)
        state = room["game"].state_snapshot(viewer_player=actor)
        return {
            **result,
            "room_code": room["room_code"],
            "phase": room["phase"],
            "viewer_player": actor,
            "seats": self.room_seats(room),
            "state": state,
            "state_revision": room["game"].state_revision,
        }

    def card_copy(self, card):
        return dict(card) if isinstance(card, dict) else card

    def point_list(self, point):
        return [round(float(point[0]), 3), round(float(point[1]), 3)]

    def wall_list(self, wall):
        return [[round(float(x), 3), round(float(y), 3)] for x, y in wall]

    def wall_tuple(self, wall):
        return tuple(tuple(round(float(value), 2) for value in point) for point in wall)

    def authoritative_game_state(self, game):
        game.ensure_zoid_ids()
        return {
            "player_count": game.player_count,
            "ai_players": sorted(game.ai_players),
            "player_color_indices": list(game.player_color_indices),
            "next_zoid_id": game.next_zoid_id,
            "players": [
                {
                    "name": player["name"],
                    "color_name": player["color_name"],
                    "color_index": player["color_index"],
                }
                for player in game.players
            ],
            "deck": [self.card_copy(card) for card in game.deck],
            "discard": [self.card_copy(card) for card in game.discard],
            "hands": [[self.card_copy(card) for card in hand] for hand in game.hands],
            "pieces": [
                {
                    "shape": piece["shape"],
                    "points": [self.point_list(point) for point in piece["points"]],
                    "owner": piece.get("owner"),
                    "played_by": piece.get("played_by"),
                }
                for piece in game.pieces
            ],
            "zoids": [
                {
                    "zoid_id": z["zoid_id"],
                    "kind": z.get("kind", "zoid"),
                    "owner": z.get("owner"),
                    "played_by": z.get("played_by"),
                    "piece": z.get("piece"),
                    "pos": self.point_list(z.get("pos", (0, 0))),
                    "vel": self.point_list(z.get("vel", (0, 0))),
                    "visited": sorted(z.get("visited", [])),
                }
                for z in game.zoids
            ],
            "open_walls": [self.wall_list(wall) for wall in sorted(game.open_walls)],
            "current_player": game.current_player,
            "cards_used_this_turn": game.cards_used_this_turn,
            "discarded_this_turn": game.discarded_this_turn,
            "last_card_drawn": game.last_card_drawn,
            "no_discard_turns_after_empty": game.no_discard_turns_after_empty,
            "round_scores": list(game.round_scores),
            "total_scores": list(game.total_scores),
            "round_light_scores": list(game.round_light_scores),
            "last_score_breakdown": json.loads(json.dumps(game.last_score_breakdown)),
            "round_slots": list(game.round_slots),
            "round_wild_kind": game.round_wild_kind,
            "turn_started_at": game.turn_started_at,
            "next_ufo_at": game.next_ufo_at,
            "ufo_flight_index": game.ufo_flight_index,
            "active_ufo": json.loads(json.dumps(game.active_ufo)),
            "explosions": json.loads(json.dumps(game.explosions)),
            "slot_show_until": 0,
            "state_revision": game.state_revision,
            "action_log": json.loads(json.dumps(game.action_log)),
            "message": game.message,
        }

    def restore_game_state(self, state):
        game = ShapeAzoidMatch(
            player_count=int(state.get("player_count", 2)),
            ai_players=set(state.get("ai_players", [])),
            player_color_indices=list(state.get("player_color_indices", list(range(6)))),
            seat_configs=state.get("players", []),
        )
        game.deck = [self.card_copy(card) for card in state.get("deck", [])]
        game.discard = [self.card_copy(card) for card in state.get("discard", [])]
        game.hands = [[self.card_copy(card) for card in hand] for hand in state.get("hands", [])]
        game.pieces = [
            {
                "shape": piece["shape"],
                "points": [tuple(point) for point in piece.get("points", [])],
                "owner": piece.get("owner"),
                "played_by": piece.get("played_by"),
            }
            for piece in state.get("pieces", [])
        ]
        game.invalidate_wall_plane_geometry()
        game.zoids = [
            {
                "zoid_id": z.get("zoid_id"),
                "kind": z.get("kind", "zoid"),
                "owner": z.get("owner"),
                "played_by": z.get("played_by"),
                "piece": z.get("piece"),
                "pos": list(z.get("pos", [0, 0])),
                "vel": list(z.get("vel", [0, 0])),
                "visited": set(z.get("visited", [])),
            }
            for z in state.get("zoids", [])
        ]
        game.next_zoid_id = state.get("next_zoid_id", 1)
        game.ensure_zoid_ids()
        game.open_walls = {self.wall_tuple(wall) for wall in state.get("open_walls", [])}
        game.current_player = int(state.get("current_player", 0))
        game.selected_card = None
        game.cards_used_this_turn = int(state.get("cards_used_this_turn", 0))
        game.discarded_this_turn = bool(state.get("discarded_this_turn", False))
        game.last_card_drawn = bool(state.get("last_card_drawn", False))
        game.no_discard_turns_after_empty = int(state.get("no_discard_turns_after_empty", 0))
        game.round_scores = list(state.get("round_scores", [0] * game.player_count))
        game.total_scores = list(state.get("total_scores", [0] * game.player_count))
        game.round_light_scores = list(state.get("round_light_scores", [0] * game.player_count))
        game.last_score_breakdown = list(state.get("last_score_breakdown", []))
        game.round_slots = list(state.get("round_slots", []))
        game.round_wild_kind = state.get("round_wild_kind")
        game.turn_started_at = int(state.get("turn_started_at", 0))
        game.next_ufo_at = int(state.get("next_ufo_at", 0))
        game.ufo_flight_index = int(state.get("ufo_flight_index", 0))
        game.active_ufo = state.get("active_ufo")
        game.explosions = list(state.get("explosions", []))
        game.slot_show_until = 0
        game.state_revision = int(state.get("state_revision", 0))
        game.action_log = list(state.get("action_log", []))
        game.message = state.get("message", "Room restored.")
        for idx, player_state in enumerate(state.get("players", [])):
            if idx < len(game.players):
                game.players[idx]["name"] = player_state.get("name", game.players[idx]["name"])
        return game

    def room_record(self, room_code):
        room = self.room_for_code(room_code)
        return {
            "room_code": room["room_code"],
            "host_name": room["host_name"],
            "phase": room["phase"],
            "seat_tokens": list(room["seat_tokens"]),
            "seat_configs": json.loads(json.dumps(room["seat_configs"])),
            "closed": bool(room["closed"]),
            "game": self.authoritative_game_state(room["game"]) if room["game"] is not None else None,
        }

    def save_room(self, room_code):
        record = self.room_record(room_code)
        self.save_dir.mkdir(parents=True, exist_ok=True)
        path = self.save_dir / f"{record['room_code']}.json"
        path.write_text(json.dumps(record, indent=2), encoding="utf-8")
        return path

    def load_room(self, room_code):
        code = str(room_code or "").strip().upper()
        path = self.save_dir / f"{code}.json"
        if not path.exists():
            raise KeyError("Saved room not found.")
        record = json.loads(path.read_text(encoding="utf-8"))
        game_state = record.get("game")
        game = self.restore_game_state(game_state) if game_state is not None else None
        room = {
            "room_code": record["room_code"],
            "host_name": record["host_name"],
            "phase": record["phase"],
            "game": game,
            "seat_tokens": list(record["seat_tokens"]),
            "seat_configs": list(record["seat_configs"]),
            "closed": bool(record.get("closed", False)),
            "last_tick_at": time.monotonic(),
            "next_ai_tick_at": 0.0,
        }
        self.rooms[room["room_code"]] = room
        return self.snapshot(room["room_code"], seat_token=room["seat_tokens"][0] if room["seat_tokens"] else None)
