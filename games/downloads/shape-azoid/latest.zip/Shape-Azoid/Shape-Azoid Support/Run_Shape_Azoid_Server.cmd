@echo off
setlocal
cd /d "%~dp0"
set "SUPPORT_DIR=%~dp0Shape-Azoid Support"
if not exist "%SUPPORT_DIR%" set "SUPPORT_DIR=%~dp0"
if not exist "%SUPPORT_DIR%\.venv\Scripts\python.exe" (
  echo Missing .venv. Run:
  echo Install_Shape_Azoid_Requirements.cmd
  pause
  exit /b 1
)
cd /d "%SUPPORT_DIR%"
".venv\Scripts\python.exe" -m uvicorn network.shape_azoid_server:app --host 127.0.0.1 --port 8765
