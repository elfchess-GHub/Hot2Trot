import math
import json
import os
import random
import sys
import getpass
import socket
import subprocess
import threading
import time
from urllib.parse import urlparse, urlencode
from array import array
from collections import Counter, deque

import pygame
import pygame.gfxdraw

try:
    from network.shape_azoid_http_client import ShapeAzoidHttpClient, ShapeAzoidHttpError
except Exception:
    ShapeAzoidHttpClient = None
    ShapeAzoidHttpError = RuntimeError

try:
    from websockets.sync.client import connect as websocket_connect
except Exception:
    websocket_connect = None


pygame.mixer.pre_init(44100, -16, 1, 512)
pygame.init()

WIDTH, HEIGHT = 1400, 900
RIGHT_W = 190
BOTTOM_H = 150
BOARD_RECT = pygame.Rect(12, 82, WIDTH - RIGHT_W - 24, HEIGHT - BOTTOM_H - 94)
display_mode = "windowed"
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Shape-Azoid")
CLOCK = pygame.time.Clock()


def apply_display_mode():
    global SCREEN, display_mode
    old_screen = SCREEN
    old_mode = display_mode
    flags = 0
    if display_mode == "fullscreen":
        flags = pygame.FULLSCREEN
    elif display_mode == "windowed_fullscreen":
        flags = pygame.FULLSCREEN
    try:
        SCREEN = pygame.display.set_mode((WIDTH, HEIGHT), flags)
    except pygame.error:
        display_mode = "windowed"
        try:
            SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
        except pygame.error:
            SCREEN = old_screen
            display_mode = old_mode
    pygame.display.set_caption("Shape-Azoid")

BLACK = (8, 10, 16)
WHITE = (238, 243, 250)
PANEL = (8, 15, 25)
PANEL_2 = (10, 20, 32)
LINE_COLOR = (138, 224, 239)
OPEN_LINE_COLOR = (132, 228, 212)
SELECT_COLOR = (226, 183, 102)
NEUTRAL_FILL = (78, 88, 108)
SPACE_BG = (2, 6, 12)
SPACE_TOP = (3, 9, 21)
SPHERE_PANEL = (9, 18, 31)
SPHERE_LINE = (65, 118, 132)
SCI_CYAN = (138, 224, 239)
SCI_TEAL = (84, 214, 193)
SCI_GOLD = (226, 183, 102)
MUSIC_EXTS = (".mp3", ".ogg", ".wav", ".flac", ".mid", ".midi")
MUSIC_END_EVENT = pygame.USEREVENT + 1
current_music_file = None
VERSION = "v0.7.33"
MAX_ACTION_LOG = 80
TELEMETRY_INTERVAL_MS = 1000
SLOW_FRAME_MS = 85
ONLINE_ZOID_SNAP_DISTANCE = 120.0
ONLINE_ZOID_SMOOTHING = 0.35
ZOID_PHYSICS_STEP_MS = 1000.0 / 60.0
MAX_ZOID_PHYSICS_STEPS = 6
SETTINGS_FILENAME = "settings.json"

THEMES = {
    "adam_sphere": {
        "name": "Adam Sphere",
        "bg_top": (3, 9, 21),
        "bg_bottom": (1, 3, 8),
        "panel": (9, 18, 31, 220),
        "panel_2": (10, 20, 32, 220),
        "panel_border": (138, 224, 239, 70),
        "board_fill": (4, 10, 18, 118),
        "board_border": (138, 224, 239, 78),
        "grid": (138, 224, 239, 20),
        "grid_alt": (138, 224, 239, 16),
        "accent": (226, 183, 102),
        "accent_2": (84, 214, 193),
        "text": (238, 243, 250),
        "muted_text": (190, 205, 225),
        "card_body": (8, 15, 25),
        "card_inner": (13, 28, 43),
        "button_top": (10, 20, 32),
        "button_bottom": (5, 10, 18),
        "active_button_top": (84, 214, 193),
        "active_button_bottom": (40, 96, 122),
        "portrait_glow_alpha": 24,
        "active_portrait_glow_alpha": 42,
        "decor": "starfield",
    },
    "atomic_dark": {
        "name": "Atomic Dark",
        "background": "background.png",
        "bg_top": (7, 18, 28),
        "bg_bottom": (2, 6, 12),
        "panel": (22, 19, 15, 214),
        "panel_2": (46, 31, 19, 214),
        "panel_border": (228, 171, 91, 104),
        "board_fill": (5, 17, 24, 0),
        "board_border": (228, 171, 91, 0),
        "grid": (228, 171, 91, 0),
        "grid_alt": (228, 171, 91, 0),
        "accent": (238, 139, 67),
        "accent_2": (228, 171, 91),
        "text": (245, 236, 211),
        "muted_text": (222, 199, 163),
        "card_body": (21, 18, 14),
        "card_inner": (34, 27, 19),
        "button_top": (116, 58, 31),
        "button_bottom": (46, 30, 20),
        "active_button_top": (238, 139, 67),
        "active_button_bottom": (100, 55, 38),
        "portrait_glow_alpha": 14,
        "active_portrait_glow_alpha": 32,
        "decor": "atomic",
    },
    "cream_console": {
        "name": "Cream Console",
        "bg_top": (4, 8, 13),
        "bg_bottom": (0, 1, 5),
        "panel": (224, 213, 181, 218),
        "panel_2": (246, 236, 205, 218),
        "panel_border": (226, 183, 102, 110),
        "board_fill": (185, 225, 218, 0),
        "board_border": (226, 183, 102, 0),
        "grid": (31, 104, 112, 0),
        "grid_alt": (31, 104, 112, 0),
        "accent": (226, 103, 45),
        "accent_2": (226, 183, 102),
        "text": (246, 236, 205),
        "muted_text": (226, 213, 181),
        "card_body": (224, 213, 181),
        "card_inner": (246, 236, 205),
        "card_text": (25, 35, 38),
        "button_top": (245, 232, 200),
        "button_bottom": (190, 215, 205),
        "active_button_top": (226, 103, 45),
        "active_button_bottom": (150, 70, 42),
        "portrait_glow_alpha": 10,
        "active_portrait_glow_alpha": 26,
        "decor": "mod",
        "clear_background_overlay": True,
        "clear_structural_panels": True,
    },
    "rocket_garden": {
        "name": "Rocket Garden",
        "background": "background.png",
        "bg_top": (19, 96, 112),
        "bg_bottom": (7, 34, 48),
        "panel": (236, 222, 181, 198),
        "panel_2": (205, 224, 203, 188),
        "panel_border": (224, 154, 68, 120),
        "board_fill": (9, 44, 58, 0),
        "board_border": (224, 154, 68, 0),
        "grid": (224, 154, 68, 0),
        "grid_alt": (224, 154, 68, 0),
        "accent": (226, 91, 31),
        "accent_2": (184, 151, 73),
        "text": (48, 38, 27),
        "muted_text": (78, 83, 68),
        "card_body": (236, 222, 181),
        "card_inner": (210, 226, 207),
        "button_top": (235, 210, 151),
        "button_bottom": (183, 151, 77),
        "active_button_top": (244, 126, 54),
        "active_button_bottom": (190, 72, 35),
        "portrait_glow_alpha": 10,
        "active_portrait_glow_alpha": 24,
        "decor": "rocket",
    },
    "olive_party_platter": {
        "name": "Olive-Party-Platter",
        "background": "background.png",
        "bg_top": (138, 148, 92),
        "bg_bottom": (84, 98, 58),
        "panel": (225, 211, 165, 198),
        "panel_2": (154, 169, 124, 188),
        "panel_border": (91, 120, 102, 128),
        "board_fill": (94, 133, 119, 0),
        "board_border": (91, 120, 102, 0),
        "grid": (91, 120, 102, 0),
        "grid_alt": (91, 120, 102, 0),
        "accent": (199, 77, 49),
        "accent_2": (142, 147, 79),
        "text": (43, 38, 28),
        "muted_text": (73, 82, 61),
        "card_body": (225, 211, 165),
        "card_inner": (180, 203, 182),
        "button_top": (230, 213, 161),
        "button_bottom": (151, 153, 84),
        "active_button_top": (209, 83, 51),
        "active_button_bottom": (137, 63, 45),
        "portrait_glow_alpha": 10,
        "active_portrait_glow_alpha": 24,
        "decor": "mod",
    },
    "crt_midnight": {
        "name": "CRT Midnight",
        "bg_top": (5, 8, 14),
        "bg_bottom": (0, 1, 5),
        "panel": (7, 14, 24, 230),
        "panel_2": (10, 18, 30, 230),
        "panel_border": (80, 160, 170, 76),
        "board_fill": (4, 9, 16, 136),
        "board_border": (80, 160, 170, 88),
        "grid": (80, 160, 170, 18),
        "grid_alt": (80, 160, 170, 12),
        "accent": (226, 183, 102),
        "accent_2": (80, 160, 170),
        "text": (230, 238, 245),
        "muted_text": (160, 180, 190),
        "card_body": (8, 15, 25),
        "card_inner": (12, 22, 35),
        "button_top": (10, 18, 30),
        "button_bottom": (3, 6, 12),
        "active_button_top": (80, 160, 170),
        "active_button_bottom": (28, 70, 82),
        "portrait_glow_alpha": 10,
        "active_portrait_glow_alpha": 28,
        "decor": "crt",
    },
}

current_theme_key = "adam_sphere"


def theme():
    return THEMES.get(current_theme_key, THEMES["adam_sphere"])

PLAYER_COLORS = [
    ("Red", (225, 58, 64)),
    ("Orange", (242, 133, 44)),
    ("Yellow", (232, 208, 61)),
    ("Green", (65, 177, 92)),
    ("Blue", (66, 133, 235)),
    ("Violet", (147, 93, 214)),
]

CARD_TYPES = ["hex", "pentagon", "square", "triangle", "line", "zoid"]
SHAPE_SIDES = {"triangle": 3, "square": 4, "hex": 6}
SIDE_LEN = 96
ZOID_RADIUS = 9
PENTA_ZOID_RADIUS = 15
WALL_COLLISION_MARGIN = 0.05
WALL_COLLISION_TOLERANCE = 0.00001
WALL_CORRECTION_MAX_PASSES = 64
AI_MOVE_DELAY_MS = 850
AI_BALL_WAIT_TIMEOUT_MS = 12000
AI_REQUIRED_BALL_COVERAGE = 0.75
UFO_FIRST_DELAY_MS = 30000
UFO_REPEAT_DELAY_MS = 10000
UFO_FLIGHT_MS = 4300
UFO_COUNTDOWN_MS = 10000
UFO_DRAW_W = 128
UFO_DRAW_H = 78
ONLINE_POLL_MS = 1400
ONLINE_ACTIVE_SELECTION_POLL_MS = 2400
ONLINE_HTTP_TIMEOUT = 0.85
ONLINE_COMMAND_TIMEOUT = 1.35
EDGE_CLICK_TOLERANCE = 30
LINE_CLICK_TOLERANCE = 48
HAND_CARD_W = 180
HAND_CARD_H = 116
HAND_CARD_GAP = 10
ACTIVE_PORTRAIT_W = 136
ACTIVE_PORTRAIT_H = 156
ROSTER_PORTRAIT_W = 74
ROSTER_PORTRAIT_H = 94
SETUP_PORTRAIT_W = 82
SETUP_PORTRAIT_H = 110
SETTINGS_PORTRAIT_W = 64
SETTINGS_PORTRAIT_H = 84
HELP_SECTIONS = [
    ("Goal", [
        "ShapeAzoiD is a pass-and-play or player-vs-AI shape control game for 1 to 6 players.",
        "Players score by placing shapes, controlling colors on the board, keeping Zoids alive, and lighting same-color connections.",
    ]),
    ("Turn", [
        "Each player can have up to 5 cards at the start of their turn.",
        "Cards played during the turn are not replaced until that player's next turn.",
        "Discarding returns that card to the draw pile.",
    ]),
    ("Cards", [
        "Hex, square, and triangle cards place that shape in the card color.",
        "Zoid cards place a bouncing ball in the card color.",
        "Penta-Zoid cards place a larger star ball that eats normal Zoids.",
        "Line cards remove a wall between connected shapes, letting Zoids pass through.",
        "Wild cards can be right-clicked to cycle their card type for the round.",
    ]),
    ("Placement", [
        "A shape card attaches to an exposed side of an existing shape.",
        "The first player places the first shape on the board.",
        "Shapes cannot overlap, and Shape-Zoids cannot be placed inside another player's color.",
    ]),
    ("Scoring", [
        "Played shape: 1 point to the player who placed it.",
        "Controlled shape: 2 points at end of round for each shape in your active color.",
        "Zoid: 2 points. Penta-Zoid: 3 points.",
        "Open same-color circuit: 1 point at round end.",
    ]),
    ("Multiplayer Prep", [
        "Current play is local pass-and-play or local AI.",
        "The multiplayer version will use the server as referee for deck order, legal moves, scoring, UFO events, and hidden hands.",
        "The prototype server already supports room codes, lobby joining, host start, sanitized snapshots, commands, room listing, and room save/load.",
        "The Online screen can create, list, join, refresh, and start prototype server rooms.",
        "Joiners type the host Server Address and Room Code directly on the Online screen.",
        "Online AI seats can now take server-side bot turns while the client polls the room.",
        "Open Play Shape-Azoid.exe first, then use Online inside the game for hosting or joining.",
    ]),
    ("Keyboard", [
        "F11 toggles display mode.",
        "Esc backs out of Online / Online Playing, or quits from other screens.",
        "Online text fields use Tab, Enter, and Backspace for typing flow.",
        "There is no R hotkey.",
    ]),
]


def make_card(kind, color_index, wild=False):
    return {"kind": kind, "base_kind": kind, "color": color_index, "wild": wild}


def card_kind(card):
    return card.get("kind", card) if isinstance(card, dict) else card


def card_base_kind(card):
    return card.get("base_kind", card_kind(card)) if isinstance(card, dict) else card


def card_color(card):
    return card.get("color", 0) if isinstance(card, dict) else 0


def card_color_name(card):
    color_index = card_color(card)
    if 0 <= color_index < len(PLAYER_COLORS):
        return PLAYER_COLORS[color_index][0]
    return "Color"


def card_rgb(card):
    color_index = card_color(card)
    if 0 <= color_index < len(PLAYER_COLORS):
        return PLAYER_COLORS[color_index][1]
    return WHITE


def color_index_rgb(color_index):
    if color_index is not None and 0 <= color_index < len(PLAYER_COLORS):
        return PLAYER_COLORS[color_index][1]
    return NEUTRAL_FILL


def card_label(card):
    return f"{card_color_name(card)} {card_kind(card)}"


def card_key(card):
    return (card_kind(card), card_color(card))


def card_signature(card):
    if not isinstance(card, dict):
        return None
    return (
        card.get("kind"),
        card.get("base_kind"),
        card.get("color"),
        bool(card.get("wild", False)),
    )


def base_card_key(card):
    return (card_base_kind(card), card_color(card))


def is_wild(card):
    return isinstance(card, dict) and card.get("wild", False)


def cycle_wild_card(card):
    if not is_wild(card):
        return False
    current = card_kind(card)
    idx = CARD_TYPES.index(current) if current in CARD_TYPES else 0
    card["kind"] = CARD_TYPES[(idx + 1) % len(CARD_TYPES)]
    return True

title_font = pygame.font.SysFont("Georgia", 72)
font = pygame.font.SysFont("Segoe UI", 30)
small_font = pygame.font.SysFont(None, 22)
tiny_font = pygame.font.SysFont(None, 18)
NETWORK_SERVER_FILE = "Shape_Azoid_Network_Server.txt"
HOST_SERVER_ADDRESS_FILE = "HOST_SERVER_ADDRESS.txt"


def app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def support_dir():
    packaged_support = os.path.join(app_dir(), "Shape-Azoid Support")
    if os.path.isdir(packaged_support):
        return packaged_support
    return app_dir()


def normalize_server_url(text):
    text = str(text or "").strip()
    if not text:
        return ""
    if "://" not in text:
        text = f"http://{text}"
    parsed = urlparse(text)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return ""
    return f"{parsed.scheme}://{parsed.netloc}"


def websocket_room_url(base_url, room_code, seat_token=None):
    normalized = normalize_server_url(base_url)
    code = str(room_code or "").strip().upper()
    if not normalized or not code:
        return ""
    parsed = urlparse(normalized)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    query = urlencode({"seat_token": seat_token}) if seat_token else ""
    suffix = f"?{query}" if query else ""
    return f"{scheme}://{parsed.netloc}/ws/rooms/{code}{suffix}"


def server_socket_ready(url, timeout=0.25):
    parsed = urlparse(url)
    host = parsed.hostname
    if not host:
        return False
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def configured_network_server_url():
    candidates = [("env", os.environ.get("SHAPE_AZOID_NETWORK_SERVER", ""))]
    search_dirs = []
    for folder in (os.getcwd(), app_dir()):
        if folder not in search_dirs:
            search_dirs.append(folder)
    for folder in search_dirs:
        path = os.path.join(folder, NETWORK_SERVER_FILE)
        if os.path.exists(path):
            try:
                candidates.append(("file", open(path, "r", encoding="utf-8").read().strip()))
            except OSError:
                pass
    for source, candidate in candidates:
        normalized = normalize_server_url(candidate)
        if normalized and (source != "file" or server_socket_ready(normalized)):
            return normalized
    return ""


def local_online_python():
    venv_python = os.path.join(support_dir(), ".venv", "Scripts", "python.exe")
    if os.path.exists(venv_python):
        return venv_python
    if not getattr(sys, "frozen", False):
        return sys.executable
    return ""


def local_lan_ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(("8.8.8.8", 80))
            return probe.getsockname()[0]
    except Exception:
        return "127.0.0.1"


def can_bind_local_port(port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.bind(("0.0.0.0", int(port)))
            return True
    except OSError:
        return False


def free_local_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind(("0.0.0.0", 0))
        return int(probe.getsockname()[1])


def online_address_file_paths():
    return [
        os.path.join(app_dir(), NETWORK_SERVER_FILE),
        os.path.join(app_dir(), HOST_SERVER_ADDRESS_FILE),
    ]


def write_online_address_files(share_url):
    simple_path, help_path = online_address_file_paths()
    with open(simple_path, "w", encoding="utf-8") as handle:
        handle.write(f"{share_url}\n")
    with open(help_path, "w", encoding="utf-8") as handle:
        handle.write(
            "Give this server address to the other player:\n"
            f"{share_url}\n\n"
            "They type this address in Server Address, then type the room code in the Online screen.\n"
        )


def clear_owned_online_address_files(share_url):
    if not share_url:
        return
    for path in online_address_file_paths():
        try:
            content = open(path, "r", encoding="utf-8").read()
        except OSError:
            continue
        if share_url in content:
            try:
                os.remove(path)
            except OSError:
                pass


def runtime_log_dir():
    configured = os.environ.get("SHAPE_AZOID_TELEMETRY_DIR", "").strip()
    folder = configured or os.path.join(app_dir(), "logs")
    os.makedirs(folder, exist_ok=True)
    return folder


class RuntimeTelemetry:
    def __init__(self):
        self.enabled = os.environ.get("SHAPE_AZOID_TELEMETRY", "1").strip().lower() not in {"0", "false", "off", "no"}
        self.handle = None
        self.path = ""
        if not self.enabled:
            return
        try:
            stamp = time.strftime("%Y%m%d-%H%M%S")
            self.path = os.path.join(runtime_log_dir(), f"shape_azoid_run_{stamp}.jsonl")
            self.handle = open(self.path, "a", encoding="utf-8")
            self.write("run_start", {
                "version": VERSION,
                "cwd": os.getcwd(),
                "app_dir": app_dir(),
                "frozen": bool(getattr(sys, "frozen", False)),
            })
        except OSError:
            self.enabled = False
            self.handle = None

    def write(self, kind, data=None):
        if not self.enabled or self.handle is None:
            return
        try:
            row = {
                "kind": kind,
                "wall_time": round(time.time(), 3),
                "tick_ms": pygame.time.get_ticks(),
                "version": VERSION,
            }
            if data:
                row.update(data)
            self.handle.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
            self.handle.flush()
        except Exception:
            self.enabled = False

    def close(self):
        if self.handle is not None:
            try:
                self.write("run_end", {})
                self.handle.close()
            except Exception:
                pass
            self.handle = None


MUSIC_DIR = os.path.join(app_dir(), "music")
ART_DIR = os.path.join(app_dir(), "art")
THEME_DIR = os.path.join(app_dir(), "themes")
SETTINGS_PATH = os.path.join(app_dir(), SETTINGS_FILENAME)
STARFIELD = []
STAR_COUNTER = 0
STAR_CENTER = (WIDTH // 2 - RIGHT_W // 2, HEIGHT // 2 - BOTTOM_H // 3)
STARFIELD_SURFACE = None
CHARACTER_IMAGES = {}
ACTION_CHARACTER_IMAGES = {}
OPENING_IMAGE = None
THEME_BACKGROUNDS = {}
BACKGROUND_BASE_CACHE = {}
BACKGROUND_OVERLAY_CACHE = {}
BOARD_GRID_CACHE = {}
SHAPE_GRADIENT_CACHE = {}
SHAPE_GRADIENT_CACHE_ORDER = deque()
SHAPE_GRADIENT_CACHE_LIMIT = 128
CIRCUIT_GLOW_SURFACE = None
GLASS_RECT_CACHE = {}
METAL_PANEL_CACHE = {}
BUTTON_SURFACE_CACHE = {}
PORTRAIT_SURFACE_CACHE = {}
WALL_NETWORK_CACHE = {}
WALL_NETWORK_CACHE_ORDER = deque()
WALL_NETWORK_CACHE_LIMIT = 4
WALL_NETWORK_SUPERSAMPLE = 4
UFO_IMAGE = None

ACTION_IMAGE_FOLDERS = {
    "thinking": ("thinking", ["Green", "Yellow", "Orange", "Red", "Violet", "Blue"]),
    "sad": ("sad", ["Blue", "Yellow", "Orange", "Red", "Green", "Violet"]),
    "angry": ("Angry", ["Blue", "Orange", "Red", "Violet", "Green", "Yellow"]),
    "point_left": ("pointleftohno", ["Blue", "Yellow", "Orange", "Red", "Green", "Violet"]),
    "point_right": ("pointright", ["Blue", "Yellow", "Orange", "Red", "Green", "Violet"]),
}


def theme_asset_path(filename):
    return os.path.join(THEME_DIR, current_theme_key, filename)


def theme_has_background_asset():
    return bool(theme().get("background"))


def theme_clears_background_overlay():
    return theme_has_background_asset() or bool(theme().get("clear_background_overlay"))


def theme_clears_structural_panels():
    return theme_has_background_asset() or bool(theme().get("clear_structural_panels"))


# ---------- Golgi-style key sounds ----------

SAMPLE_RATE = 44100
NOTE_CACHE = {}
KEY_LIBRARY = [
    ("C Major", 261.63, [0, 2, 4, 5, 7, 9, 11]),
    ("D Major", 293.66, [0, 2, 4, 5, 7, 9, 11]),
    ("E Major", 329.63, [0, 2, 4, 5, 7, 9, 11]),
    ("F Major", 349.23, [0, 2, 4, 5, 7, 9, 11]),
    ("G Major", 392.00, [0, 2, 4, 5, 7, 9, 11]),
    ("A Major", 440.00, [0, 2, 4, 5, 7, 9, 11]),
    ("D Minor", 293.66, [0, 2, 3, 5, 7, 8, 10]),
    ("E Minor", 329.63, [0, 2, 3, 5, 7, 8, 10]),
    ("G Minor", 392.00, [0, 2, 3, 5, 7, 8, 10]),
    ("A Minor", 440.00, [0, 2, 3, 5, 7, 8, 10]),
]
SOUND_STYLES = {
    "glass": {"harm2": 0.55, "harm3": 0.24, "harm4": 0.10, "duration": 0.72, "volume": 0.15, "vibrato": 0.0025, "attack": 0.03, "decay_curve": 2.8},
    "pluck": {"harm2": 0.30, "harm3": 0.09, "harm4": 0.03, "duration": 0.34, "volume": 0.17, "vibrato": 0.0, "attack": 0.01, "decay_curve": 5.0},
    "chime": {"harm2": 0.72, "harm3": 0.18, "harm4": 0.16, "duration": 0.86, "volume": 0.13, "vibrato": 0.004, "attack": 0.02, "decay_curve": 2.4},
    "organ": {"harm2": 0.42, "harm3": 0.34, "harm4": 0.22, "duration": 0.58, "volume": 0.12, "vibrato": 0.006, "attack": 0.08, "decay_curve": 1.5},
    "soft": {"harm2": 0.22, "harm3": 0.05, "harm4": 0.02, "duration": 0.62, "volume": 0.12, "vibrato": 0.001, "attack": 0.05, "decay_curve": 3.3},
}
current_key = random.choice(KEY_LIBRARY)
sound_enabled = True
sfx_volume = 0.78
music_volume = 0.45
effect_instruments = {"glass": "glass", "pluck": "pluck"}


def default_settings():
    return {
        "version": 1,
        "audio": {
            "music_enabled": True,
            "music_volume": 0.45,
            "sound_effects_volume": 0.78,
        },
        "graphics": {
            "display_mode": "windowed",
            "theme": "adam_sphere",
        },
        "gameplay": {
            "player_count": 2,
            "ai_players": [1],
        },
        "sound": {
            "key": current_key[0],
            "glass_button": "glass",
            "pluck_button": "pluck",
        },
    }


def clamp_setting(value, low, high, fallback):
    try:
        return max(low, min(high, float(value)))
    except (TypeError, ValueError):
        return fallback


def load_player_settings():
    global display_mode, music_volume, sfx_volume, current_theme_key, current_key, effect_instruments
    if not os.path.exists(SETTINGS_PATH):
        return default_settings()
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as handle:
            settings = json.load(handle)
    except Exception:
        return default_settings()

    audio = settings.get("audio", {})
    graphics = settings.get("graphics", {})
    sound = settings.get("sound", {})

    music_volume = clamp_setting(audio.get("music_volume"), 0.0, 1.0, music_volume)
    sfx_volume = clamp_setting(audio.get("sound_effects_volume"), 0.0, 1.0, sfx_volume)
    if graphics.get("display_mode") in {"windowed", "fullscreen", "windowed_fullscreen"}:
        display_mode = graphics["display_mode"]
    if graphics.get("theme") in THEMES:
        current_theme_key = graphics["theme"]
    key_name = sound.get("key")
    for key in KEY_LIBRARY:
        if key[0] == key_name:
            current_key = key
            break
    for role, value in {
        "glass": sound.get("glass_button"),
        "pluck": sound.get("pluck_button"),
    }.items():
        if value in SOUND_STYLES:
            effect_instruments[role] = value
    return settings


def save_player_settings(game=None):
    settings = default_settings()
    settings["audio"]["music_volume"] = round(float(music_volume), 3)
    settings["audio"]["sound_effects_volume"] = round(float(sfx_volume), 3)
    settings["graphics"]["display_mode"] = display_mode
    settings["graphics"]["theme"] = current_theme_key
    settings["sound"]["key"] = current_key[0]
    settings["sound"]["glass_button"] = effect_instruments.get("glass", "glass")
    settings["sound"]["pluck_button"] = effect_instruments.get("pluck", "pluck")
    if game is not None:
        settings["audio"]["music_enabled"] = bool(game.music_enabled)
        settings["gameplay"]["player_count"] = int(game.player_count)
        settings["gameplay"]["ai_players"] = sorted(int(i) for i in game.ai_players)
    try:
        with open(SETTINGS_PATH, "w", encoding="utf-8") as handle:
            json.dump(settings, handle, indent=2, sort_keys=True)
            handle.write("\n")
    except Exception:
        pass


def make_ding_sound(freq, style_name="glass"):
    style = SOUND_STYLES.get(style_name, SOUND_STYLES["glass"])
    key = (round(freq, 2), style_name)
    if key in NOTE_CACHE:
        return NOTE_CACHE[key]

    n_samples = int(SAMPLE_RATE * style["duration"])
    attack = max(1, int(n_samples * style["attack"]))
    buf = array("h")
    for i in range(n_samples):
        t = i / SAMPLE_RATE
        vib = 1.0 + style["vibrato"] * math.sin(2 * math.pi * 5.2 * t)
        f = freq * vib
        wave = (
            math.sin(2 * math.pi * f * t)
            + style["harm2"] * math.sin(2 * math.pi * f * 2.0 * t)
            + style["harm3"] * math.sin(2 * math.pi * f * 3.0 * t)
            + style["harm4"] * math.sin(2 * math.pi * f * 4.0 * t)
        )
        if i < attack:
            env = i / attack
        else:
            decay_t = (i - attack) / max(1, n_samples - attack)
            env = math.exp(-decay_t * style["decay_curve"])
        env *= max(0.0, 1.0 - (i / n_samples) ** 2)
        sample = int(max(-1.0, min(1.0, wave * env * style["volume"])) * 32767)
        buf.append(sample)
    snd = pygame.mixer.Sound(buffer=buf.tobytes())
    NOTE_CACHE[key] = snd
    return snd


def play_note(style="glass"):
    if not sound_enabled:
        return
    try:
        instrument = effect_instruments.get(style, style)
        _, root_freq, intervals = current_key
        freq = root_freq * (2 ** (random.choice(intervals) / 12.0)) * random.choice([0.5, 1.0, 1.0, 2.0])
        snd = make_ding_sound(freq, instrument)
        snd.set_volume(sfx_volume)
        snd.play()
    except Exception:
        pass


def available_music_files():
    if not os.path.isdir(MUSIC_DIR):
        return []
    return [
        os.path.join(MUSIC_DIR, name)
        for name in sorted(os.listdir(MUSIC_DIR))
        if name.lower().endswith(MUSIC_EXTS)
    ]


def start_music():
    global current_music_file
    files = available_music_files()
    if not files:
        return False
    choices = files
    if current_music_file in files and len(files) > 1:
        choices = [path for path in files if path != current_music_file]
    selected = random.choice(choices)
    try:
        pygame.mixer.music.set_endevent(MUSIC_END_EVENT)
        pygame.mixer.music.load(selected)
        pygame.mixer.music.set_volume(music_volume)
        pygame.mixer.music.play()
        current_music_file = selected
        return True
    except Exception:
        return False


def stop_music():
    global current_music_file
    try:
        pygame.mixer.music.stop()
        pygame.mixer.music.set_endevent()
        current_music_file = None
    except Exception:
        pass


def load_character_images():
    if CHARACTER_IMAGES or not os.path.isdir(ART_DIR):
        return
    files = [
        os.path.join(ART_DIR, name)
        for name in sorted(os.listdir(ART_DIR))
        if name.lower().endswith((".png", ".webp", ".jpg", ".jpeg"))
    ]
    by_name = {os.path.splitext(os.path.basename(path))[0].lower(): path for path in files}
    used_paths = set()
    for color_idx, (color_name, _) in enumerate(PLAYER_COLORS):
        path = by_name.get(color_name.lower())
        if path:
            try:
                CHARACTER_IMAGES[color_idx] = prepare_character_image(pygame.image.load(path))
                used_paths.add(path)
            except Exception:
                pass
    remaining = [path for path in files if path not in used_paths]
    for color_idx in range(len(PLAYER_COLORS)):
        if color_idx in CHARACTER_IMAGES or not remaining:
            continue
        path = remaining.pop(0)
        try:
            CHARACTER_IMAGES[color_idx] = prepare_character_image(pygame.image.load(path))
        except Exception:
            pass


def load_action_character_images(action=None, color_idx=None):
    if not os.path.isdir(ART_DIR):
        return
    color_lookup = {name.lower(): idx for idx, (name, _) in enumerate(PLAYER_COLORS)}
    actions = [action] if action in ACTION_IMAGE_FOLDERS else list(ACTION_IMAGE_FOLDERS.keys())
    for action_key in actions:
        if color_idx is not None and color_idx in ACTION_CHARACTER_IMAGES.get(action_key, {}):
            continue
        folder_name, color_order = ACTION_IMAGE_FOLDERS[action_key]
        folder = os.path.join(ART_DIR, folder_name)
        if not os.path.isdir(folder):
            continue
        files = [
            os.path.join(folder, name)
            for name in sorted(os.listdir(folder))
            if name.lower().endswith((".png", ".webp", ".jpg", ".jpeg"))
        ]
        action_images = ACTION_CHARACTER_IMAGES.setdefault(action_key, {})
        for path, color_name in zip(files, color_order):
            mapped_idx = color_lookup.get(color_name.lower())
            if mapped_idx is None or mapped_idx in action_images:
                continue
            if color_idx is not None and mapped_idx != color_idx:
                continue
            try:
                image = pygame.image.load(path).convert_alpha()
                max_h = 420
                if image.get_height() > max_h:
                    scale = max_h / image.get_height()
                    size = (max(1, int(image.get_width() * scale)), max_h)
                    image = pygame.transform.scale(image, size)
                action_images[mapped_idx] = prepare_character_image(image)
            except Exception:
                pass


def opening_image():
    global OPENING_IMAGE
    if OPENING_IMAGE is not None:
        return OPENING_IMAGE
    path = os.path.join(ART_DIR, "opening.png")
    if not os.path.exists(path):
        return None
    try:
        OPENING_IMAGE = pygame.image.load(path).convert_alpha()
    except Exception:
        OPENING_IMAGE = None
    return OPENING_IMAGE


def ufo_image():
    global UFO_IMAGE
    if UFO_IMAGE is not None:
        return UFO_IMAGE
    folder = os.path.join(ART_DIR, "UFO")
    if not os.path.isdir(folder):
        return None
    files = [
        os.path.join(folder, name)
        for name in sorted(os.listdir(folder))
        if name.lower().endswith((".png", ".webp", ".jpg", ".jpeg"))
    ]
    files.sort(key=lambda path: 0 if os.path.basename(path).lower() == "ufo_transparent.png" else 1)
    for path in files:
        try:
            UFO_IMAGE = prepare_character_image(pygame.image.load(path))
            return UFO_IMAGE
        except Exception:
            pass
    return None


def themed_background_image():
    filename = theme().get("background")
    if not filename:
        return None
    key = (current_theme_key, filename)
    if key in THEME_BACKGROUNDS:
        return THEME_BACKGROUNDS[key]
    path = theme_asset_path(filename)
    if not os.path.exists(path):
        THEME_BACKGROUNDS[key] = None
        return None
    try:
        THEME_BACKGROUNDS[key] = pygame.image.load(path).convert_alpha()
    except Exception:
        THEME_BACKGROUNDS[key] = None
    return THEME_BACKGROUNDS[key]


def blit_cover(image, rect):
    if not image:
        return False
    scale = max(rect.width / image.get_width(), rect.height / image.get_height())
    size = (max(1, int(image.get_width() * scale)), max(1, int(image.get_height() * scale)))
    scaled = pygame.transform.smoothscale(image, size)
    SCREEN.blit(scaled, scaled.get_rect(center=rect.center))
    return True


def cover_image_surface(image, rect):
    surf = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    if not image:
        return surf
    scale = max(rect.width / image.get_width(), rect.height / image.get_height())
    size = (max(1, int(image.get_width() * scale)), max(1, int(image.get_height() * scale)))
    scaled = pygame.transform.smoothscale(image, size)
    surf.blit(scaled, scaled.get_rect(center=surf.get_rect().center))
    return surf


def blit_fit(image, rect):
    if not image:
        return
    scale = min(rect.width / image.get_width(), rect.height / image.get_height())
    size = (max(1, int(image.get_width() * scale)), max(1, int(image.get_height() * scale)))
    scaled = pygame.transform.smoothscale(image, size)
    SCREEN.blit(scaled, scaled.get_rect(center=rect.center))


def checker_background_channels(r, g, b, a):
    return a > 0 and min(r, g, b) >= 210 and max(r, g, b) - min(r, g, b) <= 28


def is_checker_background(pixel):
    return checker_background_channels(*pixel)


def prepare_character_image(image):
    surf = image.convert_alpha()
    w, h = surf.get_size()
    pixels = pygame.PixelArray(surf)
    seen = bytearray(w * h)
    stack = []
    for x in range(w):
        top = x
        if not seen[top]:
            seen[top] = 1
            stack.append(top)
        bottom = (h - 1) * w + x
        if not seen[bottom]:
            seen[bottom] = 1
            stack.append(bottom)
    for y in range(h):
        left = y * w
        if not seen[left]:
            seen[left] = 1
            stack.append(left)
        right = left + w - 1
        if not seen[right]:
            seen[right] = 1
            stack.append(right)

    red_mask, green_mask, blue_mask, alpha_mask = surf.get_masks()
    red_shift, green_shift, blue_shift, alpha_shift = surf.get_shifts()
    direct_channels = surf.get_losses() == (0, 0, 0, 0)
    pixel_value_mask = (1 << surf.get_bitsize()) - 1

    while stack:
        index = stack.pop()
        x = index % w
        y = index // w
        mapped = int(pixels[x, y]) & pixel_value_mask
        if direct_channels:
            red = (mapped & red_mask) >> red_shift
            green = (mapped & green_mask) >> green_shift
            blue = (mapped & blue_mask) >> blue_shift
            alpha = (mapped & alpha_mask) >> alpha_shift
        else:
            color = surf.unmap_rgb(mapped)
            red, green, blue, alpha = color.r, color.g, color.b, color.a
        if not checker_background_channels(red, green, blue, alpha):
            continue
        pixels[x, y] = mapped & ~alpha_mask
        if x + 1 < w and not seen[index + 1]:
            seen[index + 1] = 1
            stack.append(index + 1)
        if x > 0 and not seen[index - 1]:
            seen[index - 1] = 1
            stack.append(index - 1)
        if y + 1 < h and not seen[index + w]:
            seen[index + w] = 1
            stack.append(index + w)
        if y > 0 and not seen[index - w]:
            seen[index - w] = 1
            stack.append(index - w)

    del pixels

    mask = pygame.mask.from_surface(surf)
    component = mask.connected_component()
    if component.count() > 0:
        component_surface = component.to_surface(setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 0)).convert_alpha()
        surf.blit(component_surface, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)

    bounds = surf.get_bounding_rect()
    if bounds.width <= 0 or bounds.height <= 0:
        return surf
    return surf.subsurface(bounds).copy()


def portrait_for_color(color_idx, action=None):
    load_character_images()
    if action:
        load_action_character_images(action=action, color_idx=color_idx)
        action_images = ACTION_CHARACTER_IMAGES.get(action)
        if action_images and color_idx in action_images:
            return action_images[color_idx]
    return CHARACTER_IMAGES.get(color_idx)


def draw_portrait(color_idx, rect, active=False, action=None):
    img = portrait_for_color(color_idx, action=action)
    tdata = theme()
    border = PLAYER_COLORS[color_idx][1] if 0 <= color_idx < len(PLAYER_COLORS) else tdata["accent_2"]
    if img:
        alpha = tdata["active_portrait_glow_alpha"] if active else tdata["portrait_glow_alpha"]
        key = (current_theme_key, color_idx, action or "", bool(active), rect.width, rect.height, border, alpha, id(img))
        cached = PORTRAIT_SURFACE_CACHE.get(key)
        if cached is None:
            cached = pygame.Surface((rect.width + 26, rect.height + 26), pygame.SRCALPHA)
            pygame.draw.ellipse(cached, border + (alpha,), cached.get_rect())
            inner = pygame.Rect(13, 13, rect.width, rect.height)
            scale = min(rect.width / img.get_width(), rect.height / img.get_height())
            size = (max(1, int(img.get_width() * scale)), max(1, int(img.get_height() * scale)))
            scaled = pygame.transform.smoothscale(img, size)
            cached.blit(scaled, scaled.get_rect(center=inner.center))
            if active:
                foot_y = inner.bottom - 3
                pygame.draw.line(cached, tdata["accent"], (inner.x + 12, foot_y), (inner.right - 12, foot_y), 2)
            PORTRAIT_SURFACE_CACHE[key] = cached
        SCREEN.blit(cached, (rect.x - 13, rect.y - 13))
    else:
        pygame.draw.circle(SCREEN, border, rect.center, min(rect.width, rect.height) // 3)
    if active:
        if not img:
            foot_y = rect.bottom - 3
            pygame.draw.line(SCREEN, tdata["accent"], (rect.x + 12, foot_y), (rect.right - 12, foot_y), 2)


def draw_ufo_event():
    if GAME.mode not in ("playing", "online_playing"):
        return
    tdata = theme()
    now = pygame.time.get_ticks()

    if GAME.next_ufo_at and GAME.active_ufo is None:
        remaining = GAME.next_ufo_at - now
        if 0 < remaining <= UFO_COUNTDOWN_MS:
            seconds = max(1, math.ceil(remaining / 1000))
            label = f"UFO {seconds}"
            text = font.render(label, True, WHITE)
            shadow = font.render(label, True, BLACK)
            box = pygame.Rect(0, 0, max(116, text.get_width() + 30), 48)
            box.topright = (WIDTH - RIGHT_W - 22, 18)
            badge = pygame.Surface(box.size, pygame.SRCALPHA)
            pygame.draw.rect(badge, (3, 6, 10, 232), badge.get_rect(), border_radius=8)
            pygame.draw.rect(badge, tdata["accent"] + (230,), badge.get_rect(), 2, border_radius=8)
            pygame.draw.rect(badge, WHITE + (54,), badge.get_rect().inflate(-5, -5), 1, border_radius=6)
            bar_rect = pygame.Rect(12, box.height - 10, box.width - 24, 4)
            pygame.draw.rect(badge, (28, 36, 44, 255), bar_rect, border_radius=2)
            fill_w = int(bar_rect.width * (remaining / UFO_COUNTDOWN_MS))
            if fill_w > 0:
                pygame.draw.rect(badge, tdata["accent"] + (255,), pygame.Rect(bar_rect.x, bar_rect.y, fill_w, bar_rect.height), border_radius=2)
            badge.blit(shadow, shadow.get_rect(center=(box.width // 2 + 2, box.height // 2 - 3)))
            badge.blit(text, text.get_rect(center=(box.width // 2, box.height // 2 - 5)))
            SCREEN.blit(badge, box.topleft)

    event = GAME.active_ufo
    if event is not None:
        progress = (now - event["started_at"]) / max(1, event["ends_at"] - event["started_at"])
        progress = max(0.0, min(1.0, progress))
        sx, sy = event["start"]
        ex, ey = event["end"]
        x = sx + (ex - sx) * progress
        y = sy + (ey - sy) * progress
        target = event.get("target_pos")
        if target and event["shot_at"] <= now <= event["hit_at"]:
            pulse = 0.45 + 0.55 * math.sin(now * 0.024)
            beam_color = blend(tdata["accent"], WHITE, pulse)
            pygame.draw.line(SCREEN, beam_color, (int(x), int(y + UFO_DRAW_H * 0.28)), (int(target[0]), int(target[1])), 3)
            pygame.draw.circle(SCREEN, beam_color, (int(target[0]), int(target[1])), 6, 2)
        img = ufo_image()
        if img:
            scaled = pygame.transform.smoothscale(img, (UFO_DRAW_W, UFO_DRAW_H))
            if not event.get("left_to_right", True):
                scaled = pygame.transform.flip(scaled, True, False)
            SCREEN.blit(scaled, scaled.get_rect(center=(int(x), int(y))))
        else:
            pygame.draw.ellipse(SCREEN, (230, 235, 240), pygame.Rect(int(x - 52), int(y - 18), 104, 36))
            pygame.draw.ellipse(SCREEN, BLACK, pygame.Rect(int(x - 52), int(y - 18), 104, 36), 3)
            pygame.draw.ellipse(SCREEN, (190, 210, 230), pygame.Rect(int(x - 24), int(y - 36), 48, 30))

    for explosion in GAME.explosions:
        age = now - explosion["started_at"]
        duration = max(1, explosion["duration"])
        t = max(0.0, min(1.0, age / duration))
        cx, cy = explosion["pos"]
        radius = int(18 + 52 * t)
        alpha = int(220 * (1.0 - t))
        burst = pygame.Surface((radius * 2 + 8, radius * 2 + 8), pygame.SRCALPHA)
        center = (burst.get_width() // 2, burst.get_height() // 2)
        pygame.draw.circle(burst, tdata["accent"] + (max(0, alpha // 2),), center, radius)
        pygame.draw.circle(burst, (255, 236, 160, alpha), center, max(3, radius // 3))
        for i in range(10):
            angle = i * math.tau / 10 + t * 2.3
            start = (center[0] + math.cos(angle) * radius * 0.25, center[1] + math.sin(angle) * radius * 0.25)
            end = (center[0] + math.cos(angle) * radius, center[1] + math.sin(angle) * radius)
            pygame.draw.line(burst, (255, 246, 190, alpha), start, end, 2)
        SCREEN.blit(burst, (int(cx - center[0]), int(cy - center[1])))


# ---------- Geometry ----------


def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def midpoint(a, b):
    return ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)


def polygon_area(points):
    total = 0
    for i, p in enumerate(points):
        q = points[(i + 1) % len(points)]
        total += p[0] * q[1] - q[0] * p[1]
    return total / 2


def ensure_ccw(points):
    return points if polygon_area(points) > 0 else list(reversed(points))


def centroid(points):
    return (sum(p[0] for p in points) / len(points), sum(p[1] for p in points) / len(points))


def side_list(points):
    return [(points[i], points[(i + 1) % len(points)]) for i in range(len(points))]


def edge_key(a, b, precision=2):
    a2 = (round(a[0], precision), round(a[1], precision))
    b2 = (round(b[0], precision), round(b[1], precision))
    return tuple(sorted([a2, b2]))


def regular_polygon(center, radius, sides, rotation=0):
    cx, cy = center
    return ensure_ccw([
        (cx + math.cos(rotation + 2 * math.pi * i / sides) * radius,
         cy + math.sin(rotation + 2 * math.pi * i / sides) * radius)
        for i in range(sides)
    ])


def point_in_polygon(point, polygon):
    x, y = point
    inside = False
    n = len(polygon)
    j = n - 1
    for i in range(n):
        xi, yi = polygon[i]
        xj, yj = polygon[j]
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) or 0.00001) + xi):
            inside = not inside
        j = i
    return inside


def point_segment_distance(p, a, b):
    ax, ay = a
    bx, by = b
    px, py = p
    dx, dy = bx - ax, by - ay
    denom = dx * dx + dy * dy
    if denom == 0:
        return dist(p, a), a
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / denom))
    q = (ax + t * dx, ay + t * dy)
    return dist(p, q), q


def weighted_edge_click_score(p, a, b, max_distance=EDGE_CLICK_TOLERANCE):
    d, q = point_segment_distance(p, a, b)
    if d > max_distance:
        return None
    return d + dist(p, midpoint(a, b)) * 0.04


def project_polygon(points, axis):
    values = [p[0] * axis[0] + p[1] * axis[1] for p in points]
    return min(values), max(values)


def polygon_edges(points):
    return [(points[i], points[(i + 1) % len(points)]) for i in range(len(points))]


def polygons_overlap(poly_a, poly_b, eps=0.8):
    # Convex SAT test. Edge/point touching is allowed; real area overlap is not.
    for poly in (poly_a, poly_b):
        for a, b in polygon_edges(poly):
            ex, ey = b[0] - a[0], b[1] - a[1]
            length = math.hypot(ex, ey)
            if length == 0:
                continue
            axis = (-ey / length, ex / length)
            min_a, max_a = project_polygon(poly_a, axis)
            min_b, max_b = project_polygon(poly_b, axis)
            if min(max_a, max_b) - max(min_a, min_b) <= eps:
                return False
    return True


def polygon_from_shared_edge(a, b, sides_count, current_center, side_len_override=None):
    side_len = side_len_override if side_len_override is not None else dist(a, b)
    mx, my = midpoint(a, b)
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    edge_len_actual = math.hypot(dx, dy) or 0.00001
    edge_angle = math.atan2(dy, dx)
    apothem = side_len / (2 * math.tan(math.pi / sides_count))
    nx1, ny1 = -dy / edge_len_actual, dx / edge_len_actual
    nx2, ny2 = dy / edge_len_actual, -dx / edge_len_actual
    c1 = (mx + nx1 * apothem, my + ny1 * apothem)
    c2 = (mx + nx2 * apothem, my + ny2 * apothem)
    center = c1 if dist(c1, current_center) > dist(c2, current_center) else c2
    radius = side_len / (2 * math.sin(math.pi / sides_count))
    pts = regular_polygon(center, radius, sides_count, edge_angle - math.pi / 2 + math.pi / sides_count)

    best_i = 0
    best_score = float("inf")
    for i in range(len(pts)):
        p1 = pts[i]
        p2 = pts[(i + 1) % len(pts)]
        score = min(dist(p1, a) + dist(p2, b), dist(p1, b) + dist(p2, a))
        if score < best_score:
            best_i = i
            best_score = score
    return ensure_ccw(pts[best_i:] + pts[:best_i])


def build_points_for_shape(shape_name, a=None, b=None, current_center=None):
    sides_count = SHAPE_SIDES[shape_name]
    if a is None or b is None:
        radius = SIDE_LEN / (2 * math.sin(math.pi / sides_count))
        return regular_polygon(BOARD_RECT.center, radius, sides_count, -math.pi / 2)
    if shape_name == "triangle":
        side_len = dist(a, b)
        mx, my = midpoint(a, b)
        dx, dy = b[0] - a[0], b[1] - a[1]
        edge_len = math.hypot(dx, dy) or 0.00001
        h = math.sqrt(3) / 2 * side_len
        nx1, ny1 = -dy / edge_len, dx / edge_len
        nx2, ny2 = dy / edge_len, -dx / edge_len
        p1 = (mx + nx1 * h, my + ny1 * h)
        p2 = (mx + nx2 * h, my + ny2 * h)
        p3 = p1 if dist(p1, current_center) > dist(p2, current_center) else p2
        return ensure_ccw([a, b, p3])
    return polygon_from_shared_edge(a, b, sides_count, current_center)


def reflect_velocity(vx, vy, a, b):
    ex, ey = b[0] - a[0], b[1] - a[1]
    length = math.hypot(ex, ey) or 0.00001
    tx, ty = ex / length, ey / length
    nx, ny = -ty, tx
    dot = vx * nx + vy * ny
    return vx - 2 * dot * nx, vy - 2 * dot * ny


def inward_edge_normal(a, b, center):
    ex, ey = b[0] - a[0], b[1] - a[1]
    length = math.hypot(ex, ey) or 0.00001
    nx, ny = -ey / length, ex / length
    mx, my = midpoint(a, b)
    if (center[0] - mx) * nx + (center[1] - my) * ny < 0:
        nx, ny = -nx, -ny
    return nx, ny


def reflect_velocity_from_normal(vx, vy, nx, ny):
    dot = vx * nx + vy * ny
    return vx - 2 * dot * nx, vy - 2 * dot * ny


def valid_contact_velocity(vx, vy, inward_normals, tolerance=WALL_COLLISION_TOLERANCE):
    normals_by_key = {}
    for nx, ny in inward_normals:
        length = math.hypot(nx, ny)
        if length <= 0.000000001:
            continue
        normal = (nx / length, ny / length)
        normals_by_key[(round(normal[0], 12), round(normal[1], 12))] = normal
    normals = [normals_by_key[key] for key in sorted(normals_by_key)]
    speed = math.hypot(vx, vy)
    if speed <= 0.000000001 or not normals:
        return vx, vy

    incoming = [normal for normal in normals if vx * normal[0] + vy * normal[1] < -tolerance]
    if len(incoming) == 1:
        preferred = reflect_velocity_from_normal(vx, vy, incoming[0][0], incoming[0][1])
    elif len(incoming) >= 2:
        preferred = (-vx, -vy)
    else:
        preferred = (vx, vy)

    def direction_is_valid(direction):
        return all(
            direction[0] * nx + direction[1] * ny >= -tolerance
            for nx, ny in normals
        )

    if direction_is_valid(preferred):
        return preferred

    preferred_length = math.hypot(*preferred)
    preferred_unit = (preferred[0] / preferred_length, preferred[1] / preferred_length)
    candidates = {}

    def add_candidate(x, y):
        length = math.hypot(x, y)
        if length <= 0.000000001:
            return
        direction = (x / length, y / length)
        if not direction_is_valid(direction):
            return
        candidates[(round(direction[0], 12), round(direction[1], 12))] = direction

    for nx, ny in normals:
        add_candidate(-ny, nx)
        add_candidate(ny, -nx)

    for mask in range(1, 1 << len(normals)):
        sum_x = sum(normal[0] for index, normal in enumerate(normals) if mask & (1 << index))
        sum_y = sum(normal[1] for index, normal in enumerate(normals) if mask & (1 << index))
        add_candidate(sum_x, sum_y)

    if not candidates:
        raise ValueError("Contact normals do not admit a speed-preserving feasible direction.")
    direction = min(
        candidates.values(),
        key=lambda item: (
            -round(item[0] * preferred_unit[0] + item[1] * preferred_unit[1], 12),
            round(item[0], 12),
            round(item[1], 12),
        ),
    )
    result = (direction[0] * speed, direction[1] * speed)
    if not direction_is_valid(result):
        raise ValueError("Contact response did not satisfy every wall constraint.")
    return result


def blend(a, b, t):
    return (
        int(a[0] * (1 - t) + b[0] * t),
        int(a[1] * (1 - t) + b[1] * t),
        int(a[2] * (1 - t) + b[2] * t),
    )


def brighten(color, amount=0.25):
    return blend(color, WHITE, amount)


def darken(color, amount=0.35):
    return blend(color, BLACK, amount)


def readable_text_color(bg):
    brightness = bg[0] * 0.299 + bg[1] * 0.587 + bg[2] * 0.114
    return BLACK if brightness > 150 else WHITE


def reset_star(star=None):
    global STAR_COUNTER
    angle = random.random() * math.tau
    STAR_COUNTER += 1
    pale_color = brighten(random.choice(PLAYER_COLORS)[1], 0.68) if STAR_COUNTER % 3 == 0 else (250, 253, 255)
    data = {
        "angle": angle,
        "radius": random.uniform(4.0, 92.0),
        "speed": random.uniform(1.7, 4.9),
        "size": random.choice((1, 1, 1, 2)),
        "twinkle": random.uniform(0.55, 1.0),
        "color": pale_color,
    }
    if star is None:
        return data
    star.update(data)
    return star


def ensure_starfield(count=190):
    while len(STARFIELD) < count:
        STARFIELD.append(reset_star())
    if len(STARFIELD) > count:
        del STARFIELD[count:]


def reusable_starfield_surface():
    global STARFIELD_SURFACE
    if STARFIELD_SURFACE is None or STARFIELD_SURFACE.get_size() != (WIDTH, HEIGHT):
        STARFIELD_SURFACE = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    STARFIELD_SURFACE.fill((0, 0, 0, 0))
    return STARFIELD_SURFACE


def draw_zoom_starfield():
    ensure_starfield()
    stars = reusable_starfield_surface()
    cx, cy = STAR_CENTER
    edge_limit = math.hypot(WIDTH, HEIGHT)
    for star in STARFIELD:
        star["radius"] += star["speed"]
        star["speed"] = min(8.8, star["speed"] * 1.004)
        angle = star["angle"]
        dx, dy = math.cos(angle), math.sin(angle)
        x = cx + dx * star["radius"]
        y = cy + dy * star["radius"]
        if x < -28 or x > WIDTH + 28 or y < -28 or y > HEIGHT + 28 or star["radius"] > edge_limit:
            reset_star(star)
            continue
        tail = min(18.0, 2.5 + star["radius"] * 0.026)
        alpha = int(min(235, 58 + star["radius"] * 0.18) * star["twinkle"])
        start = (int(x - dx * tail), int(y - dy * tail))
        end = (int(x), int(y))
        color = star.get("color", (250, 253, 255))
        trail_color = blend((210, 238, 255), color, 0.45)
        pygame.draw.line(stars, trail_color + (max(24, alpha // 3),), start, end, star["size"])
        pygame.draw.circle(stars, color + (alpha,), end, star["size"])
    SCREEN.blit(stars, (0, 0))


def static_background_base():
    tdata = theme()
    key = (current_theme_key, WIDTH, HEIGHT, theme().get("background"))
    cached = BACKGROUND_BASE_CACHE.get(key)
    if cached is not None:
        return cached
    image = themed_background_image()
    if image:
        base = cover_image_surface(image, SCREEN.get_rect())
    else:
        base = pygame.Surface((WIDTH, HEIGHT)).convert()
        for y in range(HEIGHT):
            t = y / max(1, HEIGHT - 1)
            color = blend(tdata["bg_top"], tdata["bg_bottom"], min(1.0, t * 1.25))
            pygame.draw.line(base, color, (0, y), (WIDTH, y))
    BACKGROUND_BASE_CACHE[key] = base
    return base


def static_background_overlay():
    if theme_clears_background_overlay():
        return None
    tdata = theme()
    key = (current_theme_key, WIDTH, HEIGHT, BOARD_RECT.x, BOARD_RECT.y, BOARD_RECT.width, BOARD_RECT.height)
    cached = BACKGROUND_OVERLAY_CACHE.get(key)
    if cached is not None:
        return cached
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    accent = tdata["accent_2"]
    for r in range(460, 0, -18):
        alpha = max(0, int(28 * (r / 460) ** 2))
        pygame.draw.circle(overlay, accent + (alpha,), (int(WIDTH * 0.72), 90), r)
    for r in range(390, 0, -18):
        alpha = max(0, int(22 * (r / 390) ** 2))
        pygame.draw.circle(overlay, tdata["accent"] + (alpha,), (int(WIDTH * 0.2), 12), r)

    for x in range(0, WIDTH, 54):
        pygame.draw.line(overlay, tdata["grid"], (x, 0), (x, HEIGHT), 1)
    for y in range(0, HEIGHT, 54):
        alpha = max(0, 24 - int(y / HEIGHT * 18))
        base = tdata["grid_alt"]
        pygame.draw.line(overlay, base[:3] + (min(base[3], alpha),), (0, y), (WIDTH, y), 1)
    decor = tdata.get("decor")
    if decor == "atomic":
        for cx, cy, radius in ((112, 168, 42), (1240, 688, 58), (1150, 210, 34)):
            pygame.draw.circle(overlay, tdata["accent"] + (28,), (cx, cy), radius, 1)
            pygame.draw.line(overlay, tdata["accent_2"] + (22,), (cx - radius, cy), (cx + radius, cy), 1)
    elif decor == "mod":
        for rect in (pygame.Rect(72, 120, 170, 74), pygame.Rect(1120, 126, 190, 82), pygame.Rect(94, 712, 210, 58)):
            pygame.draw.rect(overlay, tdata["accent_2"] + (18,), rect, 2, border_radius=12)
    elif decor == "rocket":
        for x in (72, 1284):
            for y in range(120, 760, 72):
                pygame.draw.ellipse(overlay, tdata["accent"] + (22,), pygame.Rect(x, y, 8, 22))
    elif decor == "crt":
        for y in range(0, HEIGHT, 4):
            pygame.draw.line(overlay, (255, 255, 255, 10), (0, y), (WIDTH, y), 1)
    halo = pygame.Surface((BOARD_RECT.width + 18, BOARD_RECT.height + 18), pygame.SRCALPHA)
    pygame.draw.rect(halo, tdata["accent_2"] + (34,), halo.get_rect(), border_radius=2)
    overlay.blit(halo, (BOARD_RECT.x - 9, BOARD_RECT.y - 9))
    BACKGROUND_OVERLAY_CACHE[key] = overlay
    return overlay


def draw_metal_background():
    SCREEN.blit(static_background_base(), (0, 0))
    draw_zoom_starfield()
    overlay = static_background_overlay()
    if overlay:
        SCREEN.blit(overlay, (0, 0))


def draw_glass_rect(rect, fill=None, border=None, radius=2):
    tdata = theme()
    if fill is None:
        fill = tdata["panel"]
    if border is None:
        border = tdata["panel_border"]
    fill_alpha = fill[3] if len(fill) > 3 else 255
    if fill_alpha <= 0 and theme_clears_structural_panels():
        return
    key = (current_theme_key, rect.width, rect.height, tuple(fill), tuple(border), radius, tdata["accent_2"])
    cached = GLASS_RECT_CACHE.get(key)
    if cached is None:
        cached = pygame.Surface((rect.width + 12, rect.height + 12), pygame.SRCALPHA)
        if fill_alpha > 0:
            pygame.draw.rect(cached, tdata["accent_2"] + (30,), cached.get_rect(), 2, border_radius=radius + 6)
        inner = pygame.Rect(6, 6, rect.width, rect.height)
        if fill_alpha > 0:
            pygame.draw.rect(cached, fill, inner, border_radius=radius)
        pygame.draw.rect(cached, border, inner, 2, border_radius=radius)
        if fill_alpha > 0:
            pygame.draw.rect(cached, (255, 255, 255, 24), inner.inflate(-2, -2), 1, border_radius=radius)
        GLASS_RECT_CACHE[key] = cached
    SCREEN.blit(cached, (rect.x - 6, rect.y - 6))


def draw_polygon_gradient(surface, points, color):
    point_key = tuple((int(round(p[0])), int(round(p[1]))) for p in points)
    cache_key = (point_key, tuple(color))
    cached = SHAPE_GRADIENT_CACHE.get(cache_key)
    if cached is not None:
        try:
            SHAPE_GRADIENT_CACHE_ORDER.remove(cache_key)
        except ValueError:
            pass
        SHAPE_GRADIENT_CACHE_ORDER.append(cache_key)
        grad, pos = cached
        surface.blit(grad, pos)
        return
    min_x = max(0, min(p[0] for p in point_key) - 2)
    max_x = min(WIDTH, max(p[0] for p in point_key) + 3)
    min_y = max(0, min(p[1] for p in point_key) - 2)
    max_y = min(HEIGHT, max(p[1] for p in point_key) + 3)
    w, h = max(1, max_x - min_x), max(1, max_y - min_y)
    shifted = [(p[0] - min_x, p[1] - min_y) for p in point_key]
    grad = pygame.Surface((w, h), pygame.SRCALPHA)
    top = brighten(color, 0.28)
    bottom = darken(color, 0.24)
    for y in range(h):
        t = y / max(1, h - 1)
        line_color = blend(top, bottom, t)
        pygame.draw.line(grad, line_color + (230,), (0, y), (w, y))
    mask = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.polygon(mask, (255, 255, 255, 255), shifted)
    grad.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    pos = (min_x, min_y)
    SHAPE_GRADIENT_CACHE[cache_key] = (grad, pos)
    SHAPE_GRADIENT_CACHE_ORDER.append(cache_key)
    while len(SHAPE_GRADIENT_CACHE_ORDER) > SHAPE_GRADIENT_CACHE_LIMIT:
        oldest_key = SHAPE_GRADIENT_CACHE_ORDER.popleft()
        SHAPE_GRADIENT_CACHE.pop(oldest_key, None)
    surface.blit(grad, pos)


def circuit_glow_surface():
    global CIRCUIT_GLOW_SURFACE
    if CIRCUIT_GLOW_SURFACE is None:
        CIRCUIT_GLOW_SURFACE = pygame.Surface((58, 58), pygame.SRCALPHA)
        pygame.draw.circle(CIRCUIT_GLOW_SURFACE, (255, 255, 255, 42), (29, 29), 24)
        pygame.draw.circle(CIRCUIT_GLOW_SURFACE, (255, 255, 255, 78), (29, 29), 16)
    return CIRCUIT_GLOW_SURFACE


def draw_shape_circuit(piece_idx, piece, shared):
    center = centroid(piece["points"])
    cx, cy = int(center[0]), int(center[1])
    lit_any = False
    for a, b in side_list(piece["points"]):
        key = edge_key(a, b)
        entries = shared.get(key, [])
        lit = False
        open_shared = key in GAME.open_walls and len(entries) == 2
        if open_shared:
            other_idx = entries[0][0] if entries[1][0] == piece_idx else entries[1][0]
            lit = GAME.pieces[other_idx].get("owner") == piece.get("owner")
            if not lit:
                continue
        if lit:
            lit_any = True
        side_mid = midpoint(a, b)
        pygame.draw.line(SCREEN, WHITE if lit else (2, 4, 8), center, side_mid, 3 if lit else 2)

    if lit_any:
        SCREEN.blit(circuit_glow_surface(), (cx - 29, cy - 29))
        pygame.draw.circle(SCREEN, WHITE, (cx, cy), ZOID_RADIUS)
        pygame.draw.circle(SCREEN, (210, 230, 255), (cx - 3, cy - 3), 3)
    else:
        pygame.draw.circle(SCREEN, (42, 45, 50), (cx, cy), ZOID_RADIUS)
        pygame.draw.circle(SCREEN, (4, 6, 10), (cx, cy), ZOID_RADIUS, 2)


def draw_open_wall_gaps(shared):
    # Open walls are invisible because draw_board and draw_shape_circuit skip
    # them before drawing. Do not paint over them with a fake board color:
    # themed boards are layered and a flat "eraser" leaves visible artifacts.
    return


def static_board_grid():
    tdata = theme()
    key = (current_theme_key, BOARD_RECT.width, BOARD_RECT.height, tdata["grid"], tdata["grid_alt"])
    cached = BOARD_GRID_CACHE.get(key)
    if cached is not None:
        return cached
    board_grid = pygame.Surface((BOARD_RECT.width, BOARD_RECT.height), pygame.SRCALPHA)
    for x in range(0, BOARD_RECT.width, 54):
        pygame.draw.line(board_grid, tdata["grid"], (x, 0), (x, BOARD_RECT.height), 1)
    for y in range(0, BOARD_RECT.height, 54):
        pygame.draw.line(board_grid, tdata["grid_alt"], (0, y), (BOARD_RECT.width, y), 1)
    BOARD_GRID_CACHE[key] = board_grid
    return board_grid


def draw_metal_panel(rect):
    tdata = theme()
    if theme_clears_structural_panels():
        return
    key = (current_theme_key, rect.width, rect.height, tdata["panel"], tdata["panel_2"], tdata["panel_border"])
    panel = METAL_PANEL_CACHE.get(key)
    if panel is None:
        panel = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        top = tdata["panel"][:3]
        bottom = tdata["panel_2"][:3]
        alpha = max(tdata["panel"][3], tdata["panel_2"][3])
        for y in range(rect.height):
            t = y / max(1, rect.height - 1)
            color = blend(top, bottom, t)
            pygame.draw.line(panel, color + (alpha,), (0, y), (rect.width, y))
        pygame.draw.rect(panel, tdata["panel_border"], panel.get_rect(), 1, border_radius=2)
        pygame.draw.rect(panel, (255, 255, 255, 14), panel.get_rect().inflate(-2, -2), 1, border_radius=2)
        METAL_PANEL_CACHE[key] = panel
    SCREEN.blit(panel, rect.topleft)


# ---------- Game state ----------


class Game:
    def __init__(self):
        self.mode = "setup"
        self.previous_mode = "setup"
        self.help_return_mode = "setup"
        gameplay_settings = PLAYER_SETTINGS.get("gameplay", {}) if isinstance(PLAYER_SETTINGS, dict) else {}
        audio_settings = PLAYER_SETTINGS.get("audio", {}) if isinstance(PLAYER_SETTINGS, dict) else {}
        self.player_count = int(gameplay_settings.get("player_count", 2))
        self.player_count = max(1, min(6, self.player_count))
        self.ai_players = {
            int(i)
            for i in gameplay_settings.get("ai_players", [1])
            if isinstance(i, int) or str(i).isdigit()
        }
        self.ai_players = {i for i in self.ai_players if 0 < i < self.player_count}
        if not self.ai_players and self.player_count > 1:
            self.ai_players.add(1)
        self.player_color_indices = list(range(6))
        self.players = []
        self.deck = []
        self.discard = []
        self.hands = []
        self.pieces = []
        self.zoids = []
        self.next_zoid_id = 1
        self.open_walls = set()
        self._shared_edges_signature = None
        self._shared_edges_cache = None
        self._wall_plane_geometry_version = 0
        self._wall_plane_cache_version = -1
        self._wall_plane_cache = ()
        self.current_player = 0
        self.selected_card = None
        self.cards_used_this_turn = 0
        self.discarded_this_turn = False
        self.last_card_drawn = False
        self.no_discard_turns_after_empty = 0
        self.state_revision = 0
        self.action_log = []
        self.music_enabled = bool(audio_settings.get("music_enabled", True))
        self.music_loaded = False
        self.round_scores = []
        self.total_scores = []
        self.round_light_scores = []
        self.last_score_breakdown = []
        self.round_slots = []
        self.round_wild_kind = None
        self.slot_show_until = 0
        self.ai_next_action_at = 0
        self.ai_pending_advance = False
        self.ai_wait_started_at = 0
        self.ai_wait_player = None
        self.turn_started_at = 0
        self.next_ufo_at = 0
        self.ufo_flight_index = 0
        self.active_ufo = None
        self.explosions = []
        self.player_actions = {}
        self.message = "Choose players, then Start."
        self.card_rects = []
        self.setup_buttons = []
        self.settings_buttons = []
        self.gear_rect = pygame.Rect(WIDTH - 64, 18, 42, 42)
        self.back_button = pygame.Rect(WIDTH // 2 - 110, HEIGHT - 104, 220, 42)
        self.new_game_button = pygame.Rect(WIDTH // 2 - 110, HEIGHT - 154, 220, 42)
        self.start_button = pygame.Rect(WIDTH // 2 - 110, HEIGHT // 2 + 170, 220, 46)
        self.help_button = pygame.Rect(WIDTH // 2 + 18, HEIGHT // 2 + 170, 220, 46)
        self.score_help_button = pygame.Rect(WIDTH // 2 - 110, HEIGHT - 194, 220, 42)
        self.score_help_popup = False
        self.online_button = pygame.Rect(WIDTH // 2 - 110, HEIGHT // 2 + 224, 220, 46)
        self.next_round_button = pygame.Rect(WIDTH // 2 - 110, HEIGHT - 142, 220, 46)
        self.discard_button = pygame.Rect(WIDTH - RIGHT_W + 18, HEIGHT - 178, RIGHT_W - 36, 36)
        self.end_turn_button = pygame.Rect(WIDTH - RIGHT_W + 18, HEIGHT - 136, RIGHT_W - 36, 36)
        self.ai_button = pygame.Rect(WIDTH - RIGHT_W + 18, HEIGHT - 94, RIGHT_W - 36, 36)
        self.online_buttons = []
        self.online_server_url = configured_network_server_url()
        self.online_server_input = self.online_server_url
        self.online_room_code_input = ""
        self.online_player_name = (os.environ.get("SHAPE_AZOID_PLAYER_NAME") or getpass.getuser() or "Player").strip()
        self.online_player_name_input = self.online_player_name
        self.online_focus = "room_code" if self.online_server_url else "server"
        self.online_room_code = None
        self.online_seat_token = None
        self.online_lobby = None
        self.online_rooms = []
        self.online_status = "Click Create to host, or type the host server address and room code to join."
        self.online_viewer_player = None
        self.online_last_refresh_ms = 0
        self.online_join_in_progress = False
        self.online_create_in_progress = False
        self.startup_online_create = False
        self.online_share_server = ""
        self.online_server_process = None
        self.online_server_log = None
        self.online_ws_thread = None
        self.online_ws_stop = threading.Event()
        self.online_ws_lock = threading.Lock()
        self.online_ws_pending = None
        self.online_ws_url = ""
        self.online_ws_connected = False
        self.online_ws_status = ""
        self.online_ws_last_frame_ms = 0
        self.telemetry = RuntimeTelemetry()
        self.telemetry_next_state_ms = 0
        self.telemetry_last_slow_frame_ms = 0
        self.setup()

    def open_settings(self):
        if self.mode != "settings":
            self.previous_mode = self.mode
        self.mode = "settings"
        play_note("pluck")

    def close_settings(self):
        save_player_settings(self)
        self.mode = self.previous_mode if self.previous_mode in ("setup", "online", "online_playing", "playing", "score", "help") else "setup"
        play_note("pluck")

    def open_help(self):
        if self.mode != "help":
            self.help_return_mode = self.mode
        self.mode = "help"
        play_note("pluck")

    def close_help(self):
        self.mode = self.help_return_mode if self.help_return_mode in ("setup", "online", "online_playing", "settings", "playing", "score") else "setup"
        play_note("pluck")

    def open_online(self):
        self.previous_mode = self.mode
        self.mode = "online"
        if self.startup_online_create and not self.online_room_code:
            self.online_status = "Creating host room..."
            self.create_online_room()
        else:
            self.online_status = "Click Create to host, or type the host server address and room code to join."
        play_note("pluck")

    def close_online(self):
        self.stop_online_stream()
        self.online_room_code = None
        self.online_room_code_input = ""
        self.online_seat_token = None
        self.online_lobby = None
        self.online_viewer_player = None
        self.online_join_in_progress = False
        self.online_create_in_progress = False
        self.mode = "setup"
        self.message = "Choose players, then Start."
        play_note("pluck")

    def online_player_display_name(self):
        name = (self.online_player_name_input or self.online_player_name or "Player").strip()
        if not name:
            name = "Player"
        self.online_player_name = name
        self.online_player_name_input = name
        return name

    def online_client(self, timeout=None):
        if ShapeAzoidHttpClient is None:
            raise RuntimeError("Online client code is not available.")
        self.apply_online_server_input()
        if not self.online_server_url:
            raise RuntimeError("Type the host server address first.")
        return ShapeAzoidHttpClient(self.online_server_url, timeout=timeout or 5.0)

    def online_websocket_url(self):
        return websocket_room_url(self.online_server_url, self.online_room_code, self.online_seat_token)

    def stop_online_stream(self, join=True, clear_pending=True):
        self.online_ws_stop.set()
        thread = self.online_ws_thread
        if join and thread is not None and thread.is_alive():
            thread.join(timeout=1.0)
        if thread is not None and not thread.is_alive():
            self.online_ws_thread = None
        with self.online_ws_lock:
            self.online_ws_connected = False
            if clear_pending:
                self.online_ws_pending = None

    def start_online_stream(self):
        if websocket_connect is None:
            self.online_ws_status = "WebSocket client is not available."
            return False
        ws_url = self.online_websocket_url()
        if not ws_url:
            return False
        thread = self.online_ws_thread
        if thread is not None and thread.is_alive() and self.online_ws_url == ws_url:
            return True
        if thread is not None and thread.is_alive():
            self.stop_online_stream(join=True, clear_pending=True)
        self.online_ws_url = ws_url
        self.online_ws_stop = threading.Event()
        with self.online_ws_lock:
            self.online_ws_pending = None
            self.online_ws_connected = False
            self.online_ws_status = "Connecting live stream..."
        self.online_ws_thread = threading.Thread(
            target=self._online_stream_worker,
            args=(ws_url, self.online_ws_stop),
            name="ShapeAzoidWebSocket",
            daemon=True,
        )
        self.online_ws_thread.start()
        return True

    def _online_stream_worker(self, ws_url, stop_event):
        while not stop_event.is_set():
            try:
                with websocket_connect(ws_url, open_timeout=1.5, close_timeout=0.5) as websocket:
                    with self.online_ws_lock:
                        self.online_ws_connected = True
                        self.online_ws_status = "Live stream connected."
                    while not stop_event.is_set():
                        try:
                            raw = websocket.recv(timeout=0.5)
                        except TimeoutError:
                            continue
                        payload = json.loads(raw)
                        with self.online_ws_lock:
                            self.online_ws_pending = payload
                            self.online_ws_connected = True
                            self.online_ws_status = "Live stream connected."
            except Exception as exc:
                with self.online_ws_lock:
                    self.online_ws_connected = False
                    self.online_ws_status = f"Live stream retrying: {self.online_error_text(exc)}"
                stop_event.wait(1.0)

    def consume_online_stream(self):
        with self.online_ws_lock:
            payload = self.online_ws_pending
            self.online_ws_pending = None
        if not payload:
            return False
        if payload.get("type") == "error":
            self.message = payload.get("error", "Online live stream failed.")
            return False
        if payload.get("room_code") and payload.get("room_code") != self.online_room_code:
            return False
        if payload.get("phase") == "playing":
            self.apply_online_snapshot(payload)
            self.apply_online_mode(payload)
        else:
            self.online_lobby = payload
            if self.mode == "online_playing":
                self.mode = "online"
        self.online_ws_last_frame_ms = pygame.time.get_ticks()
        return True

    def apply_online_mode(self, payload):
        state = payload.get("state", payload) if isinstance(payload, dict) else {}
        state_mode = state.get("mode")
        if state_mode == "score":
            self.mode = "score"
        elif payload.get("phase") == "playing":
            self.mode = "online_playing"
        else:
            self.mode = "online"

    def online_stream_healthy(self):
        if not self.online_ws_connected or self.online_ws_last_frame_ms <= 0:
            return False
        return pygame.time.get_ticks() - self.online_ws_last_frame_ms < 1800

    def apply_online_server_input(self):
        source = self.online_server_input or self.online_server_url
        normalized = normalize_server_url(source)
        if normalized:
            self.online_server_url = normalized
            self.online_server_input = normalized
            return True
        self.online_server_url = ""
        return False

    def online_error_text(self, exc):
        payload = getattr(exc, "payload", None)
        if isinstance(payload, dict):
            detail = payload.get("detail")
            if isinstance(detail, dict):
                return str(detail.get("error") or detail.get("detail") or detail)
            if detail:
                return str(detail)
        return str(exc)

    def online_server_ready(self, base_url=None):
        if ShapeAzoidHttpClient is None:
            return False
        url = normalize_server_url(base_url or self.online_server_url)
        if not url:
            return False
        try:
            return bool(ShapeAzoidHttpClient(url, timeout=1.0).health().get("ok"))
        except Exception:
            return False

    def choose_local_online_server_url(self):
        port = 8765 if can_bind_local_port(8765) else free_local_port()
        return f"http://127.0.0.1:{port}", True, ""

    def start_local_online_server(self):
        if self.online_server_process is not None and self.online_server_ready():
            return True
        if self.online_server_process is not None and self.online_server_process.poll() is not None:
            self.online_server_process = None
        python_exe = local_online_python()
        if not python_exe:
            self.online_status = "Online host needs requirements installed first."
            return False
        base_url, should_start, problem = self.choose_local_online_server_url()
        if problem:
            self.online_status = problem
            return False
        self.online_server_url = base_url
        self.online_server_input = base_url
        if should_start:
            try:
                log_path = os.path.join(support_dir(), "shape_azoid_online_server.log")
                self.online_server_log = open(log_path, "w", encoding="utf-8")
                port = urlparse(base_url).port or 8765
                self.online_server_process = subprocess.Popen(
                    [
                        python_exe,
                        "-m",
                        "uvicorn",
                        "network.shape_azoid_server:app",
                        "--host",
                        "0.0.0.0",
                        "--port",
                        str(port),
                        "--log-level",
                        "warning",
                    ],
                    cwd=support_dir(),
                    stdout=self.online_server_log,
                    stderr=subprocess.STDOUT,
                )
            except Exception as exc:
                self.online_status = f"Server start failed: {self.online_error_text(exc)}"
                return False
            deadline = time.time() + 12.0
            while time.time() < deadline:
                if self.online_server_ready(base_url):
                    break
                time.sleep(0.2)
            else:
                self.online_status = "Online server did not become ready."
                return False
        port = urlparse(base_url).port or 8765
        share_url = f"http://{local_lan_ip()}:{port}"
        self.online_share_server = share_url
        if self.online_server_ready(share_url):
            self.online_server_url = share_url
            self.online_server_input = share_url
        try:
            write_online_address_files(share_url)
        except OSError:
            pass
        return True

    def refresh_online_rooms(self):
        try:
            payload = self.online_client(timeout=ONLINE_HTTP_TIMEOUT).list_rooms()
            self.online_rooms = payload.get("rooms", [])
            self.online_status = f"Found {len(self.online_rooms)} room(s)."
        except Exception as exc:
            self.online_rooms = []
            self.online_status = f"Server not ready: {self.online_error_text(exc)}"

    def create_online_room(self):
        if self.online_create_in_progress:
            self.online_status = "Create is already in progress."
            return
        if self.online_room_code and self.online_seat_token:
            self.refresh_online_lobby()
            self.online_status = f"Already in room {self.online_room_code}. Use Back first to leave this lobby."
            return
        self.online_create_in_progress = True
        if not self.start_local_online_server():
            self.online_create_in_progress = False
            return
        try:
            payload = self.online_client(timeout=ONLINE_HTTP_TIMEOUT).create_room(
                host_name=self.online_player_display_name() or "Host",
                player_count=self.player_count,
                ai_players=sorted(self.ai_players),
                start=False,
            )
            self.online_room_code = payload["room_code"]
            self.online_room_code_input = self.online_room_code
            self.online_seat_token = payload["host_seat_token"]
            share = f" Give joiners: {self.online_share_server}" if self.online_share_server else ""
            self.online_status = f"Created room {self.online_room_code}.{share}"
            self.refresh_online_lobby()
            if self.online_share_server:
                self.online_status = f"Room {self.online_room_code}. Give joiners: {self.online_share_server}"
        except Exception as exc:
            self.online_status = f"Create failed: {self.online_error_text(exc)}"
        finally:
            self.online_create_in_progress = False

    def join_online_room(self):
        code = self.online_room_code_input.strip().upper()
        if not code:
            self.online_status = "Type a room code first."
            return
        if not self.apply_online_server_input():
            self.online_status = "Type the host server address first."
            self.online_focus = "server"
            return
        if self.online_join_in_progress:
            self.online_status = "Join is already in progress."
            return
        if self.online_room_code == code and self.online_seat_token:
            self.refresh_online_lobby()
            self.online_status = f"Already joined room {code}."
            return
        self.online_join_in_progress = True
        try:
            payload = self.online_client(timeout=ONLINE_HTTP_TIMEOUT).join_room(
                code,
                player_name=self.online_player_display_name() or None,
                seat_token=self.online_seat_token,
            )
            self.online_room_code = payload["room_code"]
            self.online_room_code_input = self.online_room_code
            self.online_seat_token = payload["seat_token"]
            self.online_status = f"Joined room {self.online_room_code}."
            self.refresh_online_lobby()
        except Exception as exc:
            self.online_status = f"Join failed: {self.online_error_text(exc)}"
        finally:
            self.online_join_in_progress = False

    def cycle_online_seat_color(self):
        if not self.online_room_code or not self.online_seat_token or not self.online_lobby:
            self.online_status = "Join a lobby before choosing a color."
            return
        viewer = self.online_lobby.get("viewer_player")
        seats = self.online_lobby.get("seats", [])
        if viewer is None or not (0 <= viewer < len(seats)):
            self.online_status = "Only joined players can choose a color."
            return
        if self.online_lobby.get("phase") != "lobby":
            self.online_status = "Colors are locked after the host starts."
            return
        current = int(seats[viewer].get("color_index", viewer % len(PLAYER_COLORS)))
        used = {
            int(seat.get("color_index"))
            for idx, seat in enumerate(seats)
            if idx != viewer
            and isinstance(seat.get("color_index"), int)
            and 0 <= int(seat.get("color_index")) < len(PLAYER_COLORS)
        }
        for step in range(1, len(PLAYER_COLORS) + 1):
            candidate = (current + step) % len(PLAYER_COLORS)
            if candidate in used:
                continue
            try:
                self.online_client(timeout=ONLINE_HTTP_TIMEOUT).update_seat(
                    self.online_room_code,
                    self.online_seat_token,
                    player_name=self.online_player_display_name() or None,
                    color_index=candidate,
                )
                self.online_status = f"Your online color is now {PLAYER_COLORS[candidate][0]}."
                self.refresh_online_lobby()
                play_note("pluck")
                return
            except Exception as exc:
                self.online_status = f"Color failed: {self.online_error_text(exc)}"
                return
        self.online_status = "No unused color is available."

    def refresh_online_lobby(self):
        code = (self.online_room_code or self.online_room_code_input).strip().upper()
        if not code:
            self.refresh_online_rooms()
            return
        try:
            self.online_lobby = self.online_client(timeout=ONLINE_HTTP_TIMEOUT).snapshot(code, seat_token=self.online_seat_token)
            self.online_room_code = code
            self.online_room_code_input = code
            self.online_status = f"Room {code}: {self.online_lobby.get('phase', 'unknown')}."
            if self.online_lobby.get("phase") == "playing":
                self.apply_online_snapshot(self.online_lobby)
                self.apply_online_mode(self.online_lobby)
                self.start_online_stream()
        except Exception as exc:
            self.online_lobby = None
            self.online_status = f"Refresh failed: {self.online_error_text(exc)}"

    def online_poll_interval(self):
        if (
            self.mode == "online_playing"
            and self.selected_card is not None
            and self.online_viewer_player == self.current_player
        ):
            return ONLINE_ACTIVE_SELECTION_POLL_MS
        return ONLINE_POLL_MS

    def poll_online_lobby(self):
        if not self.online_room_code or not self.online_seat_token:
            return
        now = pygame.time.get_ticks()
        if now - self.online_last_refresh_ms < self.online_poll_interval():
            return
        self.online_last_refresh_ms = now
        self.refresh_online_lobby()

    def start_online_room(self):
        if not self.online_room_code or not self.online_seat_token:
            self.online_status = "Create or join a room first."
            return
        try:
            payload = self.online_client(timeout=ONLINE_HTTP_TIMEOUT).start_room(self.online_room_code, self.online_seat_token)
            self.online_status = f"Room {payload.get('room_code', self.online_room_code)} started on the server."
            self.refresh_online_lobby()
            if self.online_lobby and self.online_lobby.get("phase") == "playing":
                self.apply_online_mode(self.online_lobby)
                self.start_online_stream()
        except Exception as exc:
            self.online_status = f"Start failed: {self.online_error_text(exc)}"

    def wall_tuple_from_snapshot(self, wall):
        if not isinstance(wall, (list, tuple)) or len(wall) != 2:
            return tuple()
        try:
            a = (float(wall[0][0]), float(wall[0][1]))
            b = (float(wall[1][0]), float(wall[1][1]))
        except (TypeError, ValueError, IndexError):
            return tuple()
        return edge_key(a, b)

    def online_ufo_time(self, value, server_time, local_now):
        if not isinstance(value, (int, float)):
            return None
        if isinstance(server_time, (int, float)):
            value = float(value)
            server_time = float(server_time)
            if value > 1000000 and server_time > 1000000:
                return int(local_now + (value - server_time))
            return int(local_now + (value - server_time) * 1000.0)
        return int(value)

    def online_ufo_event_from_snapshot(self, event, server_time):
        if not isinstance(event, dict):
            return None
        local_now = pygame.time.get_ticks()
        converted = dict(event)
        for key in ("started_at", "ends_at", "shot_at", "hit_at"):
            converted_value = self.online_ufo_time(event.get(key), server_time, local_now)
            if converted_value is not None:
                converted[key] = converted_value
        for key in ("start", "end", "target_pos"):
            value = converted.get(key)
            if isinstance(value, list):
                converted[key] = tuple(value)
        return converted

    def apply_online_snapshot(self, payload):
        state = payload.get("state", payload)
        server_time = payload.get("server_time")
        previous_selected = self.selected_card
        previous_selected_signature = None
        if (
            previous_selected is not None
            and 0 <= self.current_player < len(self.hands)
            and isinstance(self.hands[self.current_player], list)
            and 0 <= previous_selected < len(self.hands[self.current_player])
        ):
            previous_selected_signature = card_signature(self.hands[self.current_player][previous_selected])
        previous_viewer = self.online_viewer_player
        previous_current = self.current_player
        self.online_lobby = payload
        self.online_viewer_player = payload.get("viewer_player")
        self.player_count = int(state.get("player_count", 1))
        self.players = []
        for idx, player in enumerate(state.get("players", [])):
            color_idx = int(player.get("color_index", idx % len(PLAYER_COLORS)))
            self.players.append({
                "name": player.get("name") or PLAYER_COLORS[color_idx][0],
                "color_name": player.get("color_name") or PLAYER_COLORS[color_idx][0],
                "color": color_index_rgb(color_idx),
                "color_index": color_idx,
            })
        while len(self.players) < self.player_count:
            color_idx = len(self.players) % len(PLAYER_COLORS)
            self.players.append({
                "name": PLAYER_COLORS[color_idx][0],
                "color_name": PLAYER_COLORS[color_idx][0],
                "color": PLAYER_COLORS[color_idx][1],
                "color_index": color_idx,
            })
        self.player_color_indices = [player["color_index"] for player in self.players] + list(range(len(PLAYER_COLORS)))
        self.ensure_color_choices()
        self.ai_players = {
            idx for idx, player in enumerate(state.get("players", []))
            if player.get("is_ai")
        }
        self.current_player = max(0, min(self.player_count - 1, int(state.get("current_player", 0))))
        self.deck = [None] * int(state.get("deck_count", 0))
        self.discard = [dict(card) for card in state.get("discard", []) if isinstance(card, dict)]
        self.hands = []
        for entry in state.get("hands", []):
            if isinstance(entry, list):
                self.hands.append([dict(card) for card in entry if isinstance(card, dict)])
            elif isinstance(entry, dict):
                self.hands.append({"count": int(entry.get("count", 0))})
            else:
                self.hands.append({"count": 0})
        while len(self.hands) < self.player_count:
            self.hands.append({"count": 0})
        self.pieces = [
            {
                "shape": piece.get("shape", "square"),
                "points": [tuple(point) for point in piece.get("points", [])],
                "owner": piece.get("owner"),
                "played_by": piece.get("played_by"),
            }
            for piece in state.get("pieces", [])
        ]
        self.invalidate_wall_plane_geometry()
        previous_zoids = list(self.zoids)
        previous_zoids_by_id = {}
        for old in previous_zoids:
            old_id = old.get("zoid_id")
            if self.valid_zoid_id(old_id) and old_id not in previous_zoids_by_id:
                previous_zoids_by_id[old_id] = old
        matched_zoid_ids = set()
        next_zoids = []
        for idx, z in enumerate(state.get("zoids", [])):
            if not isinstance(z, dict):
                continue
            server_pos = [float(z.get("pos", [0, 0])[0]), float(z.get("pos", [0, 0])[1])]
            pos = list(server_pos)
            zoid_id = z.get("zoid_id")
            old = None
            if self.valid_zoid_id(zoid_id) and zoid_id not in matched_zoid_ids:
                old = previous_zoids_by_id.get(zoid_id)
                if old is not None:
                    matched_zoid_ids.add(zoid_id)
            elif not self.valid_zoid_id(zoid_id) and idx < len(previous_zoids):
                old = previous_zoids[idx]
            if (
                old is not None
                and old.get("kind", "zoid") == z.get("kind", "zoid")
                and old.get("owner") == z.get("owner")
                and old.get("played_by") == z.get("played_by")
                and isinstance(old.get("pos"), list)
                and len(old["pos"]) == 2
            ):
                old_pos = [float(old["pos"][0]), float(old["pos"][1])]
                gap = dist(old_pos, server_pos)
                if gap <= ONLINE_ZOID_SNAP_DISTANCE:
                    pos = [
                        old_pos[0] + (server_pos[0] - old_pos[0]) * ONLINE_ZOID_SMOOTHING,
                        old_pos[1] + (server_pos[1] - old_pos[1]) * ONLINE_ZOID_SMOOTHING,
                    ]
            next_zoids.append({
                "zoid_id": zoid_id if self.valid_zoid_id(zoid_id) else None,
                "kind": z.get("kind", "zoid"),
                "owner": z.get("owner"),
                "played_by": z.get("played_by"),
                "piece": z.get("piece"),
                "pos": pos,
                "vel": list(z.get("vel", [0, 0])),
                "visited": set(z.get("visited", [])),
            })
        self.zoids = next_zoids
        snapshot_next_id = state.get("next_zoid_id")
        stable_ids = [z["zoid_id"] for z in next_zoids if self.valid_zoid_id(z.get("zoid_id"))]
        minimum_next_id = max(stable_ids, default=0) + 1
        self.next_zoid_id = max(
            minimum_next_id,
            snapshot_next_id if self.valid_zoid_id(snapshot_next_id) else minimum_next_id,
        )
        self.open_walls = {self.wall_tuple_from_snapshot(wall) for wall in state.get("open_walls", [])}
        self.next_ufo_at = self.online_ufo_time(state.get("next_ufo_at"), server_time, pygame.time.get_ticks()) or 0
        self.ufo_flight_index = int(state.get("ufo_flight_index", self.ufo_flight_index))
        self.active_ufo = self.online_ufo_event_from_snapshot(state.get("active_ufo"), server_time)
        self.explosions = []
        local_now = pygame.time.get_ticks()
        for explosion in state.get("explosions", []):
            if not isinstance(explosion, dict):
                continue
            started_at = self.online_ufo_time(explosion.get("started_at"), server_time, local_now)
            if started_at is None:
                started_at = int(explosion.get("started_at", local_now))
            pos = explosion.get("pos", [0, 0])
            self.explosions.append({
                "pos": tuple(pos) if isinstance(pos, list) else pos,
                "started_at": started_at,
                "duration": int(explosion.get("duration", 760)),
            })
        self.round_slots = list(state.get("round_slots", []))
        self.round_wild_kind = state.get("round_wild_kind")
        self.cards_used_this_turn = int(state.get("cards_used_this_turn", 0))
        self.last_card_drawn = bool(state.get("last_card_drawn", False))
        self.no_discard_turns_after_empty = int(state.get("no_discard_turns_after_empty", 0))
        self.action_log = list(state.get("action_log", []))
        self.state_revision = int(state.get("state_revision", 0))
        self.round_scores = [int(player.get("score_round", 0)) for player in state.get("players", [])]
        self.total_scores = [int(player.get("score_total", 0)) for player in state.get("players", [])]
        while len(self.round_scores) < self.player_count:
            self.round_scores.append(0)
        while len(self.total_scores) < self.player_count:
            self.total_scores.append(0)
        self.round_light_scores = [0] * self.player_count
        self.last_score_breakdown = [
            dict(parts) for parts in state.get("last_score_breakdown", [])
            if isinstance(parts, dict)
        ]
        self.message = state.get("message", "Online room synchronized.")
        self.selected_card = None
        if (
            previous_selected is not None
            and previous_viewer == self.online_viewer_player
            and previous_current == self.current_player
            and self.online_viewer_player == self.current_player
            and 0 <= self.current_player < len(self.hands)
            and isinstance(self.hands[self.current_player], list)
            and 0 <= previous_selected < len(self.hands[self.current_player])
            and card_signature(self.hands[self.current_player][previous_selected]) == previous_selected_signature
        ):
            self.selected_card = previous_selected
        self.online_last_refresh_ms = pygame.time.get_ticks()

    def refresh_online_game(self):
        if not self.online_room_code:
            self.mode = "online"
            self.online_status = "No online room selected."
            return
        try:
            payload = self.online_client(timeout=ONLINE_HTTP_TIMEOUT).snapshot(self.online_room_code, seat_token=self.online_seat_token)
            if payload.get("phase") == "playing":
                self.apply_online_snapshot(payload)
                self.apply_online_mode(payload)
                self.start_online_stream()
            else:
                self.stop_online_stream()
                self.online_lobby = payload
                self.mode = "online"
        except Exception as exc:
            self.message = f"Online refresh failed: {self.online_error_text(exc)}"

    def online_line_command_diagnostics(self, command):
        if not isinstance(command, dict) or command.get("type") != "play_at":
            return None
        pos = command.get("pos")
        if not pos or len(pos) != 2:
            return None
        try:
            card_index = int(command.get("card_index", -1))
        except (TypeError, ValueError):
            return None
        if not (0 <= self.current_player < len(self.hands)):
            return None
        hand = self.hands[self.current_player]
        if not isinstance(hand, list) or not (0 <= card_index < len(hand)):
            return None
        if card_kind(hand[card_index]) != "line":
            return None
        return self.line_click_diagnostics((float(pos[0]), float(pos[1])))

    def send_online_command(self, command):
        command_type = command.get("type") if isinstance(command, dict) else None
        if command_type != "next_round" and self.online_viewer_player != self.current_player:
            self.message = "Waiting for the current online player."
            return
        if command_type in {"play_at", "discard", "cycle_wild"} and command.get("card_index") is None:
            self.message = "Select a card first."
            return
        started = time.perf_counter()
        line_debug = self.online_line_command_diagnostics(command)
        try:
            result = self.online_client(timeout=ONLINE_COMMAND_TIMEOUT).apply_command(
                self.online_room_code,
                self.online_seat_token,
                command,
            )
            elapsed_ms = (time.perf_counter() - started) * 1000.0
            self.message = result.get("message", "Online command sent.")
            self.telemetry_event("online_command", {
                "ok": True,
                "command_type": command_type,
                "elapsed_ms": round(elapsed_ms, 2),
                "state_revision": result.get("state_revision"),
                "line_debug_client": line_debug,
                "line_debug_server": result.get("line_debug"),
                "state": self.telemetry_snapshot(),
            })
            if result.get("state"):
                self.apply_online_snapshot(result)
                self.apply_online_mode(result)
            else:
                self.refresh_online_game()
        except Exception as exc:
            elapsed_ms = (time.perf_counter() - started) * 1000.0
            payload = getattr(exc, "payload", None)
            self.telemetry_event("online_command", {
                "ok": False,
                "command_type": command_type,
                "elapsed_ms": round(elapsed_ms, 2),
                "error": self.online_error_text(exc),
                "payload": payload,
                "line_debug_client": line_debug,
                "state": self.telemetry_snapshot(),
            })
            self.message = f"Online command failed: {self.online_error_text(exc)}"

    def return_to_start(self):
        self.stop_online_stream()
        self.mode = "setup"
        self.previous_mode = "setup"
        self.reset_match_sync_state()
        self.setup()
        self.message = "Choose players, then Start."
        play_note("pluck")

    def cycle_display_mode(self):
        global display_mode
        modes = ["windowed", "fullscreen", "windowed_fullscreen"]
        idx = modes.index(display_mode) if display_mode in modes else 0
        display_mode = modes[(idx + 1) % len(modes)]
        apply_display_mode()
        labels = {"windowed": "Windowed", "fullscreen": "Full Screen", "windowed_fullscreen": "Windowed Full Screen"}
        self.message = f"Display: {labels[display_mode]}."
        save_player_settings(self)

    def cycle_theme(self):
        global current_theme_key
        keys = list(THEMES.keys())
        idx = keys.index(current_theme_key) if current_theme_key in keys else 0
        current_theme_key = keys[(idx + 1) % len(keys)]
        self.message = f"Theme: {THEMES[current_theme_key]['name']}."
        play_note("pluck")
        save_player_settings(self)

    def setup(self):
        self.ensure_color_choices()
        self.players = [
            {"name": PLAYER_COLORS[color_idx][0], "color_name": PLAYER_COLORS[color_idx][0], "color": PLAYER_COLORS[color_idx][1], "color_index": color_idx}
            for color_idx in self.player_color_indices[:self.player_count]
        ]
        if len(self.total_scores) != self.player_count:
            self.total_scores = [0] * self.player_count
        self.reset_round()

    def ensure_color_choices(self):
        used = []
        for color_idx in self.player_color_indices:
            if color_idx not in used and 0 <= color_idx < len(PLAYER_COLORS):
                used.append(color_idx)
        for color_idx in range(len(PLAYER_COLORS)):
            if color_idx not in used:
                used.append(color_idx)
        self.player_color_indices = used[:len(PLAYER_COLORS)]

    def cycle_player_color(self, player_idx):
        if not (0 <= player_idx < self.player_count):
            return
        used = set(self.player_color_indices[:self.player_count])
        current = self.player_color_indices[player_idx]
        used.discard(current)
        for step in range(1, len(PLAYER_COLORS) + 1):
            candidate = (current + step) % len(PLAYER_COLORS)
            if candidate not in used:
                self.player_color_indices[player_idx] = candidate
                self.setup()
                self.message = f"Player {player_idx + 1} is now {PLAYER_COLORS[candidate][0]}."
                play_note("pluck")
                return

    @property
    def current_color_index(self):
        return self.players[self.current_player]["color_index"]

    def player_index_for_color(self, color_index):
        for idx, player in enumerate(self.players):
            if player["color_index"] == color_index:
                return idx
        return None

    def set_player_action(self, player_idx, action, duration_ms=2600):
        if not (0 <= player_idx < self.player_count):
            return
        self.player_actions[player_idx] = {
            "action": action,
            "until": pygame.time.get_ticks() + duration_ms,
        }

    def player_action(self, player_idx):
        state = self.player_actions.get(player_idx)
        if not state:
            return None
        if pygame.time.get_ticks() >= state["until"]:
            self.player_actions.pop(player_idx, None)
            return None
        return state["action"]

    def reset_match_sync_state(self):
        self.state_revision = 0
        self.action_log = []

    def record_action(self, actor, command_type, payload):
        self.state_revision += 1
        self.action_log.append({
            "revision": self.state_revision,
            "actor": actor,
            "type": command_type,
            "payload": payload,
            "message": self.message,
        })
        if len(self.action_log) > MAX_ACTION_LOG:
            self.action_log = self.action_log[-MAX_ACTION_LOG:]

    def telemetry_event(self, kind, data=None):
        if hasattr(self, "telemetry") and self.telemetry is not None:
            self.telemetry.write(kind, data or {})

    def shared_wall_counts(self):
        shared = self.shared_edges() if self.pieces else {}
        shared_count = 0
        open_count = 0
        closed_count = 0
        for key, entries in shared.items():
            if len(entries) != 2:
                continue
            shared_count += 1
            if key in self.open_walls:
                open_count += 1
            else:
                closed_count += 1
        return shared_count, open_count, closed_count

    def telemetry_snapshot(self, frame_ms=None, phase_times=None):
        shared_count, open_count, closed_count = self.shared_wall_counts()
        hand_size = None
        if 0 <= self.current_player < len(self.hands):
            hand = self.hands[self.current_player]
            hand_size = len(hand) if isinstance(hand, list) else hand.get("count")
        ws_age = None
        if self.online_ws_last_frame_ms:
            ws_age = max(0, pygame.time.get_ticks() - self.online_ws_last_frame_ms)
        data = {
            "mode": self.mode,
            "message": str(self.message)[:180],
            "fps": round(float(CLOCK.get_fps()), 1),
            "frame_ms": round(float(frame_ms), 2) if frame_ms is not None else None,
            "player_count": self.player_count,
            "current_player": self.current_player,
            "viewer_player": self.online_viewer_player,
            "state_revision": self.state_revision,
            "selected_card": self.selected_card,
            "cards_used_this_turn": self.cards_used_this_turn,
            "deck_count": len(self.deck),
            "discard_count": len(self.discard),
            "current_hand_count": hand_size,
            "pieces": len(self.pieces),
            "zoids": len(self.zoids),
            "open_walls": len(self.open_walls),
            "shared_walls": shared_count,
            "open_shared_walls": open_count,
            "closed_shared_walls": closed_count,
            "active_ufo": bool(self.active_ufo),
            "explosions": len(self.explosions),
            "online_room": self.online_room_code,
            "online_ws_connected": bool(self.online_ws_connected),
            "online_ws_healthy": bool(self.online_stream_healthy()),
            "online_ws_age_ms": ws_age,
            "online_ws_status": str(self.online_ws_status)[:180],
            "telemetry_path": self.telemetry.path if getattr(self, "telemetry", None) else "",
        }
        if phase_times:
            data["phase_ms"] = {
                key: round(float(value), 3)
                for key, value in phase_times.items()
                if isinstance(value, (int, float))
            }
        return data

    def telemetry_tick(self, frame_ms, phase_times=None):
        now = pygame.time.get_ticks()
        if now >= self.telemetry_next_state_ms:
            self.telemetry_next_state_ms = now + TELEMETRY_INTERVAL_MS
            self.telemetry_event("play_state", self.telemetry_snapshot(frame_ms=frame_ms, phase_times=phase_times))
        if frame_ms >= SLOW_FRAME_MS and now - self.telemetry_last_slow_frame_ms >= TELEMETRY_INTERVAL_MS:
            self.telemetry_last_slow_frame_ms = now
            self.telemetry_event("slow_frame", self.telemetry_snapshot(frame_ms=frame_ms, phase_times=phase_times))

    def line_click_diagnostics(self, pos):
        def point_data(point):
            return [round(float(point[0]), 3), round(float(point[1]), 3)]

        shared = self.shared_edges()
        nearest = None
        shared_count = 0
        open_count = 0
        closed_count = 0
        for key, entries in shared.items():
            if len(entries) != 2:
                continue
            shared_count += 1
            is_open = key in self.open_walls
            if is_open:
                open_count += 1
            else:
                closed_count += 1
            _, _, a, b = entries[0]
            distance, closest = point_segment_distance(pos, a, b)
            score = weighted_edge_click_score(pos, a, b, max_distance=LINE_CLICK_TOLERANCE)
            pieces = []
            for piece_idx, side_idx, _, _ in entries:
                piece = self.pieces[piece_idx]
                pieces.append({
                    "piece": piece_idx,
                    "side": side_idx,
                    "shape": piece.get("shape"),
                    "owner": piece.get("owner"),
                    "played_by": piece.get("played_by"),
                })
            candidate = {
                "wall": [point_data(point) for point in key],
                "distance": round(float(distance), 3),
                "weighted_score": round(float(score), 3) if score is not None else None,
                "within_tolerance": score is not None,
                "is_open": bool(is_open),
                "closest": point_data(closest),
                "midpoint": point_data(midpoint(a, b)),
                "pieces": pieces,
            }
            if nearest is None or candidate["distance"] < nearest["distance"]:
                nearest = candidate
        return {
            "click": point_data(pos),
            "line_tolerance": LINE_CLICK_TOLERANCE,
            "pieces": len(self.pieces),
            "open_walls": len(self.open_walls),
            "shared_walls": shared_count,
            "open_shared_walls": open_count,
            "closed_shared_walls": closed_count,
            "nearest_shared_wall": nearest,
            "target_found": bool(nearest and nearest["within_tolerance"] and not nearest["is_open"]),
        }

    def apply_player_command(self, command, actor=None, record=True):
        command_type = command.get("type") if isinstance(command, dict) else None
        actor = self.current_player if actor is None else actor
        def command_card_index():
            raw = command.get("card_index", self.selected_card if self.selected_card is not None else -1)
            return -1 if raw is None else int(raw)

        if self.mode != "playing":
            return {"ok": False, "error": "Game is not in playing mode."}
        if actor != self.current_player:
            return {"ok": False, "error": "It is not that player's turn."}

        payload = {}
        ok = False
        if command_type == "play_at":
            card_index = command_card_index()
            pos = command.get("pos")
            if not (0 <= card_index < len(self.hands[self.current_player])):
                return {"ok": False, "error": "Card index is not in the current hand."}
            if not pos or len(pos) != 2:
                return {"ok": False, "error": "Play command needs a board position."}
            self.selected_card = card_index
            payload = {"card_index": card_index, "pos": [round(float(pos[0]), 3), round(float(pos[1]), 3)]}
            ok = self.try_play_selected_at((float(pos[0]), float(pos[1])))
        elif command_type == "discard":
            card_index = command_card_index()
            if not (0 <= card_index < len(self.hands[self.current_player])):
                return {"ok": False, "error": "Card index is not in the current hand."}
            self.selected_card = card_index
            payload = {"card_index": card_index}
            before = len(self.hands[actor])
            self.discard_selected()
            ok = len(self.hands[actor]) < before
        elif command_type == "cycle_wild":
            card_index = command_card_index()
            if not (0 <= card_index < len(self.hands[self.current_player])):
                return {"ok": False, "error": "Card index is not in the current hand."}
            card = self.hands[self.current_player][card_index]
            ok = cycle_wild_card(card)
            payload = {"card_index": card_index, "kind": card_kind(card)}
            self.selected_card = card_index
            self.message = f"Wild card changed to {card_label(card)}." if ok else "Only wild cards can change shape."
            if ok:
                play_note("pluck")
        elif command_type == "end_turn":
            payload = {}
            self.advance_turn()
            ok = True
        else:
            return {"ok": False, "error": f"Unknown command type: {command_type}"}

        if not ok:
            return {"ok": False, "error": self.message}
        if record:
            self.record_action(actor, command_type, payload)
        return {"ok": True, "revision": self.state_revision, "message": self.message}

    def state_snapshot(self, viewer_player=None):
        """Return JSON-ready game state for future saves, replays, and network clients."""
        self.ensure_zoid_ids()
        def card_copy(card):
            return dict(card) if isinstance(card, dict) else card

        def point_list(point):
            return [round(float(point[0]), 3), round(float(point[1]), 3)]

        def wall_list(wall):
            return [point_list(point) for point in wall]

        hands = []
        for idx, hand in enumerate(self.hands):
            if viewer_player is None or idx == viewer_player:
                hands.append([card_copy(card) for card in hand])
            else:
                hands.append({"count": len(hand)})

        return {
            "version": VERSION,
            "state_revision": self.state_revision,
            "next_zoid_id": self.next_zoid_id,
            "mode": self.mode,
            "player_count": self.player_count,
            "current_player": self.current_player,
            "players": [
                {
                    "name": player["name"],
                    "color_name": player["color_name"],
                    "color_index": player["color_index"],
                    "is_ai": idx in self.ai_players,
                    "score_total": self.total_scores[idx] if idx < len(self.total_scores) else 0,
                    "score_round": self.round_scores[idx] if idx < len(self.round_scores) else 0,
                }
                for idx, player in enumerate(self.players)
            ],
            "deck_count": len(self.deck),
            "discard": [card_copy(card) for card in self.discard],
            "hands": hands,
            "pieces": [
                {
                    "shape": piece["shape"],
                    "points": [point_list(point) for point in piece["points"]],
                    "owner": piece.get("owner"),
                    "played_by": piece.get("played_by"),
                }
                for piece in self.pieces
            ],
            "zoids": [
                {
                    "zoid_id": z["zoid_id"],
                    "kind": z.get("kind", "zoid"),
                    "owner": z.get("owner"),
                    "played_by": z.get("played_by"),
                    "piece": z.get("piece"),
                    "pos": point_list(z.get("pos", (0, 0))),
                    "vel": point_list(z.get("vel", (0, 0))),
                    "visited": sorted(z.get("visited", [])),
                }
                for z in self.zoids
            ],
            "open_walls": [wall_list(wall) for wall in sorted(self.open_walls)],
            "round_slots": list(self.round_slots),
            "round_wild_kind": self.round_wild_kind,
            "cards_used_this_turn": self.cards_used_this_turn,
            "last_card_drawn": self.last_card_drawn,
            "no_discard_turns_after_empty": self.no_discard_turns_after_empty,
            "action_log": [dict(entry) for entry in self.action_log],
            "message": self.message,
        }

    def reset_round(self, carry_hands=False):
        SHAPE_GRADIENT_CACHE.clear()
        SHAPE_GRADIENT_CACHE_ORDER.clear()
        carried_hands = [[] for _ in range(self.player_count)]
        if carry_hands:
            for i in range(min(self.player_count, len(self.hands))):
                carried_hands[i] = [dict(card) for card in self.hands[i]]
        self.round_slots = [random.choice(CARD_TYPES) for _ in range(3)]
        self.round_wild_kind = self.round_slots[2]
        self.deck = self.build_round_deck()
        for hand in carried_hands:
            for card in hand:
                card["kind"] = card_base_kind(card)
                card["wild"] = card_base_kind(card) == self.round_wild_kind
        carried_counts = Counter(base_card_key(card) for hand in carried_hands for card in hand)
        if carried_counts:
            kept_deck = []
            for card in self.deck:
                key = base_card_key(card)
                if carried_counts[key] > 0:
                    carried_counts[key] -= 1
                else:
                    kept_deck.append(card)
            self.deck = kept_deck
        random.shuffle(self.deck)
        self.slot_show_until = pygame.time.get_ticks() + 4600
        self.discard = []
        self.hands = carried_hands
        self.pieces = []
        self.zoids = []
        self.open_walls = set()
        self._shared_edges_signature = None
        self._shared_edges_cache = None
        self.invalidate_wall_plane_geometry()
        self.current_player = 0
        self.selected_card = None
        self.cards_used_this_turn = 0
        self.discarded_this_turn = False
        self.last_card_drawn = False
        self.no_discard_turns_after_empty = 0
        self.ai_next_action_at = 0
        self.ai_pending_advance = False
        self.ai_wait_started_at = 0
        self.ai_wait_player = None
        self.player_actions = {}
        self.turn_started_at = pygame.time.get_ticks()
        self.reset_ufo_turn_timer(self.turn_started_at)
        self.round_scores = [0] * self.player_count
        self.round_light_scores = [0] * self.player_count
        self.last_score_breakdown = []
        for i in range(self.player_count):
            self.draw_to_five(i)

    def build_round_deck(self):
        deck = []
        for color_index in range(len(PLAYER_COLORS)):
            for kind in CARD_TYPES:
                deck.append(make_card(kind, color_index, wild=(kind == self.round_wild_kind)))
        for slot_idx, extra_sets in ((0, 1), (1, 2)):
            kind = self.round_slots[slot_idx]
            for _ in range(extra_sets):
                for color_index in range(len(PLAYER_COLORS)):
                    deck.append(make_card(kind, color_index, wild=(kind == self.round_wild_kind)))
        return deck

    def start(self):
        self.reset_match_sync_state()
        self.reset_round()
        self.mode = "playing"
        self.reset_ufo_turn_timer(pygame.time.get_ticks())
        self.message = f"{self.current['name']} takes the first turn."
        if self.music_enabled:
            self.music_loaded = start_music()
        play_note("glass")

    def draw_to_five(self, player_idx):
        while len(self.hands[player_idx]) < 5 and self.deck:
            self.hands[player_idx].append(self.deck.pop())
        if self.mode == "playing" and not self.deck:
            self.last_card_drawn = True

    def score_round(self, include_control=True):
        return [sum(parts.values()) for parts in self.score_breakdown(include_control=include_control)]

    def circuit_score_breakdown(self):
        lights = [0] * self.player_count
        for key, entries in self.shared_edges().items():
            if key not in self.open_walls or len(entries) != 2:
                continue
            first_idx = entries[0][0]
            second_idx = entries[1][0]
            first_owner = self.pieces[first_idx].get("owner")
            if first_owner != self.pieces[second_idx].get("owner"):
                continue
            owner_idx = self.player_index_for_color(first_owner)
            if owner_idx is not None:
                lights[owner_idx] += 1
        return lights

    def score_breakdown(self, include_control=True):
        circuit_scores = self.circuit_score_breakdown()
        breakdown = [
            {"placed": 0, "color": 0, "zoid": 0, "penta": 0, "lights": circuit_scores[i] if i < len(circuit_scores) else 0}
            for i in range(self.player_count)
        ]
        scores = [0] * self.player_count
        for piece in self.pieces:
            if "played_by" in piece:
                placed_idx = piece["played_by"] if 0 <= piece["played_by"] < self.player_count else None
            else:
                placed_owner = piece.get("placed_owner", piece.get("owner"))
                placed_idx = self.player_index_for_color(placed_owner)
            if placed_idx is not None:
                breakdown[placed_idx]["placed"] += 1
            owner = piece.get("owner")
            owner_idx = self.player_index_for_color(owner)
            if include_control and owner_idx is not None:
                breakdown[owner_idx]["color"] += 2
        for z in self.zoids:
            owner = z.get("owner")
            owner_idx = self.player_index_for_color(owner)
            if owner_idx is None and "played_by" in z:
                owner_idx = z["played_by"] if 0 <= z["played_by"] < self.player_count else None
            if owner_idx is None:
                continue
            if z.get("kind") == "penta":
                breakdown[owner_idx]["penta"] += 3
            else:
                breakdown[owner_idx]["zoid"] += 2
        return breakdown

    def finish_round(self):
        self.last_score_breakdown = self.score_breakdown()
        self.round_scores = [sum(parts.values()) for parts in self.last_score_breakdown]
        if len(self.total_scores) != self.player_count:
            self.total_scores = [0] * self.player_count
        for i, score in enumerate(self.round_scores):
            self.total_scores[i] += score
        self.selected_card = None
        self.mode = "score"
        self.message = "No-discard cycle complete. Round scored."
        play_note("glass")

    def start_next_round(self):
        self.action_log = []
        self.reset_round(carry_hands=True)
        self.mode = "playing"
        self.reset_ufo_turn_timer(pygame.time.get_ticks())
        self.message = f"New round. {self.current['name']} takes the first turn."
        if self.music_enabled and not pygame.mixer.music.get_busy():
            self.music_loaded = start_music()
        play_note("glass")

    def toggle_music(self):
        self.music_enabled = not self.music_enabled
        if self.music_enabled:
            self.music_loaded = start_music()
            self.message = "Music on." if self.music_loaded else "Music on. Add audio files to the music folder."
        else:
            stop_music()
            self.message = "Music off."
        save_player_settings(self)

    def change_music_volume(self, delta):
        global music_volume
        music_volume = max(0.0, min(1.0, music_volume + delta))
        try:
            pygame.mixer.music.set_volume(music_volume)
        except Exception:
            pass
        self.message = f"Music volume {int(music_volume * 100)}%."
        save_player_settings(self)

    def change_sfx_volume(self, delta):
        global sfx_volume
        sfx_volume = max(0.0, min(1.0, sfx_volume + delta))
        self.message = f"Sound effects volume {int(sfx_volume * 100)}%."
        play_note("glass")
        save_player_settings(self)

    def cycle_key(self):
        global current_key
        idx = KEY_LIBRARY.index(current_key) if current_key in KEY_LIBRARY else 0
        current_key = KEY_LIBRARY[(idx + 1) % len(KEY_LIBRARY)]
        self.message = f"Sound key: {current_key[0]}."
        play_note("glass")
        save_player_settings(self)

    def cycle_instrument(self, role):
        names = list(SOUND_STYLES.keys())
        current = effect_instruments.get(role, role)
        idx = names.index(current) if current in names else 0
        effect_instruments[role] = names[(idx + 1) % len(names)]
        self.message = f"{role.title()} sound: {effect_instruments[role].title()}."
        play_note(role)
        save_player_settings(self)

    def reset_ufo_turn_timer(self, now=None):
        now = pygame.time.get_ticks() if now is None else now
        self.turn_started_at = now
        self.next_ufo_at = now + UFO_FIRST_DELAY_MS
        self.ufo_flight_index = 0
        self.active_ufo = None
        self.explosions = []

    @property
    def current(self):
        return self.players[self.current_player]

    def current_is_ai(self):
        return self.current_player in self.ai_players

    def consume_card(self, card_idx, recycle_to_deck=False):
        card = self.hands[self.current_player].pop(card_idx)
        if recycle_to_deck:
            self.deck.append(card)
            random.shuffle(self.deck)
            self.discarded_this_turn = True
        else:
            self.discard.append(card)
        self.selected_card = None
        self.cards_used_this_turn += 1
        if not self.hands[self.current_player] or self.cards_used_this_turn >= 5:
            if self.current_is_ai():
                self.begin_ai_end_wait()
            else:
                self.advance_turn()
        else:
            self.message = f"{self.current['name']} has {len(self.hands[self.current_player])} cards left."
            if self.current_is_ai():
                now = pygame.time.get_ticks()
                self.ai_next_action_at = now + AI_MOVE_DELAY_MS
                self.ai_wait_started_at = now
                self.ai_wait_player = self.current_player

    def advance_turn(self):
        self.ai_pending_advance = False
        self.ai_wait_player = None
        if self.mode == "playing" and self.last_card_drawn:
            if self.discarded_this_turn:
                self.no_discard_turns_after_empty = 0
            else:
                self.no_discard_turns_after_empty += 1
            if self.no_discard_turns_after_empty >= self.player_count:
                self.finish_round()
                return
        self.current_player = (self.current_player + 1) % self.player_count
        self.draw_to_five(self.current_player)
        if self.mode == "score":
            return
        self.cards_used_this_turn = 0
        self.discarded_this_turn = False
        self.selected_card = None
        now = pygame.time.get_ticks()
        self.ai_next_action_at = now + AI_MOVE_DELAY_MS if self.current_is_ai() else 0
        if self.current_is_ai():
            self.ai_wait_started_at = now
            self.ai_wait_player = self.current_player
        self.reset_ufo_turn_timer(now)
        self.message = f"{self.current['name']}'s turn. Play up to {len(self.hands[self.current_player])} cards."
        play_note("pluck")

    def begin_ai_end_wait(self):
        now = pygame.time.get_ticks()
        self.ai_pending_advance = True
        self.ai_wait_started_at = now
        self.ai_wait_player = self.current_player
        self.ai_next_action_at = now + AI_MOVE_DELAY_MS
        self.message = f"{self.current['name']} waits for Zoids to move."

    def piece_at(self, pos):
        for idx in range(len(self.pieces) - 1, -1, -1):
            if point_in_polygon(pos, self.pieces[idx]["points"]):
                return idx
        return None

    def piece_at_with_hint(self, pos, piece_idx):
        if (
            isinstance(piece_idx, int)
            and 0 <= piece_idx < len(self.pieces)
            and point_in_polygon(pos, self.pieces[piece_idx]["points"])
        ):
            return piece_idx
        return self.piece_at(pos)

    def shared_edges(self):
        signature = tuple(
            tuple((float(point[0]), float(point[1])) for point in piece["points"])
            for piece in self.pieces
        )
        if signature == self._shared_edges_signature and self._shared_edges_cache is not None:
            return self._shared_edges_cache
        edges = {}
        for pi, piece in enumerate(self.pieces):
            for si, (a, b) in enumerate(side_list(piece["points"])):
                edges.setdefault(edge_key(a, b), []).append((pi, si, a, b))
        self._shared_edges_signature = signature
        self._shared_edges_cache = edges
        return edges

    def exposed_edges(self):
        return {k for k, v in self.shared_edges().items() if len(v) == 1}

    def find_clicked_exposed_side(self, pos):
        exposed = self.exposed_edges()
        best = (None, None, float("inf"))
        for pi, piece in enumerate(self.pieces):
            for si, (a, b) in enumerate(side_list(piece["points"])):
                k = edge_key(a, b)
                if k not in exposed:
                    continue
                score = weighted_edge_click_score(pos, a, b)
                if score is not None and score < best[2]:
                    best = (pi, si, score)
        if best[0] is not None:
            return best[0], best[1]
        inside_piece = self.piece_at(pos)
        if inside_piece is not None:
            for si, (a, b) in enumerate(side_list(self.pieces[inside_piece]["points"])):
                if edge_key(a, b) not in exposed:
                    continue
                score = point_segment_distance(pos, a, b)[0]
                if score < best[2]:
                    best = (inside_piece, si, score)
        return best[0], best[1]

    def find_clicked_shared_wall(self, pos):
        best = (None, float("inf"))
        for k, entries in self.shared_edges().items():
            if len(entries) != 2 or k in self.open_walls:
                continue
            _, _, a, b = entries[0]
            score = weighted_edge_click_score(pos, a, b, max_distance=LINE_CLICK_TOLERANCE)
            if score is not None and score < best[1]:
                best = (k, score)
        return best[0]

    def shape_candidate(self, shape, pos):
        if self.pieces:
            pi, si = self.find_clicked_exposed_side(pos)
            if pi is None:
                return None, None
            a, b = side_list(self.pieces[pi]["points"])[si]
            return build_points_for_shape(shape, a, b, centroid(self.pieces[pi]["points"])), pi
        return build_points_for_shape(shape), None

    def shape_fits(self, points):
        if any(not BOARD_RECT.collidepoint((int(p[0]), int(p[1]))) for p in points):
            return False
        return not any(polygons_overlap(points, piece["points"]) for piece in self.pieces)

    def place_shape(self, shape, color_index, pos):
        points, attach_piece = self.shape_candidate(shape, pos)
        if points is None:
            self.message = "Click the side you want to attach to."
            return False
        if not self.shape_fits(points):
            self.message = "That shape overlaps another shape. Pick a different side."
            return False
        self.pieces.append({"shape": shape, "points": points, "owner": color_index, "played_by": self.current_player})
        self.invalidate_wall_plane_geometry()
        self.message = f"{self.current['name']} placed a {PLAYER_COLORS[color_index][0]} {shape}."
        play_note("glass")
        return True

    def count_lit_connections(self, piece_idx):
        piece = self.pieces[piece_idx]
        shared = self.shared_edges()
        total = 0
        for a, b in side_list(piece["points"]):
            key = edge_key(a, b)
            if key not in self.open_walls:
                continue
            entries = shared.get(key, [])
            if len(entries) != 2:
                continue
            other_idx = entries[0][0] if entries[1][0] == piece_idx else entries[1][0]
            if self.pieces[other_idx].get("owner") == piece.get("owner"):
                total += 1
        return total

    def play_line(self, pos):
        diagnostic = self.line_click_diagnostics(pos)
        wall = self.find_clicked_shared_wall(pos)
        if wall is None:
            self.message = "Line cards remove only a shared wall between two shapes."
            self.telemetry_event("line_attempt", {
                "ok": False,
                "message": self.message,
                "diagnostic": diagnostic,
                "state": self.telemetry_snapshot(),
            })
            return False
        self.open_walls.add(wall)
        self.message = f"{self.current['name']} opened a wall."
        self.telemetry_event("line_attempt", {
            "ok": True,
            "message": self.message,
            "opened_wall": [[round(float(point[0]), 3), round(float(point[1]), 3)] for point in wall],
            "diagnostic": diagnostic,
            "state": self.telemetry_snapshot(),
        })
        play_note("glass")
        return True

    def play_zoid(self, color_index, pos):
        return self.play_ball(pos, "zoid", color_index)

    def play_penta_zoid(self, color_index, pos):
        return self.play_ball(pos, "penta", color_index)

    @staticmethod
    def valid_zoid_id(value):
        return isinstance(value, int) and not isinstance(value, bool) and value > 0

    def ensure_zoid_ids(self):
        """Preserve valid IDs and backfill missing/duplicate IDs from old state."""
        seen = set()
        needs_id = []
        for zoid in self.zoids:
            zoid_id = zoid.get("zoid_id")
            if self.valid_zoid_id(zoid_id) and zoid_id not in seen:
                seen.add(zoid_id)
            else:
                needs_id.append(zoid)

        next_id = self.next_zoid_id if self.valid_zoid_id(self.next_zoid_id) else 1
        if seen:
            next_id = max(next_id, max(seen) + 1)
        for zoid in needs_id:
            while next_id in seen:
                next_id += 1
            zoid["zoid_id"] = next_id
            seen.add(next_id)
            next_id += 1
        self.next_zoid_id = next_id

    def allocate_zoid_id(self):
        self.ensure_zoid_ids()
        zoid_id = self.next_zoid_id
        self.next_zoid_id += 1
        return zoid_id

    def play_ball(self, pos, kind, color_index):
        pi = self.piece_at(pos)
        if pi is None:
            self.message = "Click inside a matching colored shape to place the ball."
            return False
        if self.pieces[pi]["owner"] != color_index:
            self.message = f"You can only place that ball on {PLAYER_COLORS[color_index][0]}."
            return False
        angle = random.random() * math.tau
        speed = 2.9 if kind == "zoid" else 2.55
        self.zoids.append({
            "zoid_id": self.allocate_zoid_id(),
            "pos": [pos[0], pos[1]],
            "vel": [math.cos(angle) * speed, math.sin(angle) * speed],
            "owner": color_index,
            "played_by": self.current_player,
            "piece": pi,
            "kind": kind,
            "visited": {pi},
        })
        self.pieces[pi]["owner"] = color_index
        ball_name = "Penta-Zoid" if kind == "penta" else "zoid"
        self.message = f"{self.current['name']} placed a {PLAYER_COLORS[color_index][0]} {ball_name}."
        play_note("glass")
        return True

    def try_play_selected_at(self, pos):
        if self.selected_card is None:
            return False
        if not (0 <= self.selected_card < len(self.hands[self.current_player])):
            self.selected_card = None
            return False
        card = self.hands[self.current_player][self.selected_card]
        kind = card_kind(card)
        color_index = card_color(card)
        ok = False
        if kind in SHAPE_SIDES:
            ok = self.place_shape(kind, color_index, pos)
        elif kind == "line":
            ok = self.play_line(pos)
        elif kind == "zoid":
            ok = self.play_zoid(color_index, pos)
        elif kind == "pentagon":
            ok = self.play_penta_zoid(color_index, pos)
        if ok:
            self.consume_card(self.selected_card)
        return ok

    def discard_selected(self):
        if self.selected_card is None:
            self.message = "Select a card first."
            return
        card = self.hands[self.current_player][self.selected_card]
        self.message = f"{self.current['name']} discarded {card_label(card)}."
        self.consume_card(self.selected_card, recycle_to_deck=True)

    def owner_region(self, start_piece):
        seen = {start_piece}
        queue = deque([start_piece])
        shared = self.shared_edges()
        while queue:
            pi = queue.popleft()
            for a, b in side_list(self.pieces[pi]["points"]):
                k = edge_key(a, b)
                if k not in self.open_walls:
                    continue
                for other_pi, _, _, _ in shared.get(k, []):
                    if other_pi != pi and other_pi not in seen:
                        seen.add(other_pi)
                        queue.append(other_pi)
        return seen

    def update_zoids(self):
        wall_planes = self.wall_plane_geometry() if self.pieces else ()
        for z in self.zoids:
            if not self.pieces:
                continue
            speed = math.hypot(z["vel"][0], z["vel"][1])
            steps = max(1, int(math.ceil(speed / 1.0)))
            step_vel = (z["vel"][0] / steps, z["vel"][1] / steps)
            for _ in range(steps):
                old_pos = tuple(z["pos"])
                old_piece = self.piece_at_with_hint(old_pos, z.get("piece"))
                if old_piece is None:
                    break
                z["piece"] = old_piece
                new_pos = (z["pos"][0] + step_vel[0], z["pos"][1] + step_vel[1])
                if self.resolve_wall_collision(z, old_piece, old_pos, new_pos, wall_planes):
                    break
                new_piece = self.piece_at_with_hint(new_pos, old_piece)
                if new_piece is None:
                    z["pos"][0], z["pos"][1] = old_pos
                    z["piece"] = old_piece
                    break
                if new_piece == old_piece or new_piece in self.owner_region(old_piece):
                    z["pos"][0], z["pos"][1] = new_pos
                    z["piece"] = new_piece
                    z.setdefault("visited", set()).add(new_piece)
                    self.pieces[new_piece]["owner"] = z["owner"]
                else:
                    z["pos"][0], z["pos"][1] = old_pos
                    z["piece"] = old_piece
                    break
        self.resolve_ball_collisions()

    def ball_radius(self, z):
        return PENTA_ZOID_RADIUS if z.get("kind") == "penta" else ZOID_RADIUS

    def invalidate_wall_plane_geometry(self):
        """Mark wall planes dirty after changing the piece list or point geometry."""
        self._wall_plane_geometry_version += 1

    def wall_plane_geometry(self):
        if self._wall_plane_cache_version == self._wall_plane_geometry_version:
            return self._wall_plane_cache

        planes = []
        for piece in self.pieces:
            points = piece["points"]
            center = centroid(points)
            piece_planes = []
            for a, b in side_list(points):
                nx, ny = inward_edge_normal(a, b, center)
                mx, my = midpoint(a, b)
                piece_planes.append((edge_key(a, b), nx, ny, mx, my))
            planes.append(tuple(piece_planes))
        self._wall_plane_cache = tuple(planes)
        self._wall_plane_cache_version = self._wall_plane_geometry_version
        return self._wall_plane_cache

    def resolve_ball_collisions(self):
        remove = set()
        losses = []
        for i, a in enumerate(self.zoids):
            if i in remove or a.get("kind") != "penta":
                continue
            for j, b in enumerate(self.zoids):
                if i == j or j in remove:
                    continue
                touch_dist = self.ball_radius(a) + self.ball_radius(b)
                if dist(a["pos"], b["pos"]) > touch_dist:
                    continue
                if b.get("kind") == "penta":
                    remove.add(i)
                    remove.add(j)
                    break
                remove.add(j)
                if a.get("owner") != b.get("owner"):
                    victim_idx = self.player_index_for_color(b.get("owner"))
                    attacker_idx = self.player_index_for_color(a.get("owner"))
                    if victim_idx is not None and attacker_idx is not None:
                        losses.append(victim_idx)
        if remove:
            self.zoids = [z for idx, z in enumerate(self.zoids) if idx not in remove]
            for victim_idx in set(losses):
                self.set_player_action(victim_idx, "point_left", 3200)
            play_note("pluck")

    def wall_contacts(self, piece_idx, pos, radius, piece_planes=None):
        if piece_planes is None:
            piece_planes = self.wall_plane_geometry()[piece_idx]
        contacts = []
        for key, nx, ny, mx, my in piece_planes:
            if key in self.open_walls:
                continue
            clearance = (pos[0] - mx) * nx + (pos[1] - my) * ny
            penetration = radius + WALL_COLLISION_MARGIN - clearance
            if penetration > WALL_COLLISION_TOLERANCE:
                contacts.append((key, nx, ny, mx, my, penetration))
        return contacts

    def touching_wall_normals(self, piece_idx, pos, radius, piece_planes=None):
        if piece_planes is None:
            piece_planes = self.wall_plane_geometry()[piece_idx]
        target = radius + WALL_COLLISION_MARGIN
        normals = []
        for key, nx, ny, mx, my in piece_planes:
            if key in self.open_walls:
                continue
            clearance = (pos[0] - mx) * nx + (pos[1] - my) * ny
            if clearance <= target + WALL_COLLISION_TOLERANCE:
                normals.append((key, nx, ny))
        return normals

    def resolve_wall_collision(self, z, piece_idx, old_pos, attempted_pos=None, wall_planes=None):
        if not (0 <= piece_idx < len(self.pieces)):
            return False
        if wall_planes is None:
            wall_planes = self.wall_plane_geometry()
        piece_planes = wall_planes[piece_idx]
        radius = self.ball_radius(z)
        probe = attempted_pos or old_pos
        contacts = self.wall_contacts(piece_idx, probe, radius, piece_planes)
        if not contacts:
            return False

        fixed_pos = [float(probe[0]), float(probe[1])]
        contact_normals = {contact[0]: (contact[1], contact[2]) for contact in contacts}
        for _ in range(WALL_CORRECTION_MAX_PASSES):
            corrections = sorted(
                self.wall_contacts(piece_idx, fixed_pos, radius, piece_planes),
                key=lambda contact: (
                    round(math.atan2(contact[2], contact[1]), 12),
                    contact[0],
                ),
            )
            if not corrections:
                break
            corrected = False
            for contact in corrections:
                key, nx, ny, mx, my, _ = contact
                clearance = (fixed_pos[0] - mx) * nx + (fixed_pos[1] - my) * ny
                penetration = radius + WALL_COLLISION_MARGIN - clearance
                if penetration <= WALL_COLLISION_TOLERANCE:
                    continue
                contact_normals.setdefault(key, (nx, ny))
                fixed_pos[0] += nx * penetration
                fixed_pos[1] += ny * penetration
                corrected = True
            if not corrected:
                break

        for key, nx, ny in self.touching_wall_normals(piece_idx, fixed_pos, radius, piece_planes):
            contact_normals.setdefault(key, (nx, ny))
        incoming_velocity = (z["vel"][0], z["vel"][1])
        z["vel"][0], z["vel"][1] = valid_contact_velocity(
            incoming_velocity[0], incoming_velocity[1], contact_normals.values()
        )

        z["pos"][0], z["pos"][1] = fixed_pos
        z["piece"] = piece_idx
        return True

    def choose_ufo_target(self):
        owned = [
            idx for idx, piece in enumerate(self.pieces)
            if piece.get("owner") == self.current_color_index
        ]
        return random.choice(owned) if owned else None

    def start_ufo_flight(self, now):
        lane_cycle = (
            BOARD_RECT.y + BOARD_RECT.height * 0.18,
            BOARD_RECT.y + BOARD_RECT.height * 0.82,
            BOARD_RECT.centery,
        )
        lane = lane_cycle[self.ufo_flight_index % len(lane_cycle)]
        left_to_right = self.ufo_flight_index % 2 == 0
        start_x = -UFO_DRAW_W
        end_x = WIDTH + UFO_DRAW_W
        if not left_to_right:
            start_x, end_x = end_x, start_x
        target_idx = self.choose_ufo_target()
        target_pos = centroid(self.pieces[target_idx]["points"]) if target_idx is not None else None
        self.active_ufo = {
            "start": (start_x, lane),
            "end": (end_x, lane),
            "started_at": now,
            "ends_at": now + UFO_FLIGHT_MS,
            "shot_at": now + int(UFO_FLIGHT_MS * 0.32),
            "hit_at": now + int(UFO_FLIGHT_MS * 0.68),
            "target_idx": target_idx,
            "target_pos": target_pos,
            "hit_done": False,
            "left_to_right": left_to_right,
        }
        self.ufo_flight_index += 1
        self.next_ufo_at = 0

    def remove_piece(self, piece_idx):
        if not (0 <= piece_idx < len(self.pieces)):
            return
        removed_center = centroid(self.pieces[piece_idx]["points"])
        del self.pieces[piece_idx]
        self.invalidate_wall_plane_geometry()
        new_open_walls = set()
        for key in self.open_walls:
            shared = self.shared_edges().get(key, [])
            if len(shared) == 2:
                new_open_walls.add(key)
        self.open_walls = new_open_walls

        kept_zoids = []
        for z in self.zoids:
            old_piece = z.get("piece")
            if old_piece == piece_idx:
                continue
            if old_piece is not None and old_piece > piece_idx:
                z["piece"] = old_piece - 1
                old_piece = z["piece"]
            if not self.pieces or self.piece_at(z["pos"]) is None:
                continue
            if "visited" in z:
                z["visited"] = {
                    pi - 1 if pi > piece_idx else pi
                    for pi in z["visited"]
                    if pi != piece_idx and pi - (1 if pi > piece_idx else 0) >= 0
                }
                if z.get("piece") is not None:
                    z["visited"].add(z["piece"])
            kept_zoids.append(z)
        self.zoids = kept_zoids

    def update_ufo(self):
        if self.mode != "playing":
            self.active_ufo = None
            return
        now = pygame.time.get_ticks()
        self.explosions = [e for e in self.explosions if now - e["started_at"] < e["duration"]]
        if self.active_ufo is None and self.next_ufo_at and now >= self.next_ufo_at:
            if self.choose_ufo_target() is None:
                self.message = f"{self.current['name']} has no tiles left. Turn passes."
                self.advance_turn()
                return
            self.start_ufo_flight(now)
        if self.active_ufo is None:
            return
        event = self.active_ufo
        if (
            not event["hit_done"]
            and event["target_idx"] is not None
            and now >= event["hit_at"]
        ):
            event["hit_done"] = True
            target_idx = event["target_idx"]
            if (
                0 <= target_idx < len(self.pieces)
                and self.pieces[target_idx].get("owner") == self.current_color_index
            ):
                hit_pos = event["target_pos"] or centroid(self.pieces[target_idx]["points"])
                self.remove_piece(target_idx)
                self.set_player_action(self.current_player, "sad", 3200)
                self.explosions.append({"pos": hit_pos, "started_at": now, "duration": 760})
                self.message = f"UFO blasted one of {self.current['name']}'s tiles."
                play_note("pluck")
        if now >= event["ends_at"]:
            self.active_ufo = None
            self.next_ufo_at = now + UFO_REPEAT_DELAY_MS

    def ai_ball_coverage(self, player_idx=None):
        if player_idx is None:
            player_idx = self.current_player
        if not (0 <= player_idx < len(self.players)):
            return 1.0, 0, 0
        color_index = self.players[player_idx]["color_index"]
        available = set()
        visited = set()
        for z in self.zoids:
            if z.get("owner") != color_index:
                continue
            piece_idx = z.get("piece")
            if piece_idx is None or not (0 <= piece_idx < len(self.pieces)):
                continue
            region = self.owner_region(piece_idx)
            available.update(region)
            z_visited = z.setdefault("visited", {piece_idx})
            visited.update(pi for pi in z_visited if pi in region)
        if not available:
            return 1.0, 0, 0
        return len(visited) / len(available), len(visited), len(available)

    def ai_can_end_turn(self):
        coverage, visited, available = self.ai_ball_coverage(self.ai_wait_player)
        if available <= 1:
            return True
        if coverage >= AI_REQUIRED_BALL_COVERAGE:
            return True
        elapsed = pygame.time.get_ticks() - self.ai_wait_started_at
        if elapsed >= AI_BALL_WAIT_TIMEOUT_MS:
            self.message = f"{self.current['name']} waited for Zoids: {visited}/{available} shapes."
            return True
        self.message = f"{self.current['name']} waits for Zoids: {visited}/{available} shapes."
        return False

    def ai_can_take_next_move(self):
        coverage, visited, available = self.ai_ball_coverage(self.current_player)
        if available <= 1 or coverage >= AI_REQUIRED_BALL_COVERAGE:
            return True
        elapsed = pygame.time.get_ticks() - self.ai_wait_started_at
        if elapsed >= AI_BALL_WAIT_TIMEOUT_MS:
            return True
        self.message = f"{self.current['name']} lets Zoids move: {visited}/{available} shapes."
        return False

    def maybe_ai_turn(self):
        if self.mode != "playing" or not self.current_is_ai():
            return
        now = pygame.time.get_ticks()
        if now < self.ai_next_action_at:
            return
        if self.ai_pending_advance:
            if self.ai_can_end_turn():
                self.advance_turn()
            return
        if not self.ai_can_take_next_move():
            return
        hand = self.hands[self.current_player]
        if not hand:
            self.begin_ai_end_wait()
            return
        move = self.choose_ai_move()
        if move is None:
            self.selected_card = 0
            self.discard_selected()
            return
        card_idx, target = move
        self.selected_card = card_idx
        if not self.try_play_selected_at(target):
            if 0 <= self.selected_card < len(self.hands[self.current_player]):
                self.discard_selected()

    def choose_ai_move(self):
        hand = self.hands[self.current_player]

        line_indices = [i for i, c in enumerate(hand) if card_kind(c) == "line"]
        if line_indices:
            target = self.best_ai_line_target()
            if target is not None:
                return line_indices[0], target

        penta_indices = [i for i, c in enumerate(hand) if card_kind(c) == "pentagon"]
        for card_idx in penta_indices:
            target_piece = self.best_ai_piece_for_color(card_color(hand[card_idx]))
            if target_piece is not None:
                return card_idx, centroid(self.pieces[target_piece]["points"])

        zoid_indices = [i for i, c in enumerate(hand) if card_kind(c) == "zoid"]
        for card_idx in zoid_indices:
            target_piece = self.best_ai_piece_for_color(card_color(hand[card_idx]))
            if target_piece is not None:
                return card_idx, centroid(self.pieces[target_piece]["points"])

        shape_cards = [i for i, c in enumerate(hand) if card_kind(c) in SHAPE_SIDES]
        if shape_cards:
            if not self.pieces:
                card_idx = self.best_shape_card(shape_cards)
                return card_idx, BOARD_RECT.center
            for card_idx in sorted(shape_cards, key=lambda i: {"hex": 0, "square": 1, "triangle": 2}.get(card_kind(hand[i]), 9)):
                target = self.best_ai_attach_point(card_kind(hand[card_idx]), card_color(hand[card_idx]))
                if target is not None:
                    return card_idx, target

        return None

    def best_ai_line_target(self):
        best = None
        current_color = self.current_color_index
        ball_pieces = {z.get("piece") for z in self.zoids if z["owner"] == current_color}
        for k, entries in self.shared_edges().items():
            if len(entries) != 2 or k in self.open_walls:
                continue
            owners = [self.pieces[e[0]]["owner"] for e in entries]
            piece_ids = [e[0] for e in entries]
            _, _, a, b = entries[0]
            score = dist(midpoint(a, b), BOARD_RECT.center) * 0.01
            if current_color in owners:
                score -= 80
            if any(pi in ball_pieces for pi in piece_ids):
                score -= 120
            if owners[0] != owners[1]:
                score -= 35
            if best is None or score < best[0]:
                best = (score, midpoint(a, b))
        return best[1] if best else None

    def best_ai_zoid_piece(self):
        current_color = self.current_color_index
        for i, p in enumerate(self.pieces):
            if p["owner"] == current_color:
                return i
        return 0

    def best_ai_piece_for_color(self, color_index):
        for i, p in enumerate(self.pieces):
            if p["owner"] == color_index:
                return i
        return None

    def best_shape_card(self, shape_cards):
        preferred = {"hex": 0, "square": 1, "triangle": 2}
        return sorted(shape_cards, key=lambda i: preferred.get(card_kind(self.hands[self.current_player][i]), 9))[0]

    def best_ai_attach_point(self, shape, color_index):
        exposed = self.exposed_edges()
        best = None
        for pi, piece in enumerate(self.pieces):
            owner_bonus = -60 if piece["owner"] == color_index else 0
            for a, b in side_list(piece["points"]):
                if edge_key(a, b) not in exposed:
                    continue
                m = midpoint(a, b)
                points = build_points_for_shape(shape, a, b, centroid(piece["points"]))
                if not self.shape_fits(points):
                    continue
                center_pull = dist(m, BOARD_RECT.center) * 0.02
                score = owner_bonus + center_pull + random.random()
                if best is None or score < best[0]:
                    best = (score, m)
        return best[1] if best else None


PLAYER_SETTINGS = load_player_settings()
apply_display_mode()
GAME = Game()
if not os.path.exists(SETTINGS_PATH):
    save_player_settings(GAME)


# ---------- Drawing ----------


def draw_button(rect, text, active=False):
    tdata = theme()
    key = (
        current_theme_key,
        rect.width,
        rect.height,
        text,
        bool(active),
        tdata["text"],
        tdata["accent"],
        tdata["accent_2"],
        tdata["button_top"],
        tdata["button_bottom"],
        tdata["active_button_top"],
        tdata["active_button_bottom"],
    )
    image = BUTTON_SURFACE_CACHE.get(key)
    if image is None:
        image = pygame.Surface((rect.width + 16, rect.height + 16), pygame.SRCALPHA)
        glow_color = tdata["accent"] if active else tdata["accent_2"]
        pygame.draw.rect(image, glow_color + (44 if active else 28,), image.get_rect(), 3, border_radius=min(24, rect.height // 2 + 8))
        body_rect = pygame.Rect(8, 8, rect.width, rect.height)
        body = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        top = tdata["active_button_top"] if active else tdata["button_top"]
        bottom = tdata["active_button_bottom"] if active else tdata["button_bottom"]
        radius = min(18, rect.height // 2)
        for y in range(rect.height):
            t = y / max(1, rect.height - 1)
            alpha = 225 if active else 190
            pygame.draw.line(body, blend(top, bottom, t) + (alpha,), (0, y), (rect.width, y))
        mask = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=radius)
        body.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        pygame.draw.rect(body, tdata["accent_2"] + (128,), body.get_rect(), 2, border_radius=radius)
        if active:
            pygame.draw.rect(body, tdata["accent"], body.get_rect(), 3, border_radius=radius)
        else:
            pygame.draw.rect(body, tdata["accent_2"], body.get_rect(), 2, border_radius=radius)
        image.blit(body, body_rect.topleft)
        txt = render_fit_text(text, tdata["text"], small_font, rect.width - 20, rect.height - 8, min_size=14)
        image.blit(txt, txt.get_rect(center=body_rect.center))
        BUTTON_SURFACE_CACHE[key] = image
    SCREEN.blit(image, (rect.x - 8, rect.y - 8))


def render_fit_text(text, color, preferred_font, max_width, max_height, min_size=14):
    if preferred_font.size(text)[0] <= max_width and preferred_font.get_height() <= max_height:
        return preferred_font.render(text, True, color)
    for size in range(max(1, preferred_font.get_height() - 2), min_size - 1, -1):
        candidate = pygame.font.SysFont("Segoe UI", size, bold=True)
        if candidate.size(text)[0] <= max_width and candidate.get_height() <= max_height:
            return candidate.render(text, True, color)
    return pygame.font.SysFont("Segoe UI", min_size, bold=True).render(text, True, color)


def star_points(center, outer_radius, inner_radius, points=5, rotation=-math.pi / 2):
    cx, cy = center
    pts = []
    for i in range(points * 2):
        radius = outer_radius if i % 2 == 0 else inner_radius
        angle = rotation + i * math.pi / points
        pts.append((cx + math.cos(angle) * radius, cy + math.sin(angle) * radius))
    return pts


def draw_card(rect, card, selected=False):
    tdata = theme()
    card_text = tdata.get("card_text", tdata["text"])
    pygame.draw.rect(SCREEN, tdata["card_body"], rect, border_radius=4)
    pygame.draw.rect(SCREEN, tdata["card_inner"], rect.inflate(-8, -8), border_radius=2)
    border_color = SELECT_COLOR if selected else tdata["panel_border"][:3]
    pygame.draw.rect(SCREEN, border_color, rect, 3 if selected else 1, border_radius=4)
    kind = card_kind(card)
    color = card_rgb(card)
    pygame.draw.rect(SCREEN, color, (rect.x + 8, rect.y + 8, rect.width - 16, 12), border_radius=4)
    display_kind = "PENTA-ZOID" if kind == "pentagon" else kind.upper()
    txt = tiny_font.render(display_kind, True, card_text)
    SCREEN.blit(txt, txt.get_rect(center=(rect.centerx, rect.y + 33)))
    if is_wild(card):
        wild_txt = tiny_font.render("WILD", True, readable_text_color(color))
        SCREEN.blit(wild_txt, wild_txt.get_rect(center=(rect.centerx, rect.y + 15)))
    color_txt = tiny_font.render(card_color_name(card), True, card_text)
    SCREEN.blit(color_txt, color_txt.get_rect(center=(rect.centerx, rect.y + 50)))
    icon_center = (rect.centerx, rect.y + 82)
    if kind in SHAPE_SIDES:
        sides = SHAPE_SIDES[kind]
        pts = regular_polygon(icon_center, 22, sides, -math.pi / 2)
        pygame.draw.polygon(SCREEN, color, pts)
        pygame.draw.polygon(SCREEN, BLACK, pts, 2)
    elif kind == "pentagon":
        pygame.draw.circle(SCREEN, color, icon_center, 24)
        pygame.draw.circle(SCREEN, BLACK, icon_center, 24, 2)
        pygame.draw.circle(SCREEN, (230, 245, 255), (icon_center[0] - 6, icon_center[1] - 6), 6)
        pygame.draw.polygon(SCREEN, (250, 235, 120), star_points(icon_center, 16, 7), 2)
    elif kind == "line":
        pygame.draw.line(SCREEN, color, (rect.x + 26, icon_center[1]), (rect.right - 26, icon_center[1]), 6)
        pygame.draw.line(SCREEN, BLACK, (rect.x + 26, icon_center[1]), (rect.right - 26, icon_center[1]), 2)
    else:
        pygame.draw.circle(SCREEN, color, icon_center, 19)
        pygame.draw.circle(SCREEN, BLACK, icon_center, 19, 2)
        pygame.draw.circle(SCREEN, (230, 245, 255), (icon_center[0] - 5, icon_center[1] - 5), 6)


def draw_type_icon(kind, center, color, radius=22):
    if kind in SHAPE_SIDES:
        pts = regular_polygon(center, radius, SHAPE_SIDES[kind], -math.pi / 2)
        pygame.draw.polygon(SCREEN, color, pts)
        pygame.draw.polygon(SCREEN, BLACK, pts, 2)
    elif kind == "pentagon":
        pygame.draw.circle(SCREEN, color, center, radius)
        pygame.draw.circle(SCREEN, BLACK, center, radius, 2)
        pygame.draw.polygon(SCREEN, (250, 235, 120), star_points(center, radius - 6, max(5, radius // 2 - 2)), 2)
    elif kind == "line":
        pygame.draw.line(SCREEN, color, (center[0] - radius, center[1]), (center[0] + radius, center[1]), 6)
        pygame.draw.line(SCREEN, BLACK, (center[0] - radius, center[1]), (center[0] + radius, center[1]), 2)
    else:
        pygame.draw.circle(SCREEN, color, center, radius - 3)
        pygame.draw.circle(SCREEN, BLACK, center, radius - 3, 2)
        pygame.draw.circle(SCREEN, (230, 245, 255), (center[0] - 5, center[1] - 5), 6)


def draw_slot_type_card(rect, kind, caption):
    tdata = theme()
    pygame.draw.rect(SCREEN, tdata["card_body"], rect, border_radius=6)
    pygame.draw.rect(SCREEN, tdata["card_inner"], rect.inflate(-8, -8), border_radius=4)
    pygame.draw.rect(SCREEN, tdata["accent"] if caption == "WILD" else tdata["accent_2"], rect, 2, border_radius=6)
    label = "PENTA-ZOID" if kind == "pentagon" else kind.upper()
    SCREEN.blit(tiny_font.render(caption, True, tdata["accent"] if caption == "WILD" else tdata["text"]), (rect.x + 12, rect.y + 10))
    txt = tiny_font.render(label, True, tdata["text"])
    SCREEN.blit(txt, txt.get_rect(center=(rect.centerx, rect.y + 38)))
    draw_type_icon(kind, (rect.centerx, rect.y + 76), tdata["accent"] if caption == "WILD" else tdata["accent_2"], 22)


def draw_round_slot_overlay():
    if len(GAME.round_slots) != 3:
        return
    if GAME.pieces and pygame.time.get_ticks() > GAME.slot_show_until:
        return
    card_w, card_h, gap = 132, 112, 18
    total_w = card_w * 3 + gap * 2
    x = BOARD_RECT.centerx - total_w // 2
    y = BOARD_RECT.centery - card_h // 2
    panel = pygame.Rect(x - 24, y - 46, total_w + 48, card_h + 72)
    tdata = theme()
    draw_glass_rect(panel, fill=tdata["panel"], border=tdata["accent"] + (88,), radius=6)
    title = small_font.render("ROUND DECK SLOTS", True, tdata["text"])
    SCREEN.blit(title, title.get_rect(center=(BOARD_RECT.centerx, panel.y + 22)))
    captions = ["+1 SET", "+2 SETS", "WILD"]
    for idx, kind in enumerate(GAME.round_slots):
        rect = pygame.Rect(x + idx * (card_w + gap), y, card_w, card_h)
        draw_slot_type_card(rect, kind, captions[idx])


def wall_layer_styles(color, width, dark=False):
    shadow = darken(color, 0.62 if dark else 0.42)
    highlight = blend(color, brighten(color, 0.38 if dark else 0.55), 0.42)
    return (
        (shadow, width + 2),
        (color, width),
        (highlight, max(1, width // 3)),
    )


def canonical_wall_edge(a, b):
    if (float(b[0]), float(b[1])) < (float(a[0]), float(a[1])):
        a, b = b, a
    return (
        (float(a[0]), float(a[1])),
        (float(b[0]), float(b[1])),
    )


def canonical_wall_network(edges):
    return tuple(
        sorted(
            (
                (round(a[0], 4), round(a[1], 4)),
                (round(b[0], 4), round(b[1], 4)),
            )
            for a, b in (canonical_wall_edge(a, b) for a, b in edges)
        )
    )


def draw_wall_segment_quad(surface, color, a, b, width):
    dx, dy = b[0] - a[0], b[1] - a[1]
    length = math.hypot(dx, dy)
    if length <= 0.00001:
        return
    half_width = float(width) / 2.0
    nx = -dy / length * half_width
    ny = dx / length * half_width
    points = (
        (round(a[0] + nx), round(a[1] + ny)),
        (round(b[0] + nx), round(b[1] + ny)),
        (round(b[0] - nx), round(b[1] - ny)),
        (round(a[0] - nx), round(a[1] - ny)),
    )
    pygame.gfxdraw.filled_polygon(surface, points, color)


def draw_wall_layer(surface, edges, color, width):
    endpoints = {}
    for a, b in edges:
        draw_wall_segment_quad(surface, color, a, b, width)
        endpoints[(round(a[0], 4), round(a[1], 4))] = a
        endpoints[(round(b[0], 4), round(b[1], 4))] = b
    cap_radius = max(1, math.ceil(float(width) / 2.0))
    for point in endpoints.values():
        x, y = round(point[0]), round(point[1])
        pygame.gfxdraw.filled_circle(surface, x, y, cap_radius, color)


def build_wall_network_surface(canonical_edges, color, width, dark=False):
    widest_layer = max(layer_width for _, layer_width in wall_layer_styles(color, width, dark=dark))
    if not dark:
        widest_layer = max(widest_layer, width + 4)
    padding = math.ceil(widest_layer / 2.0) + 2
    points = [point for edge in canonical_edges for point in edge]
    left = math.floor(min(point[0] for point in points) - padding)
    top = math.floor(min(point[1] for point in points) - padding)
    right = math.ceil(max(point[0] for point in points) + padding)
    bottom = math.ceil(max(point[1] for point in points) + padding)
    local_width = max(1, right - left + 1)
    local_height = max(1, bottom - top + 1)
    scale = WALL_NETWORK_SUPERSAMPLE
    high_res = pygame.Surface((local_width * scale, local_height * scale), pygame.SRCALPHA)
    scaled_edges = tuple(
        (
            ((a[0] - left) * scale, (a[1] - top) * scale),
            ((b[0] - left) * scale, (b[1] - top) * scale),
        )
        for a, b in canonical_edges
    )

    if not dark:
        draw_wall_layer(high_res, scaled_edges, color + (42,), (width + 4) * scale)
    for layer_color, layer_width in wall_layer_styles(color, width, dark=dark):
        draw_wall_layer(high_res, scaled_edges, layer_color, layer_width * scale)
    return pygame.transform.smoothscale(high_res, (local_width, local_height)), (left, top)


def cached_wall_network(canonical_edges, color, width, dark=False):
    key = (canonical_edges, tuple(color), int(width), bool(dark))
    cached = WALL_NETWORK_CACHE.get(key)
    if cached is not None:
        try:
            WALL_NETWORK_CACHE_ORDER.remove(key)
        except ValueError:
            pass
        WALL_NETWORK_CACHE_ORDER.append(key)
        return cached

    cached = build_wall_network_surface(canonical_edges, color, width, dark=dark)
    WALL_NETWORK_CACHE[key] = cached
    WALL_NETWORK_CACHE_ORDER.append(key)
    while len(WALL_NETWORK_CACHE_ORDER) > WALL_NETWORK_CACHE_LIMIT:
        expired = WALL_NETWORK_CACHE_ORDER.popleft()
        WALL_NETWORK_CACHE.pop(expired, None)
    return cached


def draw_wall_network(edges, color, width, dark=False):
    canonical_edges = canonical_wall_network(edges)
    if not canonical_edges:
        return
    wall_surface, position = cached_wall_network(canonical_edges, color, width, dark=dark)
    SCREEN.blit(wall_surface, position)


def draw_shaped_edge(a, b, color, width, dark=False):
    draw_wall_network(((a, b),), color, width, dark=dark)


def draw_gear_button(rect):
    tdata = theme()
    draw_glass_rect(rect, fill=tdata["panel"], border=tdata["accent"] + (92,), radius=6)
    cx, cy = rect.center
    pygame.draw.circle(SCREEN, tdata["accent"], rect.center, 22, 2)
    for i in range(8):
        angle = i * math.pi / 4
        x1 = cx + math.cos(angle) * 11
        y1 = cy + math.sin(angle) * 11
        x2 = cx + math.cos(angle) * 16
        y2 = cy + math.sin(angle) * 16
        pygame.draw.line(SCREEN, tdata["accent"], (x1, y1), (x2, y2), 3)
    pygame.draw.circle(SCREEN, tdata["accent"], rect.center, 11, 3)
    pygame.draw.circle(SCREEN, tdata["card_body"], rect.center, 4)


def draw_select_box(rect, label, value):
    tdata = theme()
    SCREEN.blit(small_font.render(label, True, tdata["muted_text"]), (rect.x, rect.y - 22))
    draw_glass_rect(rect, fill=tdata["panel"], border=tdata["panel_border"], radius=4)
    txt = render_fit_text(value, tdata["text"], font, rect.width - 48, rect.height - 8, min_size=15)
    SCREEN.blit(txt, txt.get_rect(midleft=(rect.x + 14, rect.centery)))
    pygame.draw.polygon(SCREEN, tdata["accent"], [(rect.right - 26, rect.y + 18), (rect.right - 12, rect.y + 18), (rect.right - 19, rect.y + 28)])


def wrap_text_lines(text, font_obj, max_width):
    words = text.split()
    lines = []
    current = ""
    for word in words:
        trial = word if not current else f"{current} {word}"
        if font_obj.size(trial)[0] <= max_width:
            current = trial
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def draw_wrapped_text(text, x, y, max_width, color, font_obj=small_font, line_gap=4):
    for line in wrap_text_lines(text, font_obj, max_width):
        SCREEN.blit(font_obj.render(line, True, color), (x, y))
        y += font_obj.get_height() + line_gap
    return y


def draw_stepper(rect, label, value):
    tdata = theme()
    SCREEN.blit(small_font.render(label, True, tdata["muted_text"]), (rect.x, rect.y - 22))
    minus = pygame.Rect(rect.x, rect.y, 42, rect.height)
    plus = pygame.Rect(rect.right - 42, rect.y, 42, rect.height)
    draw_glass_rect(rect, fill=tdata["panel"], border=tdata["panel_border"], radius=4)
    minus_txt = render_fit_text("-", tdata["text"], font, 24, rect.height - 8, min_size=16)
    plus_txt = render_fit_text("+", tdata["text"], font, 24, rect.height - 8, min_size=16)
    SCREEN.blit(minus_txt, minus_txt.get_rect(center=minus.center))
    SCREEN.blit(plus_txt, plus_txt.get_rect(center=plus.center))
    txt = render_fit_text(value, tdata["text"], font, rect.width - 92, rect.height - 8, min_size=15)
    SCREEN.blit(txt, txt.get_rect(center=rect.center))
    return minus, plus


def setup_portrait_layout(count):
    if count == 1:
        return 300, 250, 330, 52
    if count == 2:
        return 260, 220, 292, 52
    if count == 3:
        return 230, 190, 254, 50
    if count == 4:
        return 190, 154, 208, 48
    if count == 5:
        return 164, 132, 178, 46
    return 146, 116, 158, 44


def settings_portrait_layout(count):
    if count <= 3:
        return 176, 132, 176, 48
    if count == 4:
        return 138, 102, 136, 46
    return 112, 84, 112, 42


def draw_setup():
    tdata = theme()
    draw_metal_background()
    GAME.setup_buttons = []
    banner = pygame.Rect(WIDTH // 2 - 210, 24, 420, 160)
    img = opening_image()
    if img:
        blit_fit(img, banner)
    panel = pygame.Rect(WIDTH // 2 - 600, 214, 1200, 534)
    draw_glass_rect(panel, radius=8)

    y = panel.y + 34
    count_label = small_font.render("Players", True, tdata["text"])
    SCREEN.blit(count_label, count_label.get_rect(center=(WIDTH // 2, y - 18)))
    for count in range(1, 7):
        rect = pygame.Rect(WIDTH // 2 - 135 + (count - 1) * 46, y, 34, 28)
        GAME.setup_buttons.append(("players", count, rect))
        draw_button(rect, str(count), active=GAME.player_count == count)

    y += 74
    label = small_font.render("Seats / AI / Color", True, tdata["text"])
    SCREEN.blit(label, label.get_rect(center=(WIDTH // 2, y - 18)))
    setup_slot_w, portrait_w, portrait_h, swatch_size = setup_portrait_layout(GAME.player_count)
    total_w = GAME.player_count * setup_slot_w - 16
    start_x = WIDTH // 2 - total_w // 2
    for i in range(GAME.player_count):
        rect = pygame.Rect(start_x + i * setup_slot_w + (setup_slot_w - swatch_size) // 2, y, swatch_size, swatch_size)
        GAME.setup_buttons.append(("ai", i, rect))
        color_idx = GAME.player_color_indices[i]
        pygame.draw.rect(SCREEN, PLAYER_COLORS[color_idx][1], rect, border_radius=6)
        pygame.draw.rect(SCREEN, tdata["text"] if i in GAME.ai_players else BLACK, rect, 3, border_radius=6)
        tag = "AI" if i in GAME.ai_players else "H"
        txt = font.render(tag, True, BLACK)
        SCREEN.blit(txt, txt.get_rect(center=rect.center))
        name_txt = tiny_font.render(PLAYER_COLORS[color_idx][0], True, tdata["text"])
        SCREEN.blit(name_txt, name_txt.get_rect(center=(rect.centerx, rect.bottom + 12)))
        draw_portrait(color_idx, pygame.Rect(rect.centerx - portrait_w // 2, rect.bottom + 22, portrait_w, portrait_h))

    hint = tiny_font.render("Left-click toggles AI. Right-click changes color.", True, tdata["muted_text"])
    SCREEN.blit(hint, hint.get_rect(center=(WIDTH // 2, panel.bottom + 14)))

    GAME.start_button = pygame.Rect(WIDTH // 2 - 224, panel.bottom + 34, 136, 34)
    GAME.online_button = pygame.Rect(WIDTH // 2 - 68, panel.bottom + 34, 136, 34)
    GAME.help_button = pygame.Rect(WIDTH // 2 + 88, panel.bottom + 34, 136, 34)
    draw_button(GAME.start_button, "Start", active=True)
    draw_button(GAME.online_button, "Online")
    draw_button(GAME.help_button, "Help")
    draw_gear_button(GAME.gear_rect)
    version = tiny_font.render(VERSION, True, tdata["muted_text"])
    SCREEN.blit(version, (22, HEIGHT - 34))


def draw_online_screen():
    tdata = theme()
    draw_metal_background()
    draw_gear_button(GAME.gear_rect)
    GAME.online_buttons = []

    panel = pygame.Rect(WIDTH // 2 - 560, 70, 1120, 710)
    draw_metal_panel(panel)
    title = title_font.render("Online Rooms", True, tdata["text"])
    SCREEN.blit(title, title.get_rect(center=(WIDTH // 2, 116)))
    status = render_fit_text(GAME.online_status, tdata["muted_text"], small_font, 850, 28, min_size=14)
    SCREEN.blit(status, status.get_rect(center=(WIDTH // 2, 160)))

    name_rect = pygame.Rect(panel.x + 54, 196, 240, 40)
    draw_select_box(name_rect, "Player Name", GAME.online_player_name_input or "Player")
    if GAME.online_focus == "player_name":
        pygame.draw.rect(SCREEN, tdata["accent"], name_rect, 2, border_radius=4)
    server_rect = pygame.Rect(panel.x + 314, 196, 500, 40)
    draw_select_box(server_rect, "Server Address", GAME.online_server_input or "Host address")
    if GAME.online_focus == "server":
        pygame.draw.rect(SCREEN, tdata["accent"], server_rect, 2, border_radius=4)
    code_rect = pygame.Rect(panel.x + 54, 248, 220, 40)
    draw_select_box(code_rect, "Room Code", GAME.online_room_code_input or "Type code")
    if GAME.online_focus == "room_code":
        pygame.draw.rect(SCREEN, tdata["accent"], code_rect, 2, border_radius=4)
    GAME.online_buttons.extend([
        ("focus", "player_name", name_rect),
        ("focus", "server", server_rect),
        ("focus", "room_code", code_rect),
    ])

    refresh_rect = pygame.Rect(panel.x + 836, 200, 96, 34)
    create_rect = pygame.Rect(panel.x + 954, 200, 112, 34)
    GAME.online_buttons.extend([
        ("refresh", None, refresh_rect),
        ("create", None, create_rect),
    ])
    draw_button(refresh_rect, "Refresh")
    draw_button(create_rect, "Create", active=True)

    left = pygame.Rect(panel.x + 54, 316, 480, 342)
    right = pygame.Rect(panel.x + 586, 316, 480, 342)
    draw_glass_rect(left, fill=tdata["panel"], border=tdata["panel_border"], radius=6)
    draw_glass_rect(right, fill=tdata["panel"], border=tdata["panel_border"], radius=6)
    SCREEN.blit(font.render("Open Rooms", True, tdata["text"]), (left.x + 24, left.y + 20))
    SCREEN.blit(font.render("Current Lobby", True, tdata["text"]), (right.x + 24, right.y + 20))

    if GAME.online_rooms:
        y = left.y + 70
        for room in GAME.online_rooms[:7]:
            row = pygame.Rect(left.x + 18, y, left.width - 36, 38)
            GAME.online_buttons.append(("select_room", room["room_code"], row))
            active = room["room_code"] == GAME.online_room_code_input.strip().upper()
            draw_glass_rect(row, fill=tdata["panel_2"], border=tdata["accent"] + (160,) if active else tdata["panel_border"], radius=4)
            label = f"{room['room_code']}  {room['phase']}  seats {room['seat_count']}/{room['max_seats']}"
            SCREEN.blit(small_font.render(label, True, tdata["text"]), (row.x + 12, row.y + 9))
            y += 46
    else:
        draw_wrapped_text("No rooms listed. Start the server or create a room.", left.x + 24, left.y + 76, left.width - 48, tdata["muted_text"])

    lobby = GAME.online_lobby
    if lobby:
        code = lobby.get("room_code", GAME.online_room_code or "")
        phase = lobby.get("phase", "unknown")
        viewer = lobby.get("viewer_player")
        SCREEN.blit(small_font.render(f"Room {code}  |  {phase}", True, tdata["accent"]), (right.x + 24, right.y + 68))
        viewer_label = "spectator" if viewer is None else f"seat {viewer + 1}"
        SCREEN.blit(tiny_font.render(f"You are {viewer_label}.", True, tdata["muted_text"]), (right.x + 24, right.y + 96))
        y = right.y + 132
        for seat in lobby.get("seats", [])[:6]:
            color = color_index_rgb(seat.get("color_index"))
            dot_center = (right.x + 42, y + 16)
            dot_rect = pygame.Rect(dot_center[0] - 16, dot_center[1] - 16, 32, 32)
            if viewer == seat.get("index") and phase == "lobby":
                GAME.online_buttons.append(("cycle_lobby_color", None, dot_rect))
                pygame.draw.circle(SCREEN, tdata["accent"], dot_center, 16)
            pygame.draw.circle(SCREEN, color, dot_center, 12)
            pygame.draw.circle(SCREEN, BLACK, dot_center, 12, 2)
            name = seat.get("name", f"Player {seat.get('index', 0) + 1}")
            ai = "AI" if seat.get("is_ai") else "Human"
            text = f"{seat.get('index', 0) + 1}. {name}  {seat.get('color_name', '')}  {ai}"
            SCREEN.blit(small_font.render(text, True, tdata["text"]), (right.x + 66, y + 5))
            y += 42
        if phase == "lobby" and viewer is not None:
            SCREEN.blit(tiny_font.render("Click your color dot to change color before Host Start.", True, tdata["muted_text"]), (right.x + 24, right.bottom - 34))
    else:
        draw_wrapped_text("Type your player name, the host server address, and the room code. Then click Join.", right.x + 24, right.y + 76, right.width - 48, tdata["muted_text"])

    join_rect = pygame.Rect(panel.x + 348, 690, 132, 42)
    start_rect = pygame.Rect(panel.x + 504, 690, 132, 42)
    help_rect = pygame.Rect(panel.x + 660, 690, 132, 42)
    back_rect = pygame.Rect(panel.x + 816, 690, 132, 42)
    GAME.online_buttons.extend([
        ("join", None, join_rect),
        ("start_online", None, start_rect),
        ("help", None, help_rect),
        ("back", None, back_rect),
    ])
    draw_button(join_rect, "Join")
    draw_button(start_rect, "Host Start", active=bool(GAME.online_room_code and GAME.online_seat_token))
    draw_button(help_rect, "Help")
    draw_button(back_rect, "Back", active=True)

    hint = render_fit_text("Host clicks Create. Joiners enter their own name, the host Server Address, and Room Code.", tdata["muted_text"], tiny_font, panel.width - 80, 22, min_size=12)
    SCREEN.blit(hint, hint.get_rect(center=(WIDTH // 2, panel.bottom - 28)))


def draw_settings():
    tdata = theme()
    draw_metal_background()
    draw_gear_button(GAME.gear_rect)
    panel = pygame.Rect(WIDTH // 2 - 540, 78, 1080, 690)
    draw_metal_panel(panel)
    title = font.render("Settings", True, tdata["text"])
    SCREEN.blit(title, title.get_rect(center=(WIDTH // 2, 112)))
    GAME.settings_buttons = []

    x = WIDTH // 2 - 340
    y = 156
    SCREEN.blit(small_font.render("Players", True, tdata["text"]), (WIDTH // 2 - 44, y - 28))
    for count in range(1, 7):
        rect = pygame.Rect(WIDTH // 2 - 135 + (count - 1) * 46, y, 34, 28)
        GAME.settings_buttons.append(("players", count, rect))
        draw_button(rect, str(count), active=GAME.player_count == count)

    y += 72
    SCREEN.blit(small_font.render("Seats / AI / Color", True, tdata["text"]), (WIDTH // 2 - 72, y - 28))
    settings_slot_w, portrait_w, portrait_h, swatch_size = settings_portrait_layout(GAME.player_count)
    total_w = GAME.player_count * settings_slot_w - 16
    start_x = WIDTH // 2 - total_w // 2
    for i in range(GAME.player_count):
        rect = pygame.Rect(start_x + i * settings_slot_w + (settings_slot_w - swatch_size) // 2, y, swatch_size, swatch_size)
        GAME.settings_buttons.append(("ai", i, rect))
        color_idx = GAME.player_color_indices[i]
        pygame.draw.rect(SCREEN, PLAYER_COLORS[color_idx][1], rect, border_radius=6)
        pygame.draw.rect(SCREEN, tdata["text"] if i in GAME.ai_players else BLACK, rect, 3, border_radius=6)
        tag = "AI" if i in GAME.ai_players else "H"
        txt = font.render(tag, True, BLACK)
        SCREEN.blit(txt, txt.get_rect(center=rect.center))
        name_txt = tiny_font.render(PLAYER_COLORS[color_idx][0], True, tdata["text"])
        SCREEN.blit(name_txt, name_txt.get_rect(center=(rect.centerx, rect.bottom + 14)))
        draw_portrait(color_idx, pygame.Rect(rect.centerx - portrait_w // 2, rect.bottom + 24, portrait_w, portrait_h))

    y = panel.y + 448
    x = WIDTH // 2 - 340
    music_rect = pygame.Rect(x, y, 160, 34)
    GAME.settings_buttons.append(("music_toggle", None, music_rect))
    draw_button(music_rect, f"Music: {'On' if GAME.music_enabled else 'Off'}", active=GAME.music_enabled)
    music_minus, music_plus = draw_stepper(pygame.Rect(x + 198, y, 184, 34), "Music Volume", f"{int(music_volume * 100)}%")
    GAME.settings_buttons.extend([("music_vol", -0.1, music_minus), ("music_vol", 0.1, music_plus)])
    sfx_minus, sfx_plus = draw_stepper(pygame.Rect(x + 420, y, 184, 34), "SFX Volume", f"{int(sfx_volume * 100)}%")
    GAME.settings_buttons.extend([("sfx_vol", -0.1, sfx_minus), ("sfx_vol", 0.1, sfx_plus)])

    y += 70
    key_rect = pygame.Rect(x, y, 220, 38)
    GAME.settings_buttons.append(("key", None, key_rect))
    draw_select_box(key_rect, "Sound Key", current_key[0])
    glass_rect = pygame.Rect(x + 258, y, 190, 38)
    GAME.settings_buttons.append(("instrument", "glass", glass_rect))
    draw_select_box(glass_rect, "Glass Button", effect_instruments["glass"].title())
    pluck_rect = pygame.Rect(x + 486, y, 190, 38)
    GAME.settings_buttons.append(("instrument", "pluck", pluck_rect))
    draw_select_box(pluck_rect, "Pluck Button", effect_instruments["pluck"].title())

    y += 66
    display_labels = {"windowed": "Windowed", "fullscreen": "Full Screen", "windowed_fullscreen": "Windowed Full Screen"}
    display_rect = pygame.Rect(x, y, 230, 38)
    GAME.settings_buttons.append(("display", None, display_rect))
    draw_select_box(display_rect, "Display Mode", display_labels.get(display_mode, "Windowed"))
    theme_rect = pygame.Rect(x + 260, y, 230, 38)
    GAME.settings_buttons.append(("theme", None, theme_rect))
    draw_select_box(theme_rect, "Theme", theme()["name"])
    GAME.help_button = pygame.Rect(x + 520, y, 116, 32)
    GAME.new_game_button = pygame.Rect(WIDTH // 2 - 174, HEIGHT - 142, 150, 34)
    GAME.back_button = pygame.Rect(WIDTH // 2 + 24, HEIGHT - 142, 150, 34)
    draw_button(GAME.help_button, "Help")
    draw_button(GAME.new_game_button, "Start New Game")

    hint = tiny_font.render("Left-click seat toggles AI. Right-click seat cycles color. Dropdowns cycle on click.", True, tdata["muted_text"])
    SCREEN.blit(hint, hint.get_rect(center=(WIDTH // 2, panel.bottom - 62)))
    draw_button(GAME.back_button, "Back", active=True)


def draw_help():
    tdata = theme()
    draw_metal_background()
    draw_gear_button(GAME.gear_rect)
    panel = pygame.Rect(WIDTH // 2 - 480, 64, 960, 724)
    draw_metal_panel(panel)
    title = title_font.render("Help", True, tdata["text"])
    SCREEN.blit(title, title.get_rect(center=(WIDTH // 2, 112)))
    subtitle = small_font.render("Rules draft. This page is ready for more detail as the game develops.", True, tdata["muted_text"])
    SCREEN.blit(subtitle, subtitle.get_rect(center=(WIDTH // 2, 158)))

    left_x = panel.x + 58
    right_x = panel.x + 512
    y_positions = [204, 204]
    columns = [left_x, right_x]
    max_width = 390
    for idx, (heading, lines) in enumerate(HELP_SECTIONS):
        col = 0 if idx < 3 else 1
        x = columns[col]
        y = y_positions[col]
        SCREEN.blit(font.render(heading, True, tdata["accent"]), (x, y))
        y += 38
        for line in lines:
            bullet_y = y + 7
            pygame.draw.circle(SCREEN, tdata["accent_2"], (x + 6, bullet_y), 3)
            y = draw_wrapped_text(line, x + 20, y, max_width, tdata["text"], small_font, 3)
            y += 10
        y_positions[col] = y + 18

    GAME.back_button = pygame.Rect(WIDTH // 2 - 110, HEIGHT - 92, 220, 46)
    draw_button(GAME.back_button, "Back", active=True)


def draw_board():
    tdata = theme()
    draw_glass_rect(BOARD_RECT, fill=tdata["board_fill"], border=tdata["board_border"], radius=2)
    SCREEN.blit(static_board_grid(), BOARD_RECT.topleft)
    draw_round_slot_overlay()

    shared = GAME.shared_edges()
    for idx, piece in enumerate(GAME.pieces):
        fill = color_index_rgb(piece.get("owner"))
        draw_polygon_gradient(SCREEN, piece["points"], fill)

    for idx, piece in enumerate(GAME.pieces):
        draw_shape_circuit(idx, piece, shared)

    solid_wall_edges = []
    for k, entries in shared.items():
        if not entries:
            continue
        _, _, a, b = entries[0]
        if len(entries) == 2 and k in GAME.open_walls:
            continue
        solid_wall_edges.append((a, b))
    draw_wall_network(solid_wall_edges, (78, 88, 104), 5, dark=True)

    draw_open_wall_gaps(shared)

    for z in GAME.zoids:
        color = color_index_rgb(z.get("owner"))
        pos = (int(z["pos"][0]), int(z["pos"][1]))
        radius = GAME.ball_radius(z)
        pygame.draw.circle(SCREEN, BLACK, pos, radius + 3)
        pygame.draw.circle(SCREEN, color, pos, radius)
        pygame.draw.circle(SCREEN, WHITE, (pos[0] - max(3, radius // 3), pos[1] - max(3, radius // 3)), 4)
        if z.get("kind") == "penta":
            pygame.draw.polygon(SCREEN, (255, 240, 120), star_points(pos, radius - 3, max(4, radius // 2 - 2)), 2)


def draw_sidebar():
    tdata = theme()
    draw_metal_panel(pygame.Rect(WIDTH - RIGHT_W, 0, RIGHT_W, HEIGHT))
    draw_metal_panel(pygame.Rect(0, HEIGHT - BOTTOM_H, WIDTH - RIGHT_W, BOTTOM_H))
    player = GAME.current
    online = GAME.mode == "online_playing"
    current_hand = GAME.hands[GAME.current_player] if GAME.current_player < len(GAME.hands) else []
    hand_visible = isinstance(current_hand, list)
    viewer_turn = not online or GAME.online_viewer_player == GAME.current_player

    GAME.card_rects = []
    player_text_color = brighten(player["color"], 0.42)
    if online and not viewer_turn:
        label = f"Waiting for {player['name']}"
        SCREEN.blit(font.render(label, True, tdata["muted_text"]), (28, HEIGHT - 84))
    elif GAME.current_is_ai() and not online:
        SCREEN.blit(font.render("AI thinking", True, tdata["muted_text"]), (28, HEIGHT - 84))
    elif hand_visible:
        card_w = HAND_CARD_W
        card_h = HAND_CARD_H
        gap = HAND_CARD_GAP
        start_x = 18
        y = HEIGHT - BOTTOM_H + 6
        for i, card in enumerate(current_hand):
            rect = pygame.Rect(start_x + i * (card_w + gap), y, card_w, card_h)
            GAME.card_rects.append((i, rect))
            draw_card(rect, card, selected=(GAME.selected_card == i))
    else:
        count = current_hand.get("count", 0) if isinstance(current_hand, dict) else 0
        SCREEN.blit(font.render(f"Hidden hand: {count}", True, tdata["muted_text"]), (28, HEIGHT - 84))

    SCREEN.blit(font.render("Played", True, tdata["text"]), (WIDTH - RIGHT_W + 18, 24))
    discard_rect = pygame.Rect(WIDTH - RIGHT_W + 18, 64, RIGHT_W - 36, 250)
    draw_glass_rect(discard_rect, fill=tdata["board_fill"], border=tdata["panel_border"], radius=2)
    for i, card in enumerate(GAME.discard[-8:]):
        txt = small_font.render(card_label(card).upper(), True, tdata["text"])
        SCREEN.blit(txt, (discard_rect.x + 14, discard_rect.y + 12 + i * 26))

    roster_x = WIDTH - RIGHT_W + 18
    roster_y = 326
    SCREEN.blit(small_font.render("Players", True, tdata["muted_text"]), (roster_x, roster_y))
    shown = 0
    for i, other in enumerate(GAME.players):
        if i == GAME.current_player:
            continue
        px = roster_x + (shown % 2) * 82
        py = roster_y + 24 + (shown // 2) * 106
        draw_portrait(other["color_index"], pygame.Rect(px, py, ROSTER_PORTRAIT_W, ROSTER_PORTRAIT_H), action=GAME.player_action(i))
        shown += 1

    active_rect = pygame.Rect(WIDTH - RIGHT_W - ACTIVE_PORTRAIT_W - 16, BOARD_RECT.bottom + 2, ACTIVE_PORTRAIT_W, ACTIVE_PORTRAIT_H)
    active_action = GAME.player_action(GAME.current_player)
    if GAME.current_is_ai():
        active_action = "thinking"
    draw_portrait(player["color_index"], active_rect, active=True, action=active_action)

    if hand_visible:
        remaining = len(current_hand)
    elif isinstance(current_hand, dict):
        remaining = current_hand.get("count", 0)
    else:
        remaining = 0
    SCREEN.blit(small_font.render(f"Turn cards: {remaining}", True, player_text_color), (WIDTH - RIGHT_W + 20, HEIGHT - 224))
    draw_button(GAME.discard_button, "Discard Card")
    draw_button(GAME.end_turn_button, "End Turn")
    if online:
        draw_button(GAME.ai_button, "Refresh")
        hint = "Online: refresh or play when it is your turn."
    else:
        ai_label = "AI: On" if GAME.current_player in GAME.ai_players else "AI: Off"
        draw_button(GAME.ai_button, ai_label, active=(GAME.current_player in GAME.ai_players))
        hint = "Click card. Right-click WILD to cycle."
    SCREEN.blit(tiny_font.render(hint, True, player_text_color), (WIDTH - RIGHT_W + 20, HEIGHT - 52))


def draw_top_status():
    tdata = theme()
    draw_metal_panel(pygame.Rect(0, 0, WIDTH - RIGHT_W, 70))
    msg_txt = render_fit_text(GAME.message, tdata["text"], font, 410, 42, min_size=20)
    SCREEN.blit(msg_txt, (24, 12))
    live_scores = GAME.score_round(include_control=False) if GAME.mode in ("playing", "online_playing") else GAME.round_scores
    score_parts = []
    for i, player in enumerate(GAME.players):
        total = GAME.total_scores[i] if i < len(GAME.total_scores) else 0
        live = live_scores[i] if i < len(live_scores) else 0
        score_parts.append(f"{player['name']} {total + live}")
    deck_state = f"Deck {len(GAME.deck)}"
    if GAME.last_card_drawn and GAME.mode in ("playing", "online_playing"):
        deck_state += f" | no-discard turns {GAME.no_discard_turns_after_empty}/{GAME.player_count}"
    summary = f"{deck_state} | " + " | ".join(score_parts)
    summary_x = min(460, msg_txt.get_width() + 56)
    score_txt = render_fit_text(summary, tdata["muted_text"], small_font, WIDTH - RIGHT_W - summary_x - 24, 30, min_size=14)
    SCREEN.blit(score_txt, score_txt.get_rect(midleft=(summary_x, 32)))


def draw_victory_podium(ranking):
    if not ranking:
        return
    tdata = theme()
    count = len(ranking)
    gap = 18
    slot_w = 138
    total_w = count * slot_w + (count - 1) * gap
    start_x = WIDTH // 2 - total_w // 2
    base_y = 720
    max_box = 72
    for rank, player_idx in enumerate(ranking, start=1):
        player = GAME.players[player_idx]
        x = start_x + (rank - 1) * (slot_w + gap)
        box_h = max(28, max_box - (rank - 1) * 8)
        box = pygame.Rect(x + 10, base_y - box_h, slot_w - 20, box_h)
        color = player["color"]
        draw_glass_rect(box, fill=darken(color, 0.42) + (190,), border=brighten(color, 0.38) + (130,), radius=4)
        label = font.render(str(rank), True, tdata["text"])
        SCREEN.blit(label, label.get_rect(center=box.center))
        portrait_h = max(86, 132 - (rank - 1) * 8)
        portrait_w = max(68, 94 - (rank - 1) * 5)
        portrait = pygame.Rect(x + slot_w // 2 - portrait_w // 2, box.y - portrait_h + 8, portrait_w, portrait_h)
        draw_portrait(player["color_index"], portrait, active=(rank == 1), action=None if rank == 1 else "sad")
        name = tiny_font.render(player["name"], True, brighten(color, 0.45))
        SCREEN.blit(name, name.get_rect(center=(x + slot_w // 2, base_y + 18)))


def draw_playing():
    draw_metal_background()
    draw_board()
    draw_sidebar()
    draw_top_status()
    draw_gear_button(GAME.gear_rect)
    draw_ufo_event()


def draw_score_screen():
    tdata = theme()
    draw_metal_background()
    draw_gear_button(GAME.gear_rect)
    title = title_font.render("Victory Board", True, tdata["text"])
    SCREEN.blit(title, title.get_rect(center=(WIDTH // 2, 105)))
    subtitle = font.render("Ranking, round points, and why each player scored.", True, tdata["muted_text"])
    SCREEN.blit(subtitle, subtitle.get_rect(center=(WIDTH // 2, 150)))

    breakdown = GAME.last_score_breakdown or GAME.score_breakdown()
    ranking = sorted(range(GAME.player_count), key=lambda i: (GAME.total_scores[i] if i < len(GAME.total_scores) else 0, GAME.round_scores[i] if i < len(GAME.round_scores) else 0), reverse=True)
    table_w = 1120
    row_h = 48
    x = WIDTH // 2 - table_w // 2
    y = 220
    headers = [
        ("Rank", x + 22), ("Color", x + 92), ("Played", x + 250), ("Control", x + 340),
        ("Zoids", x + 440), ("Penta", x + 530), ("Lights", x + 620), ("Reason", x + 710),
        ("Round", x + 930), ("Total", x + 1030)
    ]
    draw_metal_panel(pygame.Rect(x, y - 46, table_w, 48 + row_h * GAME.player_count))
    pygame.draw.rect(SCREEN, (90, 108, 134), (x, y - 46, table_w, 48 + row_h * GAME.player_count), 2, border_radius=8)
    for label, hx in headers:
        SCREEN.blit(small_font.render(label, True, tdata["muted_text"]), (hx, y - 30))

    reason_names = {"placed": "played shapes", "color": "controlled shapes", "zoid": "zoids", "penta": "Penta-Zoids", "lights": "lit links"}
    for rank, i in enumerate(ranking, start=1):
        player = GAME.players[i]
        row_y = y + (rank - 1) * row_h
        parts = breakdown[i] if i < len(breakdown) else {}
        best_reason = max(parts, key=lambda key: parts.get(key, 0)) if parts else "placed"
        reason = reason_names.get(best_reason, "board points")
        if rank == 1:
            reason = f"Winner: {reason}"
        pygame.draw.circle(SCREEN, player["color"], (x + 42, row_y + 25), 13)
        SCREEN.blit(font.render(str(rank), True, tdata["text"]), (x + 30, row_y + 11))
        SCREEN.blit(font.render(player["name"], True, tdata["text"]), (x + 68, row_y + 11))
        for key, hx in (("placed", x + 272), ("color", x + 358), ("zoid", x + 458), ("penta", x + 548), ("lights", x + 638)):
            SCREEN.blit(small_font.render(str(parts.get(key, 0)), True, tdata["text"]), (hx, row_y + 17))
        SCREEN.blit(small_font.render(reason, True, tdata["accent"] if rank == 1 else tdata["text"]), (x + 710, row_y + 17))
        SCREEN.blit(font.render(str(GAME.round_scores[i] if i < len(GAME.round_scores) else 0), True, tdata["text"]), (x + 940, row_y + 11))
        SCREEN.blit(font.render(str(GAME.total_scores[i] if i < len(GAME.total_scores) else 0), True, tdata["text"]), (x + 1040, row_y + 11))

    draw_victory_podium(ranking)

    rules = "Played shape: 1   Controlled shape: 2   Zoids: 2   Penta-Zoids: 3   Open same-color circuit: 1"
    SCREEN.blit(tiny_font.render(rules, True, tdata["muted_text"]), (WIDTH // 2 - 338, HEIGHT - 66))
    GAME.score_help_button = pygame.Rect(WIDTH // 2 - 476, HEIGHT - 142, 220, 46)
    GAME.new_game_button = pygame.Rect(WIDTH // 2 - 232, HEIGHT - 142, 220, 46)
    GAME.help_button = pygame.Rect(WIDTH // 2 + 12, HEIGHT - 142, 220, 46)
    GAME.next_round_button = pygame.Rect(WIDTH // 2 + 256, HEIGHT - 142, 220, 46)
    draw_button(GAME.score_help_button, "How Scoring Works")
    draw_button(GAME.new_game_button, "Start New Game")
    draw_button(GAME.help_button, "Help")
    draw_button(GAME.next_round_button, "Next Round", active=True)
    if GAME.score_help_popup:
        draw_score_help_popup()


def draw_score_help_popup():
    tdata = theme()
    shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    shade.fill((0, 0, 0, 150))
    SCREEN.blit(shade, (0, 0))
    panel = pygame.Rect(WIDTH // 2 - 450, HEIGHT // 2 - 240, 900, 440)
    draw_metal_panel(panel)
    pygame.draw.rect(SCREEN, tdata["accent"], panel, 2, border_radius=8)
    title = font.render("How Scoring Works", True, tdata["text"])
    SCREEN.blit(title, title.get_rect(center=(panel.centerx, panel.y + 42)))
    lines = [
        "Played shape: 1 point to the player who placed the shape.",
        "Controlled shape: 2 points at round end for each shape in your active color.",
        "Zoid: 2 points for each normal Zoid of your color still on the board.",
        "Penta-Zoid: 3 points for each Penta-Zoid of your color still on the board.",
        "Open same-color circuit: 1 point at round end for each lit circuit through an opened wall.",
        "Closed walls do not carry the white circuit. Open walls between different colors do not light.",
        "During play, the top score is a live estimate without final control points.",
        "The Victory Board adds the full control score and updates the running total.",
    ]
    y = panel.y + 88
    for line in lines:
        y = draw_wrapped_text(line, panel.x + 54, y, panel.width - 108, tdata["text"], small_font, 7)
        y += 8
    GAME.score_help_close_button = pygame.Rect(panel.centerx - 95, panel.bottom - 68, 190, 42)
    draw_button(GAME.score_help_close_button, "OK", active=True)


def handle_setup_click(pos):
    if GAME.gear_rect.collidepoint(pos):
        GAME.open_settings()
        return
    if GAME.help_button.collidepoint(pos):
        GAME.open_help()
        return
    if GAME.online_button.collidepoint(pos):
        GAME.open_online()
        return
    for kind, value, rect in GAME.setup_buttons:
        if not rect.collidepoint(pos):
            continue
        if kind == "players":
            GAME.player_count = value
            GAME.ai_players = {i for i in GAME.ai_players if i < value}
            if not GAME.ai_players and value > 1:
                GAME.ai_players.add(1)
            GAME.setup()
            save_player_settings(GAME)
            play_note("pluck")
            return
        if kind == "ai" and value != 0:
            if value in GAME.ai_players:
                GAME.ai_players.remove(value)
            else:
                GAME.ai_players.add(value)
            save_player_settings(GAME)
            play_note("pluck")
            return
    if GAME.start_button.collidepoint(pos):
        GAME.start()
        return


def handle_online_click(pos):
    if GAME.gear_rect.collidepoint(pos):
        GAME.open_settings()
        return
    for kind, value, rect in GAME.online_buttons:
        if not rect.collidepoint(pos):
            continue
        if kind == "focus":
            GAME.online_focus = value
            play_note("pluck")
            return
        if kind == "server_local":
            GAME.online_server_url = "http://127.0.0.1:8765"
            GAME.online_server_input = GAME.online_server_url
            GAME.online_focus = "room_code"
            GAME.online_status = "Server address set to local port 8765."
            play_note("pluck")
            return
        if kind == "refresh":
            GAME.refresh_online_lobby() if GAME.online_room_code else GAME.refresh_online_rooms()
            play_note("pluck")
            return
        if kind == "create":
            GAME.create_online_room()
            play_note("pluck")
            return
        if kind == "select_room":
            GAME.online_room_code_input = value
            GAME.online_focus = "room_code"
            GAME.refresh_online_lobby()
            play_note("pluck")
            return
        if kind == "cycle_lobby_color":
            GAME.cycle_online_seat_color()
            return
        if kind == "join":
            GAME.join_online_room()
            play_note("pluck")
            return
        if kind == "start_online":
            GAME.start_online_room()
            play_note("pluck")
            return
        if kind == "help":
            GAME.open_help()
            return
        if kind == "back":
            GAME.close_online()
            return


def handle_online_key(event):
    if event.key == pygame.K_TAB:
        fields = ["player_name", "server", "room_code"]
        try:
            idx = fields.index(GAME.online_focus)
        except ValueError:
            idx = 0
        GAME.online_focus = fields[(idx + 1) % len(fields)]
        return
    if event.key == pygame.K_RETURN:
        if GAME.online_focus == "player_name":
            GAME.online_player_display_name()
            GAME.online_focus = "server"
        elif GAME.online_focus == "server":
            GAME.apply_online_server_input()
            GAME.online_focus = "room_code"
        else:
            GAME.join_online_room()
        return
    if event.key == pygame.K_BACKSPACE:
        if GAME.online_focus == "player_name":
            GAME.online_player_name_input = GAME.online_player_name_input[:-1]
        elif GAME.online_focus == "server":
            GAME.online_server_input = GAME.online_server_input[:-1]
        else:
            GAME.online_room_code_input = GAME.online_room_code_input[:-1]
        return
    text = event.unicode or ""
    if not text or ord(text[0]) < 32:
        return
    if GAME.online_focus == "player_name":
        clean = "".join(ch for ch in text if ch.isalnum() or ch in " ._-")
        if clean and len(GAME.online_player_name_input) < 28:
            GAME.online_player_name_input += clean
    elif GAME.online_focus == "server":
        clean = "".join(ch for ch in text if ch.isalnum() or ch in ".:-_/")
        if clean and len(GAME.online_server_input) < 80:
            GAME.online_server_input += clean
    else:
        clean = "".join(ch for ch in text.upper() if ch.isalnum())
        if clean and len(GAME.online_room_code_input) < 8:
            GAME.online_room_code_input += clean


def handle_setup_right_click(pos):
    if GAME.gear_rect.collidepoint(pos):
        GAME.open_settings()
        return
    for kind, value, rect in GAME.setup_buttons:
        if kind == "ai" and rect.collidepoint(pos):
            GAME.cycle_player_color(value)
            return


def handle_settings_click(pos):
    if GAME.back_button.collidepoint(pos) or GAME.gear_rect.collidepoint(pos):
        GAME.close_settings()
        return
    if GAME.new_game_button.collidepoint(pos):
        GAME.return_to_start()
        return
    if GAME.help_button.collidepoint(pos):
        GAME.open_help()
        return
    for kind, value, rect in GAME.settings_buttons:
        if not rect.collidepoint(pos):
            continue
        if kind == "players":
            GAME.player_count = value
            GAME.ai_players = {i for i in GAME.ai_players if i < value}
            if not GAME.ai_players and value > 1:
                GAME.ai_players.add(1)
            GAME.setup()
            play_note("pluck")
            return
        if kind == "ai" and value != 0:
            if value in GAME.ai_players:
                GAME.ai_players.remove(value)
            else:
                GAME.ai_players.add(value)
            play_note("pluck")
            return
        if kind == "music_toggle":
            GAME.toggle_music()
            return
        if kind == "music_vol":
            GAME.change_music_volume(value)
            return
        if kind == "sfx_vol":
            GAME.change_sfx_volume(value)
            return
        if kind == "key":
            GAME.cycle_key()
            return
        if kind == "instrument":
            GAME.cycle_instrument(value)
            return
        if kind == "display":
            GAME.cycle_display_mode()
            return
        if kind == "theme":
            GAME.cycle_theme()
            return


def handle_settings_right_click(pos):
    for kind, value, rect in GAME.settings_buttons:
        if kind == "ai" and rect.collidepoint(pos):
            GAME.cycle_player_color(value)
            return


def handle_score_click(pos):
    if GAME.score_help_popup:
        close_rect = getattr(GAME, "score_help_close_button", pygame.Rect(0, 0, 0, 0))
        if close_rect.collidepoint(pos):
            GAME.score_help_popup = False
            play_note("pluck")
        return
    if GAME.gear_rect.collidepoint(pos):
        GAME.open_settings()
        return
    if GAME.score_help_button.collidepoint(pos):
        GAME.score_help_popup = True
        play_note("pluck")
        return
    if GAME.new_game_button.collidepoint(pos):
        GAME.return_to_start()
        return
    if GAME.help_button.collidepoint(pos):
        GAME.open_help()
        return
    if GAME.next_round_button.collidepoint(pos):
        if GAME.online_room_code and GAME.online_seat_token:
            GAME.send_online_command({"type": "next_round"})
            return
        GAME.start_next_round()


def handle_help_click(pos):
    if GAME.gear_rect.collidepoint(pos):
        GAME.open_settings()
        return
    if GAME.back_button.collidepoint(pos):
        GAME.close_help()


def handle_play_click(pos):
    if GAME.gear_rect.collidepoint(pos):
        GAME.open_settings()
        return
    if GAME.mode == "online_playing":
        handle_online_play_click(pos)
        return
    if GAME.current_is_ai():
        return
    if GAME.discard_button.collidepoint(pos):
        GAME.apply_player_command({"type": "discard", "card_index": GAME.selected_card})
        return
    if GAME.end_turn_button.collidepoint(pos):
        GAME.apply_player_command({"type": "end_turn"})
        return
    if GAME.ai_button.collidepoint(pos) and GAME.current_player != 0:
        if GAME.current_player in GAME.ai_players:
            GAME.ai_players.remove(GAME.current_player)
        else:
            GAME.ai_players.add(GAME.current_player)
        play_note("pluck")
        return
    for i, rect in GAME.card_rects:
        if rect.collidepoint(pos):
            GAME.selected_card = i
            GAME.message = f"Selected {card_label(GAME.hands[GAME.current_player][i])}."
            play_note("pluck")
            return
    if BOARD_RECT.collidepoint(pos):
        GAME.apply_player_command({"type": "play_at", "card_index": GAME.selected_card, "pos": pos})


def handle_online_play_click(pos):
    if GAME.ai_button.collidepoint(pos):
        GAME.refresh_online_game()
        return
    if GAME.online_viewer_player != GAME.current_player:
        GAME.message = "Waiting for the current online player."
        return
    hand = GAME.hands[GAME.current_player] if GAME.current_player < len(GAME.hands) else []
    if not isinstance(hand, list):
        GAME.message = "Your online hand is not visible yet. Refresh the room."
        return
    if GAME.discard_button.collidepoint(pos):
        GAME.send_online_command({"type": "discard", "card_index": GAME.selected_card})
        return
    if GAME.end_turn_button.collidepoint(pos):
        GAME.send_online_command({"type": "end_turn"})
        return
    for i, rect in GAME.card_rects:
        if rect.collidepoint(pos):
            GAME.selected_card = i
            GAME.message = f"Selected {card_label(hand[i])}."
            play_note("pluck")
            return
    if BOARD_RECT.collidepoint(pos):
        GAME.send_online_command({"type": "play_at", "card_index": GAME.selected_card, "pos": pos})


def handle_play_right_click(pos):
    if GAME.mode == "online_playing":
        if GAME.online_viewer_player != GAME.current_player:
            GAME.message = "Waiting for the current online player."
            return
        for i, rect in GAME.card_rects:
            if rect.collidepoint(pos):
                GAME.send_online_command({"type": "cycle_wild", "card_index": i})
                return
        return
    if GAME.current_is_ai():
        return
    for i, rect in GAME.card_rects:
        if rect.collidepoint(pos):
            GAME.apply_player_command({"type": "cycle_wild", "card_index": i})
            return


def apply_startup_args():
    args = set(sys.argv[1:])
    GAME.startup_online_create = "--online-create" in args
    if "--online-server" in sys.argv:
        idx = sys.argv.index("--online-server")
        if idx + 1 < len(sys.argv):
            GAME.online_server_url = normalize_server_url(sys.argv[idx + 1])
    if "--online-name" in sys.argv:
        idx = sys.argv.index("--online-name")
        if idx + 1 < len(sys.argv):
            GAME.online_player_name = sys.argv[idx + 1]
            GAME.online_player_name_input = GAME.online_player_name
    if "--online-share-server" in sys.argv:
        idx = sys.argv.index("--online-share-server")
        if idx + 1 < len(sys.argv):
            GAME.online_share_server = sys.argv[idx + 1]
    if "--online" in args or "--online-create" in args:
        GAME.open_online()


def draw_loading_frame(label):
    SCREEN.fill(BLACK)
    text = font.render(label, True, WHITE)
    SCREEN.blit(text, text.get_rect(center=(WIDTH // 2, HEIGHT // 2)))
    hint = tiny_font.render("Shape-Azoid is starting up.", True, WHITE)
    SCREEN.blit(hint, hint.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 34)))
    pygame.display.flip()
    pygame.event.pump()


def preload_assets():
    """Warm the lazy-loaded caches the setup screen needs, behind a visible
    loading frame, instead of paying for them silently on the first draw.

    load_character_images() in particular runs a pixel-by-pixel flood fill to
    strip each portrait's checker background, which is the real cost here.
    """
    steps = (
        ("Loading background...", static_background_base),
        ("Loading portraits...", load_character_images),
        ("Loading action portraits...", load_action_character_images),
        ("Loading UFO...", ufo_image),
    )
    for label, step in steps:
        draw_loading_frame(label)
        try:
            step()
        except Exception:
            pass


def advance_fixed_zoid_physics(game, accumulator_ms, elapsed_ms):
    """Advance local Zoid motion at 60 Hz while discarding long-stall time."""
    step_ms = ZOID_PHYSICS_STEP_MS
    elapsed_ms = min(max(0.0, float(elapsed_ms)), step_ms * MAX_ZOID_PHYSICS_STEPS)
    accumulator_ms = max(0.0, float(accumulator_ms)) + elapsed_ms
    step_count = min(
        int((accumulator_ms + step_ms * 1e-9) / step_ms),
        MAX_ZOID_PHYSICS_STEPS,
    )
    for _ in range(step_count):
        game.update_zoids()
    accumulator_ms -= step_count * step_ms
    if abs(accumulator_ms) < step_ms * 1e-9:
        accumulator_ms = 0.0
    return accumulator_ms, step_count


def main():
    apply_startup_args()
    preload_assets()
    running = True
    zoid_physics_accumulator_ms = 0.0
    previous_frame_ms = 0.0
    local_physics_was_active = False
    while running:
        frame_work_start = time.perf_counter()
        phase_times = {}
        event_start = time.perf_counter()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == MUSIC_END_EVENT:
                if GAME.music_enabled:
                    GAME.music_loaded = start_music()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if GAME.mode == "online":
                        GAME.close_online()
                    elif GAME.mode == "online_playing":
                        GAME.stop_online_stream()
                        GAME.mode = "online"
                        GAME.refresh_online_lobby()
                    else:
                        running = False
                elif event.key == pygame.K_F11:
                    GAME.cycle_display_mode()
                elif GAME.mode == "online":
                    handle_online_key(event)
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if GAME.mode == "setup":
                    handle_setup_click(event.pos)
                elif GAME.mode == "online":
                    handle_online_click(event.pos)
                elif GAME.mode == "settings":
                    handle_settings_click(event.pos)
                elif GAME.mode == "help":
                    handle_help_click(event.pos)
                elif GAME.mode == "score":
                    handle_score_click(event.pos)
                else:
                    handle_play_click(event.pos)
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 3:
                if GAME.mode == "setup":
                    handle_setup_right_click(event.pos)
                elif GAME.mode == "settings":
                    handle_settings_right_click(event.pos)
                elif GAME.mode in ("playing", "online_playing"):
                    handle_play_right_click(event.pos)
        phase_times["events_ms"] = (time.perf_counter() - event_start) * 1000.0

        if GAME.mode != "playing":
            zoid_physics_accumulator_ms = 0.0
            local_physics_was_active = False

        if GAME.mode == "setup":
            draw_start = time.perf_counter()
            draw_setup()
            phase_times["draw_ms"] = (time.perf_counter() - draw_start) * 1000.0
        elif GAME.mode == "online":
            update_start = time.perf_counter()
            GAME.poll_online_lobby()
            phase_times["update_ms"] = (time.perf_counter() - update_start) * 1000.0
            draw_start = time.perf_counter()
            draw_online_screen()
            phase_times["draw_ms"] = (time.perf_counter() - draw_start) * 1000.0
        elif GAME.mode == "settings":
            draw_start = time.perf_counter()
            draw_settings()
            phase_times["draw_ms"] = (time.perf_counter() - draw_start) * 1000.0
        elif GAME.mode == "help":
            draw_start = time.perf_counter()
            draw_help()
            phase_times["draw_ms"] = (time.perf_counter() - draw_start) * 1000.0
        elif GAME.mode == "score":
            update_start = time.perf_counter()
            if GAME.online_room_code and GAME.online_seat_token:
                GAME.start_online_stream()
                GAME.consume_online_stream()
                if (
                    not GAME.online_stream_healthy()
                    and pygame.time.get_ticks() - GAME.online_last_refresh_ms >= GAME.online_poll_interval()
                ):
                    GAME.refresh_online_game()
            phase_times["update_ms"] = (time.perf_counter() - update_start) * 1000.0
            draw_start = time.perf_counter()
            draw_score_screen()
            phase_times["draw_ms"] = (time.perf_counter() - draw_start) * 1000.0
        elif GAME.mode == "online_playing":
            update_start = time.perf_counter()
            GAME.start_online_stream()
            GAME.consume_online_stream()
            if (
                not GAME.online_stream_healthy()
                and pygame.time.get_ticks() - GAME.online_last_refresh_ms >= GAME.online_poll_interval()
            ):
                GAME.refresh_online_game()
            phase_times["update_ms"] = (time.perf_counter() - update_start) * 1000.0
            draw_start = time.perf_counter()
            draw_playing()
            phase_times["draw_ms"] = (time.perf_counter() - draw_start) * 1000.0
        else:
            update_start = time.perf_counter()
            physics_elapsed_ms = previous_frame_ms if local_physics_was_active else 0.0
            zoid_physics_accumulator_ms, _physics_steps = advance_fixed_zoid_physics(
                GAME,
                zoid_physics_accumulator_ms,
                physics_elapsed_ms,
            )
            local_physics_was_active = True
            GAME.update_ufo()
            phase_times["update_ms"] = (time.perf_counter() - update_start) * 1000.0
            draw_start = time.perf_counter()
            draw_playing()
            phase_times["draw_ms"] = (time.perf_counter() - draw_start) * 1000.0
            ai_start = time.perf_counter()
            GAME.maybe_ai_turn()
            phase_times["ai_ms"] = (time.perf_counter() - ai_start) * 1000.0

        flip_start = time.perf_counter()
        pygame.display.flip()
        phase_times["flip_ms"] = (time.perf_counter() - flip_start) * 1000.0
        phase_times["work_ms"] = (time.perf_counter() - frame_work_start) * 1000.0
        frame_ms = CLOCK.tick(60)
        phase_times["wait_ms"] = max(0.0, float(frame_ms) - phase_times["work_ms"])
        GAME.telemetry_tick(frame_ms, phase_times=phase_times)
        previous_frame_ms = frame_ms

    if getattr(GAME, "telemetry", None) is not None:
        GAME.telemetry.close()
    GAME.stop_online_stream()
    if GAME.online_server_process is not None:
        GAME.online_server_process.terminate()
        try:
            GAME.online_server_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            GAME.online_server_process.kill()
            GAME.online_server_process.wait(timeout=5)
        clear_owned_online_address_files(GAME.online_share_server)
    if GAME.online_server_log is not None:
        try:
            GAME.online_server_log.close()
        except Exception:
            pass
    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
