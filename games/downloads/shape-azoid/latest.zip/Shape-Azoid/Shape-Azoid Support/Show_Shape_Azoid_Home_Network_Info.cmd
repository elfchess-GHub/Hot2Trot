@echo off
setlocal
cd /d "%~dp0"
set "SUPPORT_DIR=%~dp0Shape-Azoid Support"
if exist "%SUPPORT_DIR%\tools\Show_Shape_Azoid_Home_Network_Info.cmd" (
  call "%SUPPORT_DIR%\tools\Show_Shape_Azoid_Home_Network_Info.cmd"
) else (
  call "%~dp0tools\Show_Shape_Azoid_Home_Network_Info.cmd"
)
