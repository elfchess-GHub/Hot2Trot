import argparse
import hashlib
import json
import subprocess
import tempfile
import zipfile
from pathlib import Path


RELEASE_URL = (
    "https://github.com/elfchess-GHub/Hot2Trot/releases/download/"
    "shape-azoid-v0.7.33/Shape-Azoid-v0.7.33.zip"
)
REQUIRED_FILES = {
    "Shape-Azoid/BUILD_ID.txt",
    "Shape-Azoid/PACKAGE_FILES.json",
    "Shape-Azoid/Shape-Azoid.exe",
    "Shape-Azoid/Play Shape-Azoid.exe",
    "Shape-Azoid/Update Shape-Azoid.ps1",
}


def powershell_literal(value):
    return str(value).replace("'", "''")


def read_release(zip_path):
    with zipfile.ZipFile(zip_path) as archive:
        names = {info.filename for info in archive.infolist() if not info.is_dir()}
        missing = REQUIRED_FILES - names
        assert not missing, f"Missing package files: {sorted(missing)}"
        assert not any("/.venv/" in name for name in names), "Package contains a development .venv"
        roots = {name.split("/", 1)[0] for name in names}
        assert roots == {"Shape-Azoid"}, f"Unexpected package roots: {sorted(roots)}"
        build_id = archive.read("Shape-Azoid/BUILD_ID.txt").decode("ascii").strip()
        package_manifest = json.loads(
            archive.read("Shape-Azoid/PACKAGE_FILES.json").decode("ascii")
        )
        managed_files = set(package_manifest["files"])
        assert package_manifest["version"] == 1
        assert "Shape-Azoid.exe" in managed_files
        assert "settings.json" not in managed_files
        assert not any(".venv" in Path(name).parts for name in managed_files)
        updater = archive.read("Shape-Azoid/Update Shape-Azoid.ps1").decode("ascii")
        packaged_exe = archive.read("Shape-Azoid/Shape-Azoid.exe")
    return build_id, updater, packaged_exe, len(names), len(managed_files)


def apply_release(zip_path, build_id, updater, packaged_exe, package_hash):
    with tempfile.TemporaryDirectory(prefix="shape_azoid_full_release_") as temp_dir:
        root = Path(temp_dir) / "installed"
        root.mkdir()
        updater_path = root / "Update Shape-Azoid.ps1"
        updater_path.write_text(updater, encoding="ascii")
        (root / "BUILD_ID.txt").write_text("v0.7.32-20260708-1311\n", encoding="ascii")
        (root / "Shape-Azoid.exe").write_bytes(b"stale-game-executable")
        old_manifest = {
            "version": 1,
            "files": [
                "BUILD_ID.txt",
                "Shape-Azoid.exe",
                "Update Shape-Azoid.ps1",
                "music/obsolete-packaged-track.mp3",
            ],
        }
        (root / "PACKAGE_FILES.json").write_text(
            json.dumps(old_manifest, indent=2) + "\n",
            encoding="ascii",
        )
        music_dir = root / "music"
        music_dir.mkdir()
        obsolete_track = music_dir / "obsolete-packaged-track.mp3"
        obsolete_track.write_bytes(b"old-packaged-track")
        custom_track = music_dir / "jeremys-custom-track.mp3"
        custom_track.write_bytes(b"user-added-track")
        settings = root / "settings.json"
        settings.write_text('{"graphics":{"theme":"atomic_dark"}}\n', encoding="ascii")
        runtime_marker = root / ".venv" / "user-machine-runtime.txt"
        runtime_marker.parent.mkdir()
        runtime_marker.write_text("keep local runtime\n", encoding="ascii")
        manifest = json.dumps(
            {
                "build_id": build_id,
                "download_url": RELEASE_URL,
                "sha256": package_hash,
            },
            separators=(",", ":"),
        )
        command = f"""
function Invoke-WebRequest {{
    param([string]$Uri, [string]$OutFile, [switch]$UseBasicParsing, [int]$TimeoutSec)
    if ($OutFile) {{
        Copy-Item -LiteralPath '{powershell_literal(zip_path)}' -Destination $OutFile -Force
        return
    }}
    [pscustomobject]@{{ Content = '{powershell_literal(manifest)}' }}
}}
& '{powershell_literal(updater_path)}'
"""
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
            capture_output=True,
            text=True,
            timeout=120,
        )
        output = result.stdout + result.stderr
        assert result.returncode == 0, output
        assert "Shape-Azoid update complete." in output, output
        assert (root / "BUILD_ID.txt").read_text(encoding="ascii").strip() == build_id
        assert (root / "Shape-Azoid.exe").read_bytes() == packaged_exe
        assert not obsolete_track.exists()
        assert custom_track.read_bytes() == b"user-added-track"
        assert settings.read_text(encoding="ascii") == '{"graphics":{"theme":"atomic_dark"}}\n'
        assert runtime_marker.read_text(encoding="ascii") == "keep local runtime\n"


def main():
    parser = argparse.ArgumentParser(description="Verify a complete Shape-Azoid release ZIP and updater.")
    parser.add_argument("zip_path", type=Path)
    args = parser.parse_args()
    zip_path = args.zip_path.resolve()
    assert zip_path.is_file(), f"Release ZIP not found: {zip_path}"
    package_hash = hashlib.sha256(zip_path.read_bytes()).hexdigest()
    build_id, updater, packaged_exe, file_count, managed_count = read_release(zip_path)
    assert "latest-release.json" in updater
    assert "/releases/download/" in updater
    assert "System.Security.Cryptography.SHA256" in updater
    assert "latest.zip" not in updater
    assert "public updates are disabled" not in updater
    apply_release(zip_path, build_id, updater, packaged_exe, package_hash)
    print(f"PASS: package layout and required files ({file_count} files)")
    print("PASS: package excludes the development .venv")
    print(f"PASS: package manifest owns {managed_count} files but excludes settings and .venv")
    print("PASS: packaged updater uses a hashed GitHub Release asset")
    print("PASS: exact full package updates a simulated v0.7.32 installation")
    print("PASS: update removes obsolete package files and preserves user settings, music, and .venv")
    print(f"BUILD_ID: {build_id}")
    print(f"SHA256: {package_hash}")
    print("Shape-Azoid release package probe: 6/6 passed")


if __name__ == "__main__":
    main()
