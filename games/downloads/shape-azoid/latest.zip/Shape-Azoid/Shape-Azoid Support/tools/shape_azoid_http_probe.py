import os
import sys
import tempfile
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


try:
    from fastapi.testclient import TestClient
except ImportError:
    print("SKIP FastAPI is not installed. Run: pip install -r requirements.txt")
    raise SystemExit(0)

from network.shape_azoid_server import app, service
from shape_azoid_core import BOARD_CENTER, make_card, midpoint, side_list, centroid, dist


def near_wall_click(wall, pixels=38):
    a, b = wall
    mid = midpoint(a, b)
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    length = dist(a, b) or 1.0
    return (mid[0] - dy / length * pixels, mid[1] + dx / length * pixels)


def main():
    service.rooms.clear()
    client = TestClient(app)

    response = client.get("/api/health")
    assert response.status_code == 200, response.text
    assert response.json()["ok"] is True
    print("PASS health endpoint")

    response = client.post("/api/rooms", json={"host_name": "Jeremy", "player_count": 2, "ai_players": [], "start": False})
    assert response.status_code == 200, response.text
    lobby = response.json()
    lobby_code = lobby["room_code"]
    host_lobby_token = lobby["host_seat_token"]
    response = client.get("/api/rooms")
    assert response.status_code == 200, response.text
    listed = response.json()
    assert listed["ok"] is True
    assert listed["rooms"][0]["room_code"] == lobby_code
    assert listed["rooms"][0]["phase"] == "lobby"
    print("PASS room listing endpoint")
    response = client.get(f"/api/rooms/{lobby_code}", params={"seat_token": host_lobby_token})
    assert response.status_code == 200, response.text
    assert response.json()["phase"] == "lobby"
    assert response.json()["state"]["deck_count"] == 0
    response = client.post(f"/api/rooms/{lobby_code}/join", json={"player_name": "Guest"})
    assert response.status_code == 200, response.text
    guest_lobby_token = response.json()["seat_token"]
    response = client.post(f"/api/rooms/{lobby_code}/join", json={"player_name": "Guest", "seat_token": guest_lobby_token})
    assert response.status_code == 200, response.text
    assert response.json()["seat_token"] == guest_lobby_token
    assert len(response.json()["seats"]) == 2
    response = client.post(f"/api/rooms/{lobby_code}/seat", json={"seat_token": guest_lobby_token, "color_index": 2})
    assert response.status_code == 200, response.text
    assert response.json()["seats"][1]["color_name"] == "Yellow"
    response = client.post(f"/api/rooms/{lobby_code}/seat", json={"seat_token": guest_lobby_token, "color_index": 0})
    assert response.status_code == 400, response.text
    response = client.post(f"/api/rooms/{lobby_code}/start", json={"seat_token": guest_lobby_token})
    assert response.status_code == 403, response.text
    response = client.post(f"/api/rooms/{lobby_code}/start", json={"seat_token": host_lobby_token})
    assert response.status_code == 200, response.text
    assert response.json()["phase"] == "playing"
    print("PASS lobby join, color, and host start endpoints")

    response = client.post("/api/rooms", json={"host_name": "Jeremy", "player_count": 2, "ai_players": []})
    assert response.status_code == 200, response.text
    created = response.json()
    room_code = created["room_code"]
    host_token = created["host_seat_token"]
    guest_token = service.rooms[room_code]["seat_tokens"][1]
    print("PASS room creation")

    response = client.get(f"/api/rooms/{room_code}", params={"seat_token": host_token})
    assert response.status_code == 200, response.text
    host_view = response.json()
    assert host_view["viewer_player"] == 0
    assert isinstance(host_view["state"]["hands"][1], dict)
    print("PASS sanitized host snapshot")

    response = client.post(
        f"/api/rooms/{room_code}/commands",
        json={"seat_token": guest_token, "command": {"type": "end_turn"}},
    )
    assert response.status_code == 403, response.text
    print("PASS inactive seat rejected")

    game = service.rooms[room_code]["game"]
    game.hands[0] = [make_card("hex", 0)]
    response = client.post(
        f"/api/rooms/{room_code}/commands",
        json={"seat_token": host_token, "command": {"type": "play_at", "card_index": 0, "pos": BOARD_CENTER}},
    )
    assert response.status_code == 200, response.text
    placement = response.json()
    assert placement["ok"] is True
    assert placement["state_revision"] == 1
    response = client.get(f"/api/rooms/{room_code}", params={"seat_token": host_token})
    assert response.status_code == 200, response.text
    assert len(response.json()["state"]["pieces"]) == 1
    game.hands[0] = [make_card("square", 0)]
    attach_pos = midpoint(*side_list(game.pieces[0]["points"])[0])
    response = client.post(
        f"/api/rooms/{room_code}/commands",
        json={"seat_token": host_token, "command": {"type": "play_at", "card_index": 0, "pos": attach_pos}},
    )
    assert response.status_code == 200, response.text
    attached = response.json()
    assert attached["ok"] is True
    assert attached["state_revision"] == 2
    response = client.get(f"/api/rooms/{room_code}", params={"seat_token": host_token})
    assert response.status_code == 200, response.text
    assert len(response.json()["state"]["pieces"]) == 2
    print("PASS active shape placement and attachment endpoint")

    shared_wall = next(key for key, entries in game.shared_edges().items() if len(entries) == 2)
    wall_midpoint = near_wall_click(shared_wall)
    game.hands[0] = [make_card("line", 0)]
    response = client.post(
        f"/api/rooms/{room_code}/commands",
        json={"seat_token": host_token, "command": {"type": "play_at", "card_index": 0, "pos": wall_midpoint}},
    )
    assert response.status_code == 200, response.text
    opened = response.json()
    assert opened["ok"] is True
    assert opened["state_revision"] == 3
    response = client.get(f"/api/rooms/{room_code}", params={"seat_token": host_token})
    assert response.status_code == 200, response.text
    assert len(response.json()["state"]["open_walls"]) == 1
    print("PASS active line card near-click endpoint")

    response = client.post(
        f"/api/rooms/{room_code}/commands",
        json={"seat_token": host_token, "command": {"type": "play_at", "card_index": None, "pos": wall_midpoint}},
    )
    assert response.status_code == 400, response.text
    assert "Select a card" in response.text
    print("PASS empty card selection endpoint")

    ball_pos = centroid(game.pieces[0]["points"])
    game.hands[0] = [make_card("zoid", 0)]
    response = client.post(
        f"/api/rooms/{room_code}/commands",
        json={"seat_token": host_token, "command": {"type": "play_at", "card_index": 0, "pos": ball_pos}},
    )
    assert response.status_code == 200, response.text
    zoid = response.json()
    assert zoid["ok"] is True
    assert zoid["state_revision"] == 4
    response = client.get(f"/api/rooms/{room_code}", params={"seat_token": host_token})
    assert response.status_code == 200, response.text
    assert len(response.json()["state"]["zoids"]) == 1

    penta_pos = (ball_pos[0], ball_pos[1] + 45)
    game.hands[0] = [make_card("pentagon", 0)]
    response = client.post(
        f"/api/rooms/{room_code}/commands",
        json={"seat_token": host_token, "command": {"type": "play_at", "card_index": 0, "pos": penta_pos}},
    )
    assert response.status_code == 200, response.text
    penta = response.json()
    assert penta["ok"] is True
    assert penta["state_revision"] == 5
    assert len(game.zoids) == 2
    assert game.zoids[1]["kind"] == "penta"
    game.zoids[0]["pos"] = [ball_pos[0], ball_pos[1]]
    game.zoids[0]["vel"] = [0.0, 0.0]
    game.zoids[1]["pos"] = [ball_pos[0], ball_pos[1] + 45]
    game.zoids[1]["vel"] = [0.0, 0.0]
    response = client.get(f"/api/rooms/{room_code}", params={"seat_token": host_token})
    assert response.status_code == 200, response.text
    assert len(response.json()["state"]["zoids"]) == 2

    game.hands[0] = [make_card("zoid", 1)]
    response = client.post(
        f"/api/rooms/{room_code}/commands",
        json={"seat_token": host_token, "command": {"type": "play_at", "card_index": 0, "pos": ball_pos}},
    )
    assert response.status_code == 400, response.text
    assert "Orange" in response.text
    assert len(game.hands[0]) == 1
    print("PASS active Zoid and Penta-Zoid placement endpoint")

    game.pieces[1]["owner"] = 1
    first_center = centroid(game.pieces[0]["points"])
    second_center = centroid(game.pieces[1]["points"])
    dx = second_center[0] - first_center[0]
    dy = second_center[1] - first_center[1]
    length = dist(first_center, second_center) or 1.0
    game.zoids[0]["pos"] = [first_center[0], first_center[1]]
    game.zoids[0]["piece"] = 0
    game.zoids[0]["vel"] = [dx / length * 8.0, dy / length * 8.0]
    game.zoids[1]["pos"] = [first_center[0], first_center[1] + 45]
    game.zoids[1]["vel"] = [0.0, 0.0]
    for _ in range(80):
        game.update_zoids()
        if game.zoids[0]["piece"] == 1:
            break
    assert game.zoids[0]["piece"] == 1
    assert game.pieces[1]["owner"] == 0
    response = client.get(f"/api/rooms/{room_code}", params={"seat_token": host_token})
    assert response.status_code == 200, response.text
    assert response.json()["state"]["zoids"][0]["piece"] == 1
    assert response.json()["state"]["pieces"][1]["owner"] == 0
    print("PASS active Zoid movement endpoint snapshot")

    game.zoids = [
        {
            "pos": [first_center[0], first_center[1]],
            "vel": [0.0, 0.0],
            "owner": 0,
            "played_by": 0,
            "piece": 0,
            "kind": "zoid",
            "visited": {0},
        },
        {
            "pos": [first_center[0] + 1, first_center[1]],
            "vel": [0.0, 0.0],
            "owner": 1,
            "played_by": 1,
            "piece": 0,
            "kind": "penta",
            "visited": {0},
        },
    ]
    game.update_zoids()
    response = client.get(f"/api/rooms/{room_code}", params={"seat_token": host_token})
    assert response.status_code == 200, response.text
    assert len(response.json()["state"]["zoids"]) == 1
    assert response.json()["state"]["zoids"][0]["kind"] == "penta"
    game.zoids = [
        {
            "pos": [first_center[0], first_center[1]],
            "vel": [0.0, 0.0],
            "owner": 0,
            "played_by": 0,
            "piece": 0,
            "kind": "penta",
            "visited": {0},
        },
        {
            "pos": [first_center[0] + 1, first_center[1]],
            "vel": [0.0, 0.0],
            "owner": 1,
            "played_by": 1,
            "piece": 0,
            "kind": "penta",
            "visited": {0},
        },
    ]
    game.update_zoids()
    response = client.get(f"/api/rooms/{room_code}", params={"seat_token": host_token})
    assert response.status_code == 200, response.text
    assert len(response.json()["state"]["zoids"]) == 0
    print("PASS Penta-Zoid collision endpoint snapshot")

    game.zoids = [
        {
            "pos": [first_center[0], first_center[1]],
            "vel": [0.0, 0.0],
            "owner": 0,
            "played_by": 0,
            "piece": 0,
            "kind": "zoid",
            "visited": {0},
        },
        {
            "pos": [second_center[0], second_center[1]],
            "vel": [0.0, 0.0],
            "owner": 1,
            "played_by": 1,
            "piece": 1,
            "kind": "penta",
            "visited": {1},
        },
    ]

    game.hands[0] = [make_card("square", 0)]
    response = client.post(
        f"/api/rooms/{room_code}/commands",
        json={"seat_token": host_token, "command": {"type": "discard", "card_index": 0}},
    )
    assert response.status_code == 200, response.text
    result = response.json()
    assert result["ok"] is True
    assert result["state_revision"] == 6
    print("PASS active discard command endpoint")

    with tempfile.TemporaryDirectory() as tmp:
        service.save_dir = Path(tmp)
        response = client.post(f"/api/rooms/{room_code}/save")
        assert response.status_code == 200, response.text
        saved_path = Path(response.json()["path"])
        assert saved_path.exists()
        service.rooms.clear()
        response = client.post(f"/api/rooms/{room_code}/load")
        assert response.status_code == 200, response.text
        loaded = response.json()
        assert loaded["state"]["state_revision"] == 6
        assert loaded["state"]["action_log"][-1]["type"] == "discard"
        assert len(loaded["state"]["pieces"]) == 2
        assert len(loaded["state"]["open_walls"]) == 1
        assert len(loaded["state"]["zoids"]) == 2
    print("PASS save and load endpoints")

    response = client.post("/api/rooms", json={"host_name": "Jeremy", "player_count": 2, "ai_players": []})
    assert response.status_code == 200, response.text
    ufo_room = response.json()
    ufo_code = ufo_room["room_code"]
    ufo_token = ufo_room["host_seat_token"]
    ufo_game = service.rooms[ufo_code]["game"]
    ufo_game.hands[0] = [make_card("hex", 0)]
    response = client.post(
        f"/api/rooms/{ufo_code}/commands",
        json={"seat_token": ufo_token, "command": {"type": "play_at", "card_index": 0, "pos": BOARD_CENTER}},
    )
    assert response.status_code == 200, response.text
    ufo_game.next_ufo_at = 1000
    ufo_game.update_ufo(1000)
    assert ufo_game.active_ufo is not None
    assert ufo_game.active_ufo["target_idx"] == 0
    ufo_game.update_ufo(ufo_game.active_ufo["hit_at"])
    response = client.get(f"/api/rooms/{ufo_code}", params={"seat_token": ufo_token})
    assert response.status_code == 200, response.text
    assert len(response.json()["state"]["pieces"]) == 0
    assert response.json()["state"]["message"].startswith("UFO blasted")
    print("PASS UFO tile destruction endpoint")

    game = service.rooms[room_code]["game"]
    game.mode = "playing"
    game.current_player = 0
    game.last_card_drawn = True
    game.no_discard_turns_after_empty = game.player_count - 1
    game.discarded_this_turn = False
    response = client.post(
        f"/api/rooms/{room_code}/commands",
        json={"seat_token": host_token, "command": {"type": "end_turn"}},
    )
    assert response.status_code == 200, response.text
    response = client.get(f"/api/rooms/{room_code}", params={"seat_token": host_token})
    assert response.status_code == 200, response.text
    scored = response.json()
    assert scored["state"]["mode"] == "score"
    assert scored["state"]["players"][0]["score_round"] == 6
    assert scored["state"]["players"][0]["score_total"] == 6
    assert scored["state"]["players"][1]["score_round"] == 5
    assert scored["state"]["players"][1]["score_total"] == 5
    assert scored["state"]["last_score_breakdown"][0]["placed"] == 2
    assert scored["state"]["last_score_breakdown"][0]["color"] == 2
    assert scored["state"]["last_score_breakdown"][0]["zoid"] == 2
    assert scored["state"]["last_score_breakdown"][0]["lights"] == 0
    assert scored["state"]["last_score_breakdown"][1]["color"] == 2
    assert scored["state"]["last_score_breakdown"][1]["penta"] == 3
    print("PASS round-end scoring endpoint")
    print("RESULT 8/8 HTTP endpoint probes passed")


if __name__ == "__main__":
    main()
