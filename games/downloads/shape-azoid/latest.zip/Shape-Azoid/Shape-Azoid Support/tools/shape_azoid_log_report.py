from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_LOG_DIRS = [
    ROOT / "logs",
    ROOT.parent / "Shape-Azoid-portable" / "logs",
    ROOT.parent / "Shape-Azoid-portable" / "Shape-Azoid Support" / "logs",
]


def fmt_ms(value):
    if value is None:
        return "n/a"
    return f"{value:.1f} ms"


def percentile(values, pct):
    if not values:
        return None
    values = sorted(values)
    index = int(round((pct / 100.0) * (len(values) - 1)))
    return values[max(0, min(index, len(values) - 1))]


def iter_log_files(paths):
    if paths:
        candidates = [Path(path) for path in paths]
    else:
        candidates = DEFAULT_LOG_DIRS
    found = []
    for candidate in candidates:
        if candidate.is_dir():
            found.extend(candidate.glob("shape_azoid_run_*.jsonl"))
        elif candidate.is_file():
            found.append(candidate)
    return sorted(set(found), key=lambda path: path.stat().st_mtime)


def read_rows(path):
    rows = []
    errors = 0
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                errors += 1
    return rows, errors


def nested(row, *keys):
    current = row
    for key in keys:
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    return current


def summarize_file(path):
    rows, errors = read_rows(path)
    kinds = Counter(row.get("kind", "unknown") for row in rows)
    versions = sorted({row.get("version") for row in rows if row.get("version")})
    ticks = [row.get("tick_ms") for row in rows if isinstance(row.get("tick_ms"), (int, float))]
    duration_ms = (max(ticks) - min(ticks)) if ticks else 0
    tick_gaps = [b - a for a, b in zip(ticks, ticks[1:]) if isinstance(a, (int, float)) and isinstance(b, (int, float))]

    frame_rows = [row for row in rows if isinstance(row.get("frame_ms"), (int, float))]
    frame_values = [float(row["frame_ms"]) for row in frame_rows]
    play_frame_rows = [row for row in frame_rows if row.get("mode") not in {None, "setup"}]
    play_frame_values = [float(row["frame_ms"]) for row in play_frame_rows]
    slow_rows = [row for row in rows if row.get("kind") == "slow_frame"]
    play_slow_rows = [row for row in slow_rows if row.get("mode") != "setup"]
    slow_by_mode = Counter(row.get("mode", "unknown") for row in slow_rows)
    slow_messages = Counter(row.get("message", "") for row in slow_rows)
    phase_values = defaultdict(list)
    slow_phase_values = defaultdict(list)
    for row in frame_rows:
        phases = row.get("phase_ms")
        if not isinstance(phases, dict):
            continue
        for key, value in phases.items():
            if isinstance(value, (int, float)):
                phase_values[key].append(float(value))
                if row.get("kind") == "slow_frame":
                    slow_phase_values[key].append(float(value))

    line_rows = [row for row in rows if row.get("kind") == "line_attempt"]
    line_ok = sum(1 for row in line_rows if row.get("ok"))
    line_fail = len(line_rows) - line_ok
    line_fail_messages = Counter(row.get("message", "") for row in line_rows if not row.get("ok"))
    line_distances = [
        float(nested(row, "diagnostic", "nearest_shared_wall", "distance"))
        for row in line_rows
        if isinstance(nested(row, "diagnostic", "nearest_shared_wall", "distance"), (int, float))
    ]
    line_no_target = sum(1 for row in line_rows if not nested(row, "diagnostic", "target_found"))
    line_open_clicked = sum(1 for row in line_rows if nested(row, "diagnostic", "nearest_shared_wall", "is_open"))
    line_outside_tolerance = sum(
        1
        for row in line_rows
        if nested(row, "diagnostic", "nearest_shared_wall") is not None
        and not nested(row, "diagnostic", "nearest_shared_wall", "within_tolerance")
    )

    command_rows = [row for row in rows if row.get("kind") == "online_command"]
    command_by_type = defaultdict(list)
    command_failures = []
    for row in command_rows:
        command_type = row.get("command_type", "unknown")
        elapsed = row.get("elapsed_ms")
        if isinstance(elapsed, (int, float)):
            command_by_type[command_type].append(float(elapsed))
        if not row.get("ok"):
            command_failures.append(row)

    state_rows = [row for row in rows if row.get("kind") in {"play_state", "slow_frame"}]
    max_fields = {}
    for field in [
        "pieces",
        "zoids",
        "shared_walls",
        "open_shared_walls",
        "closed_shared_walls",
        "open_walls",
        "deck_count",
        "discard_count",
        "explosions",
    ]:
        values = [row.get(field) for row in state_rows if isinstance(row.get(field), (int, float))]
        max_fields[field] = max(values) if values else None

    online_rows = [row for row in state_rows if row.get("online_room")]
    ws_unhealthy = [
        row
        for row in online_rows
        if row.get("online_ws_connected") is False or row.get("online_ws_healthy") is False
    ]
    ws_ages = [row.get("online_ws_age_ms") for row in online_rows if isinstance(row.get("online_ws_age_ms"), (int, float))]

    problems = []
    if kinds.get("run_end", 0) == 0:
        problems.append("missing run_end")
    if errors:
        problems.append(f"{errors} malformed JSON lines")
    if play_frame_values and max(play_frame_values) >= 500:
        problems.append(f"very slow in-play frame: {fmt_ms(max(play_frame_values))}")
    if command_failures:
        problems.append(f"{len(command_failures)} failed online commands")
    if line_fail:
        problems.append(f"{line_fail} failed line attempts")
    if ws_unhealthy:
        problems.append(f"{len(ws_unhealthy)} unhealthy online/WebSocket state rows")

    return {
        "path": path,
        "rows": rows,
        "errors": errors,
        "kinds": kinds,
        "versions": versions,
        "duration_ms": duration_ms,
        "tick_gaps": tick_gaps,
        "frame_values": frame_values,
        "play_frame_values": play_frame_values,
        "slow_rows": slow_rows,
        "play_slow_rows": play_slow_rows,
        "slow_by_mode": slow_by_mode,
        "slow_messages": slow_messages,
        "phase_values": phase_values,
        "slow_phase_values": slow_phase_values,
        "line_rows": line_rows,
        "line_ok": line_ok,
        "line_fail": line_fail,
        "line_fail_messages": line_fail_messages,
        "line_distances": line_distances,
        "line_no_target": line_no_target,
        "line_open_clicked": line_open_clicked,
        "line_outside_tolerance": line_outside_tolerance,
        "command_by_type": command_by_type,
        "command_failures": command_failures,
        "max_fields": max_fields,
        "online_rows": online_rows,
        "ws_unhealthy": ws_unhealthy,
        "ws_ages": ws_ages,
        "problems": problems,
    }


def print_summary(summary):
    path = summary["path"]
    print(f"\n=== {path} ===")
    print(f"version: {', '.join(summary['versions']) or 'unknown'}")
    print(f"rows: {sum(summary['kinds'].values())} | duration: {summary['duration_ms'] / 1000:.1f}s")
    print(f"kinds: {', '.join(f'{kind}={count}' for kind, count in sorted(summary['kinds'].items()))}")
    if summary["problems"]:
        print(f"flags: {', '.join(summary['problems'])}")
    else:
        print("flags: none")

    frame_values = summary["frame_values"]
    if frame_values:
        print(
            "frames: "
            f"max={fmt_ms(max(frame_values))}, "
            f"p95={fmt_ms(percentile(frame_values, 95))}, "
            f"slow_count={len(summary['slow_rows'])}"
        )
        play_frame_values = summary["play_frame_values"]
        if play_frame_values:
            print(
                "in-play frames: "
                f"max={fmt_ms(max(play_frame_values))}, "
                f"p95={fmt_ms(percentile(play_frame_values, 95))}, "
                f"slow_count={len(summary['play_slow_rows'])}"
            )
        if summary["slow_by_mode"]:
            print("slow by mode: " + ", ".join(f"{mode}={count}" for mode, count in summary["slow_by_mode"].most_common()))
        for message, count in summary["slow_messages"].most_common(5):
            if message:
                print(f"slow message {count}x: {message}")

    if summary["phase_values"]:
        print("phase timing:")
        for key in ["events_ms", "update_ms", "draw_ms", "ai_ms", "flip_ms", "work_ms", "wait_ms"]:
            values = summary["phase_values"].get(key)
            if not values:
                continue
            slow_values = summary["slow_phase_values"].get(key, [])
            slow_part = f", slow_max={max(slow_values):.1f} ms" if slow_values else ""
            print(
                f"  {key}: p95={percentile(values, 95):.1f} ms, "
                f"max={max(values):.1f} ms{slow_part}"
            )

    tick_gaps = summary["tick_gaps"]
    if tick_gaps:
        print(f"log gap max: {fmt_ms(max(tick_gaps))}")

    print(
        "line attempts: "
        f"total={len(summary['line_rows'])}, ok={summary['line_ok']}, failed={summary['line_fail']}, "
        f"no_target={summary['line_no_target']}, open_clicked={summary['line_open_clicked']}, "
        f"outside_tolerance={summary['line_outside_tolerance']}"
    )
    if summary["line_distances"]:
        print(
            "line distance: "
            f"max={summary['line_distances'] and max(summary['line_distances']):.2f}px, "
            f"p95={percentile(summary['line_distances'], 95):.2f}px"
        )
    for message, count in summary["line_fail_messages"].most_common(5):
        print(f"line failure {count}x: {message}")

    if summary["command_by_type"]:
        print("online commands:")
        for command_type, values in sorted(summary["command_by_type"].items()):
            print(
                f"  {command_type}: count={len(values)}, "
                f"avg={sum(values) / len(values):.1f} ms, max={max(values):.1f} ms"
            )
    if summary["command_failures"]:
        for row in summary["command_failures"][:5]:
            print(f"online failure: {row.get('command_type')} -> {row.get('error')}")

    if summary["online_rows"]:
        print(
            "websocket: "
            f"online_rows={len(summary['online_rows'])}, unhealthy={len(summary['ws_unhealthy'])}, "
            f"max_age={fmt_ms(max(summary['ws_ages']) if summary['ws_ages'] else None)}"
        )

    maxima = summary["max_fields"]
    print(
        "max state: "
        + ", ".join(f"{field}={value}" for field, value in maxima.items() if value is not None)
    )


def main():
    parser = argparse.ArgumentParser(description="Summarize Shape-Azoid runtime telemetry logs.")
    parser.add_argument("paths", nargs="*", help="Log files or folders. Defaults to known Shape-Azoid log folders.")
    parser.add_argument("--latest", action="store_true", help="Only summarize the newest matching log.")
    args = parser.parse_args()

    files = iter_log_files(args.paths)
    if args.latest and files:
        files = [files[-1]]
    if not files:
        print("No Shape-Azoid telemetry logs found.")
        return 1

    for path in files:
        print_summary(summarize_file(path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
