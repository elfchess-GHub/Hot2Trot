import os
import sys
import time
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from network.shape_azoid_room_service import ShapeAzoidRoomService


def main():
    service = ShapeAzoidRoomService()
    room = service.create_room(host_name="Jeremy", player_count=2, ai_players=[1], start=True)
    room_code = room["room_code"]
    host_token = room["host_seat_token"]

    first = service.snapshot(room_code, seat_token=host_token)
    assert first["state"]["players"][1]["is_ai"] is True
    assert first["state"]["current_player"] == 0
    print("PASS ai seat loaded")

    result = service.apply_command(room_code, host_token, {"type": "end_turn"})
    assert result["ok"] is True, result
    after_end = service.snapshot(room_code, seat_token=host_token)
    assert after_end["state"]["current_player"] == 1
    print("PASS human ended into ai turn")

    time.sleep(1.05)
    after_ai = service.snapshot(room_code, seat_token=host_token)
    actions = after_ai["state"]["action_log"]
    assert any(action["type"] == "ai_tick" and action["actor"] == 1 for action in actions), actions
    assert any(action["type"] in {"play_at", "discard", "end_turn"} and action["actor"] == 1 for action in actions), actions
    assert after_ai["state"]["state_revision"] > after_end["state"]["state_revision"]
    print("PASS server ai ticked and made a move")
    print("RESULT 3/3 online AI probes passed")


if __name__ == "__main__":
    main()
