import math
import os
import sys
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ.setdefault("SHAPE_AZOID_TELEMETRY", "0")

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import shape_azoid


class CountingGame:
    def __init__(self):
        self.updates = 0

    def update_zoids(self):
        self.updates += 1


def run_sequence(elapsed_values):
    game = CountingGame()
    accumulator_ms = 0.0
    steps = 0
    for elapsed_ms in elapsed_values:
        accumulator_ms, frame_steps = shape_azoid.advance_fixed_zoid_physics(
            game,
            accumulator_ms,
            elapsed_ms,
        )
        steps += frame_steps
    return game, accumulator_ms, steps


def cadence_cases():
    sixty_game, sixty_residual, sixty_steps = run_sequence([16.0, 17.0, 17.0] * 20)
    thirty_game, thirty_residual, thirty_steps = run_sequence([33.0, 33.0, 34.0] * 10)
    if sixty_steps != 60 or sixty_game.updates != 60:
        raise AssertionError(f"60 Hz cadence produced {sixty_steps} physics steps")
    if thirty_steps != 60 or thirty_game.updates != 60:
        raise AssertionError(f"30 Hz cadence produced {thirty_steps} physics steps")
    if not math.isclose(sixty_residual, 0.0, abs_tol=1e-7):
        raise AssertionError(f"60 Hz cadence retained {sixty_residual} ms")
    if not math.isclose(thirty_residual, 0.0, abs_tol=1e-7):
        raise AssertionError(f"30 Hz cadence retained {thirty_residual} ms")
    print("PASS equivalent one-second 60 Hz and 30 Hz render cadences produce 60 physics steps")


def long_stall_case():
    game, residual_ms, steps = run_sequence([1000.0])
    if steps != shape_azoid.MAX_ZOID_PHYSICS_STEPS:
        raise AssertionError(f"long stall produced {steps} physics steps")
    if game.updates != shape_azoid.MAX_ZOID_PHYSICS_STEPS:
        raise AssertionError(f"long stall called update_zoids {game.updates} times")
    if not math.isclose(residual_ms, 0.0, abs_tol=1e-7):
        raise AssertionError(f"long stall retained {residual_ms} ms")
    print("PASS one-second stall is capped at six physics steps")


def residual_case():
    game = CountingGame()
    accumulator_ms, first_steps = shape_azoid.advance_fixed_zoid_physics(game, 0.0, 10.0)
    if first_steps != 0 or not math.isclose(accumulator_ms, 10.0, abs_tol=1e-7):
        raise AssertionError(f"first residual was steps={first_steps}, residual={accumulator_ms}")
    accumulator_ms, second_steps = shape_azoid.advance_fixed_zoid_physics(
        game,
        accumulator_ms,
        10.0,
    )
    expected_residual = 20.0 - shape_azoid.ZOID_PHYSICS_STEP_MS
    if second_steps != 1 or not math.isclose(accumulator_ms, expected_residual, abs_tol=1e-7):
        raise AssertionError(f"carried residual was steps={second_steps}, residual={accumulator_ms}")
    if game.updates != 1:
        raise AssertionError(f"residual case called update_zoids {game.updates} times")
    print("PASS sub-step residual time carries into the next rendered frame")


def main():
    cadence_cases()
    long_stall_case()
    residual_case()
    print("RESULT 3/3 fixed-step probes passed")


if __name__ == "__main__":
    main()
