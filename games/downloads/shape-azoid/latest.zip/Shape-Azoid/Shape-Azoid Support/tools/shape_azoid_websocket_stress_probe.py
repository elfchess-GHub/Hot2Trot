import json
import os
import sys
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient

from network.shape_azoid_server import app, service
from shape_azoid_core import regular_polygon


def inflate_room(game):
    game.pieces = []
    for idx in range(54):
        x = 90 + (idx % 9) * 118
        y = 120 + (idx // 9) * 92
        shape = "hex" if idx % 3 == 0 else "square" if idx % 3 == 1 else "triangle"
        sides = 6 if shape == "hex" else 4 if shape == "square" else 3
        game.pieces.append({
            "shape": shape,
            "points": regular_polygon((x, y), 44, sides),
            "owner": idx % 6,
            "played_by": idx % max(1, game.player_count),
        })
    game.zoids = []
    for idx in range(12):
        piece = game.pieces[idx]
        point = piece["points"][0]
        game.zoids.append({
            "kind": "penta" if idx % 5 == 0 else "zoid",
            "owner": piece["owner"],
            "played_by": idx % max(1, game.player_count),
            "piece": idx,
            "pos": [float(point[0]), float(point[1])],
            "vel": [2.5, 1.75],
            "visited": {idx},
        })
    game.action_log = [
        {"revision": idx, "actor": idx % max(1, game.player_count), "type": "old", "payload": {}, "message": "old"}
        for idx in range(240)
    ]


def main():
    with TestClient(app) as client:
        created = client.post("/api/rooms", json={"host_name": "Jeremy", "player_count": 2, "ai_players": [], "start": True}).json()
        room_code = created["room_code"]
        host_token = created["host_seat_token"]
        game = service.rooms[room_code]["game"]
        inflate_room(game)

        with client.websocket_connect(f"/ws/rooms/{room_code}?seat_token={host_token}") as websocket:
            frames = [websocket.receive_json() for _ in range(4)]
            sizes = [len(json.dumps(frame)) for frame in frames]
            assert all(frame["type"] == "room_snapshot" for frame in frames)
            assert all(frame["state"]["mode"] == "playing" for frame in frames)
            assert all(len(frame["state"]["action_log"]) <= 12 for frame in frames)
            assert max(sizes) < 90000, f"late-game stream frame too large: {max(sizes)} bytes"

            game.mode = "score"
            game.round_scores = [12, 7]
            game.total_scores = [40, 35]
            game.last_score_breakdown = [
                {"placed": 4, "color": 4, "zoid": 2, "penta": 0, "lights": 2},
                {"placed": 2, "color": 2, "zoid": 0, "penta": 3, "lights": 0},
            ]
            score_frame = websocket.receive_json()
            assert score_frame["state"]["mode"] == "score"
            assert score_frame["state"]["players"][0]["score_total"] == 40

            next_round = client.post(
                f"/api/rooms/{room_code}/commands",
                json={"seat_token": host_token, "command": {"type": "next_round"}},
            ).json()
            assert next_round["ok"], next_round
            assert next_round["state"]["mode"] == "playing"
            assert next_round["state"]["players"][0]["score_total"] == 40

        print("PASS late-game websocket stream and next-round stress")
        print("RESULT 1/1 websocket stress probes passed")


if __name__ == "__main__":
    main()
