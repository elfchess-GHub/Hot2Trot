import subprocess
import sys
import time
import socket
import os
import urllib.error
import urllib.request
import argparse
import getpass
from pathlib import Path
from urllib.parse import urlparse


SCRIPT_PATH = Path(__file__).resolve()
SUPPORT_ROOT = SCRIPT_PATH.parents[1]
if SUPPORT_ROOT.name == "Shape-Azoid Support":
    PACKAGE_ROOT = SUPPORT_ROOT.parent
    SERVER_ROOT = SUPPORT_ROOT
else:
    PACKAGE_ROOT = SUPPORT_ROOT
    SERVER_ROOT = SUPPORT_ROOT
HOST = "127.0.0.1"
SERVER_BIND_HOST = "0.0.0.0"
DEFAULT_PORT = 8765
LOG_PATH = SUPPORT_ROOT / "shape_azoid_online_server.log"
HOST_ADDRESS_PATH = PACKAGE_ROOT / "HOST_SERVER_ADDRESS.txt"
NETWORK_SERVER_PATH = PACKAGE_ROOT / "Shape_Azoid_Network_Server.txt"


def url_ok(url):
    try:
        with urllib.request.urlopen(url, timeout=1.5) as response:
            return response.status == 200
    except Exception:
        return False


def health_ok(base_url):
    try:
        with urllib.request.urlopen(f"{base_url}/api/health", timeout=1.5) as response:
            return response.status == 200 and b"Shape-Azoid" in response.read()
    except Exception:
        return False


def wait_for_server(base_url, timeout_seconds=18):
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        if health_ok(base_url):
            return True
        time.sleep(0.25)
    return False


def free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind((HOST, 0))
        return int(probe.getsockname()[1])


def can_bind_default_port():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.bind((HOST, DEFAULT_PORT))
            return True
    except OSError:
        return False


def local_lan_ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(("8.8.8.8", 80))
            return probe.getsockname()[0]
    except Exception:
        return HOST


def normalize_server_url(text):
    text = str(text or "").strip()
    if not text:
        return ""
    if "://" not in text:
        text = f"http://{text}"
    parsed = urlparse(text)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return ""
    return f"{parsed.scheme}://{parsed.netloc}"


def configured_network_server_url():
    env_url = normalize_server_url(os.environ.get("SHAPE_AZOID_NETWORK_SERVER", ""))
    if env_url:
        return env_url
    if NETWORK_SERVER_PATH.exists():
        try:
            return normalize_server_url(NETWORK_SERVER_PATH.read_text(encoding="utf-8"))
        except OSError:
            return ""
    return ""


def choose_port():
    base_url = f"http://{HOST}:{DEFAULT_PORT}"
    if health_ok(base_url):
        return DEFAULT_PORT, base_url, False
    if can_bind_default_port():
        return DEFAULT_PORT, base_url, True
    return DEFAULT_PORT, base_url, False


def parse_args():
    parser = argparse.ArgumentParser(description="Start or join a local Shape-Azoid online room.")
    parser.add_argument("--mode", choices=("host", "join"), default="host")
    parser.add_argument("--server", default="")
    parser.add_argument("--name", default=(getpass.getuser() or "Player"))
    return parser.parse_args()


def python_path():
    venv_python = SUPPORT_ROOT / ".venv" / "Scripts" / "python.exe"
    if venv_python.exists():
        return str(venv_python)
    return sys.executable


def game_path():
    dist_exe = PACKAGE_ROOT / "dist" / "Shape-Azoid.exe"
    if dist_exe.exists():
        return [str(dist_exe)]
    exe = PACKAGE_ROOT / "Shape-Azoid.exe"
    if exe.exists():
        return [str(exe)]
    return [python_path(), str(SERVER_ROOT / "shape_azoid.py")]


def main():
    args = parse_args()
    started_server = None
    if args.mode == "host":
        port, base_url, should_start = choose_port()
    else:
        base_url = normalize_server_url(args.server) or configured_network_server_url()
        should_start = False
    log = LOG_PATH.open("w", encoding="utf-8")
    if should_start:
        started_server = subprocess.Popen(
            [
                python_path(),
                "-m",
                "uvicorn",
                "network.shape_azoid_server:app",
                "--host",
                SERVER_BIND_HOST,
                "--port",
                str(port),
            ],
            cwd=str(SERVER_ROOT),
            stdout=log,
            stderr=subprocess.STDOUT,
        )
    elif args.mode == "host" and not health_ok(base_url):
        log.close()
        print("Shape-Azoid online server could not start because port 8765 is already in use.")
        print("Close the old Shape-Azoid server or restart the computer, then try again.")
        input("Press Enter to close.")
        return 1
    if args.mode == "host" and not wait_for_server(base_url):
        if started_server:
            started_server.terminate()
        log.close()
        print("Shape-Azoid online server did not start.")
        print(f"Server log: {LOG_PATH}")
        input("Press Enter to close.")
        return 1

    # Keep one player-facing entry flow: launch the normal start screen, while
    # preloading online settings for the Online button inside the game.
    game_cmd = [
        *game_path(),
        "--online-server",
        base_url,
        "--online-name",
        args.name,
    ]
    if args.mode == "host":
        share_url = f"http://{local_lan_ip()}:{port}"
        NETWORK_SERVER_PATH.write_text(f"{share_url}\n", encoding="utf-8")
        HOST_ADDRESS_PATH.write_text(
            "Give this server address to the other player:\n"
            f"{share_url}\n\n"
            "On the other computer, create Shape_Azoid_Network_Server.txt next to "
            "Run_Shape_Azoid_Join.cmd and put that address on one line.\n\n"
            "After that, they open Run_Shape_Azoid_Join.cmd and type only the room code.\n",
            encoding="utf-8",
        )
        game_cmd.extend(["--online-share-server", share_url])
    game = subprocess.Popen(game_cmd, cwd=str(PACKAGE_ROOT))
    game.wait()

    if started_server:
        started_server.terminate()
        try:
            started_server.wait(timeout=8)
        except subprocess.TimeoutExpired:
            started_server.kill()
            started_server.wait(timeout=8)
    log.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
