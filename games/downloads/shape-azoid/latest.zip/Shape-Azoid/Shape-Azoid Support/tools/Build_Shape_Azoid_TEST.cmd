@echo off
setlocal
cd /d "%~dp0.."

if not exist ".venv\Scripts\python.exe" (
  echo Could not find .venv\Scripts\python.exe under Shape-Azoid.
  echo Run Install_Shape_Azoid_Requirements.cmd first.
  pause
  exit /b 1
)

echo Making sure PyInstaller is available in the dev venv...
".venv\Scripts\python.exe" -m pip install --quiet pyinstaller
if errorlevel 1 (
  echo Could not install PyInstaller.
  pause
  exit /b 1
)

echo.
echo Building an ISOLATED TEST package.
echo This does NOT touch Shape-Azoid-portable, Shape-Azoid-portable.zip,
echo or shape-azoid-v0.7.33.zip. It builds into a new, separate,
echo timestamped folder next to Shape-Azoid-portable instead.
echo.

set "SHAPE_AZOID_TEST_BUILD=1"
".venv\Scripts\python.exe" "tools\build_portable_zip.py"
set "BUILD_RESULT=%ERRORLEVEL%"

echo.
if "%BUILD_RESULT%"=="0" (
  echo Test build finished. Look for a folder named
  echo Shape-Azoid-portable-TEST-<timestamp> next to Shape-Azoid-portable.
  echo Its "Play Shape-Azoid.exe" is safe to run - the live portable
  echo folder was not touched.
) else (
  echo Test build failed. Scroll up for the error.
)
pause
