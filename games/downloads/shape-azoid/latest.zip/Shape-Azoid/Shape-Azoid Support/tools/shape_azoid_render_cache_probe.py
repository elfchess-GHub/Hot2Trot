import os
import sys
import time
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ.setdefault("SHAPE_AZOID_TELEMETRY", "0")

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pygame
import shape_azoid


def gradient_points(index):
    x = 20 + (index % 20) * 20
    y = 20 + (index // 20) * 20
    return [(x, y), (x + 8, y), (x + 4, y + 8)]


def gradient_key(points, color):
    point_key = tuple((int(round(point[0])), int(round(point[1]))) for point in points)
    return point_key, tuple(color)


def expected_shared_edges(game):
    edges = {}
    for piece_index, piece in enumerate(game.pieces):
        for side_index, (a, b) in enumerate(shape_azoid.side_list(piece["points"])):
            edges.setdefault(shape_azoid.edge_key(a, b), []).append(
                (piece_index, side_index, a, b)
            )
    return edges


def reusable_surface_probe():
    shape_azoid.STARFIELD_SURFACE = None
    first = shape_azoid.reusable_starfield_surface()
    first.set_at((7, 11), (255, 80, 40, 255))
    second = shape_azoid.reusable_starfield_surface()
    if first is not second:
        raise AssertionError("starfield surface identity changed between frames")
    if second.get_at((7, 11)).a != 0:
        raise AssertionError("reused starfield surface retained the prior frame")

    shape_azoid.CIRCUIT_GLOW_SURFACE = None
    first_glow = shape_azoid.circuit_glow_surface()
    second_glow = shape_azoid.circuit_glow_surface()
    if first_glow is not second_glow:
        raise AssertionError("circuit glow surface was rendered more than once")
    if first_glow.get_size() != (58, 58) or first_glow.get_at((29, 29)).a == 0:
        raise AssertionError("cached circuit glow does not contain the expected visible center")
    print("PASS reusable starfield clearing and circuit glow identity")


def gradient_cache_probe(game):
    shape_azoid.SHAPE_GRADIENT_CACHE.clear()
    shape_azoid.SHAPE_GRADIENT_CACHE_ORDER.clear()
    target = pygame.Surface((shape_azoid.WIDTH, shape_azoid.HEIGHT), pygame.SRCALPHA)
    color = (76, 142, 211)
    cases = []
    for index in range(140):
        points = gradient_points(index)
        cases.append((points, gradient_key(points, color)))
        shape_azoid.draw_polygon_gradient(target, points, color)

    limit = shape_azoid.SHAPE_GRADIENT_CACHE_LIMIT
    if len(shape_azoid.SHAPE_GRADIENT_CACHE) != limit:
        raise AssertionError(f"gradient cache contains {len(shape_azoid.SHAPE_GRADIENT_CACHE)} entries, expected {limit}")
    if len(shape_azoid.SHAPE_GRADIENT_CACHE_ORDER) != limit:
        raise AssertionError("gradient cache LRU bookkeeping is not bounded with the cache")
    if set(shape_azoid.SHAPE_GRADIENT_CACHE) != set(shape_azoid.SHAPE_GRADIENT_CACHE_ORDER):
        raise AssertionError("gradient cache and LRU bookkeeping contain different keys")

    reused_points, reused_key = cases[12]
    reused_surface = shape_azoid.SHAPE_GRADIENT_CACHE[reused_key][0]
    shape_azoid.draw_polygon_gradient(target, reused_points, color)
    if shape_azoid.SHAPE_GRADIENT_CACHE[reused_key][0] is not reused_surface:
        raise AssertionError("gradient cache hit replaced its cached surface")
    if shape_azoid.SHAPE_GRADIENT_CACHE_ORDER[-1] != reused_key:
        raise AssertionError("gradient cache hit did not refresh LRU order")

    evicted_key = cases[13][1]
    shape_azoid.draw_polygon_gradient(target, gradient_points(140), color)
    if reused_key not in shape_azoid.SHAPE_GRADIENT_CACHE or evicted_key in shape_azoid.SHAPE_GRADIENT_CACHE:
        raise AssertionError("gradient LRU did not preserve the hit and evict the oldest untouched entry")

    game.reset_round()
    if shape_azoid.SHAPE_GRADIENT_CACHE or shape_azoid.SHAPE_GRADIENT_CACHE_ORDER:
        raise AssertionError("round reset did not clear gradient cache and LRU bookkeeping")
    print("PASS gradient cache bound, LRU hit, eviction, and round reset")


def shared_edges_probe(game):
    left = [(0.0, 0.0), (100.0, 0.0), (100.0, 100.0), (0.0, 100.0)]
    right = [(100.0, 0.0), (200.0, 0.0), (200.0, 100.0), (100.0, 100.0)]
    game.pieces = [
        {"shape": "square", "points": list(left), "owner": 0, "played_by": 0},
        {"shape": "square", "points": list(right), "owner": 1, "played_by": 1},
    ]
    game._shared_edges_signature = None
    game._shared_edges_cache = None

    first = game.shared_edges()
    if game.shared_edges() is not first:
        raise AssertionError("shared-edge geometry hit did not return the identical mapping")
    if first != expected_shared_edges(game):
        raise AssertionError("shared-edge cache changed mapping values")

    game.pieces[0]["owner"] = 5
    if game.shared_edges() is not first:
        raise AssertionError("ownership-only change invalidated shared-edge geometry cache")

    game.pieces[0]["points"][1] = (101.0, 0.0)
    changed_in_place = game.shared_edges()
    if changed_in_place is first or changed_in_place != expected_shared_edges(game):
        raise AssertionError("in-place point change did not rebuild exact shared-edge values")

    game.pieces.append(
        {"shape": "triangle", "points": [(20.0, 20.0), (35.0, 20.0), (27.5, 35.0)], "owner": 2, "played_by": 2}
    )
    after_append = game.shared_edges()
    if after_append is changed_in_place or after_append != expected_shared_edges(game):
        raise AssertionError("piece append did not invalidate shared-edge geometry cache")

    game.pieces.pop()
    after_remove = game.shared_edges()
    if after_remove is after_append or after_remove != expected_shared_edges(game):
        raise AssertionError("piece removal did not invalidate shared-edge geometry cache")

    game.pieces[1] = {
        "shape": "square",
        "points": [(101.0, 0.0), (205.0, 0.0), (205.0, 100.0), (101.0, 100.0)],
        "owner": 4,
        "played_by": 1,
    }
    after_replacement = game.shared_edges()
    if after_replacement is after_remove or after_replacement != expected_shared_edges(game):
        raise AssertionError("replacement geometry did not invalidate shared-edge cache")
    print("PASS shared-edge identity hit and geometry-only invalidation")


def preload_probe():
    originals = {
        "draw_loading_frame": shape_azoid.draw_loading_frame,
        "static_background_base": shape_azoid.static_background_base,
        "load_character_images": shape_azoid.load_character_images,
        "load_action_character_images": shape_azoid.load_action_character_images,
        "ufo_image": shape_azoid.ufo_image,
    }
    calls = []
    labels = []
    try:
        shape_azoid.draw_loading_frame = labels.append
        shape_azoid.static_background_base = lambda: calls.append("background")
        shape_azoid.load_character_images = lambda: calls.append("portraits")
        shape_azoid.load_action_character_images = lambda: calls.append("action_portraits")
        shape_azoid.ufo_image = lambda: calls.append("ufo")
        shape_azoid.preload_assets()
    finally:
        for name, value in originals.items():
            setattr(shape_azoid, name, value)

    expected_calls = ["background", "portraits", "action_portraits", "ufo"]
    expected_labels = [
        "Loading background...",
        "Loading portraits...",
        "Loading action portraits...",
        "Loading UFO...",
    ]
    if calls != expected_calls or labels != expected_labels:
        raise AssertionError(f"preload stages differ: calls={calls}, labels={labels}")
    print("PASS visible preload stages invoke background, portraits, actions, and UFO")


def timing_note():
    iterations = 8
    started = time.perf_counter()
    for _ in range(iterations):
        surface = pygame.Surface((shape_azoid.WIDTH, shape_azoid.HEIGHT), pygame.SRCALPHA)
        surface.fill((0, 0, 0, 0))
    fresh_ms = (time.perf_counter() - started) * 1000.0

    shape_azoid.STARFIELD_SURFACE = None
    started = time.perf_counter()
    for _ in range(iterations):
        shape_azoid.reusable_starfield_surface()
    reused_ms = (time.perf_counter() - started) * 1000.0
    print(
        f"INFO star surface {iterations} frames: fresh={fresh_ms:.3f} ms, "
        f"reused-and-cleared={reused_ms:.3f} ms, allocations={iterations} vs 1"
    )


def main():
    reusable_surface_probe()
    game = shape_azoid.Game()
    gradient_cache_probe(game)
    shared_edges_probe(game)
    preload_probe()
    timing_note()
    print("RESULT 4/4 render cache probe groups passed")


if __name__ == "__main__":
    main()
