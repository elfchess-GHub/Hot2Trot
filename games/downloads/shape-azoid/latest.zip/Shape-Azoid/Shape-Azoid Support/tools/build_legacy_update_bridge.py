#!/usr/bin/env python3
"""Build the one-time v0.7.32-to-release-manifest update bridge.

The legacy v0.7.32 updater can only read latest-build.txt and latest.zip. This
builder creates the small Shape-Azoid-rooted ZIP that old updater expects. The
bridge installs the manifest-based updater and current game/support files; the
next launcher run then downloads the complete, hash-verified release package.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import tempfile
import zipfile
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path, PurePosixPath


ZIP_ROOT = "Shape-Azoid"
EXPECTED_LEGACY_BUILD_ID = "v0.7.32-20260708-1311"
EXPECTED_LEGACY_SHA256 = "7a5083bab14a2adfad2852bca8387e29a10918205041cfd1ce3f9e666695e1d3"
BUILD_STAMP_RE = re.compile(r"(\d{8}-\d{4})$")
FIXED_ZIP_TIMESTAMP = (2026, 1, 1, 0, 0, 0)
DEFAULT_MAX_BYTES = 95 * 1024 * 1024
REQUIRED_FINAL_FILES = (
    Path("Shape-Azoid.exe"),
    Path("Update Shape-Azoid.ps1"),
    Path("Install_Shape_Azoid_Requirements.cmd"),
)
SUPPORT_DIRECTORY = Path("Shape-Azoid Support")
UPDATER_MARKERS = (
    "latest-release.json",
    "ConvertFrom-Json",
    "expectedSha256",
    "Read-PackageFiles",
)


class BridgeBuildError(RuntimeError):
    """Raised when bridge inputs do not satisfy the migration contract."""


@dataclass(frozen=True)
class BridgeBuildResult:
    output_path: Path
    legacy_build_id: str
    final_build_id: str
    bootstrap_build_id: str
    managed_file_count: int
    payload_file_count: int
    size_bytes: int
    sha256: str


def _parse_build_stamp(build_id: str, label: str) -> datetime:
    match = BUILD_STAMP_RE.search(build_id)
    if not match:
        raise BridgeBuildError(
            f"{label} build ID does not end in YYYYMMDD-HHMM: {build_id!r}"
        )
    try:
        return datetime.strptime(match.group(1), "%Y%m%d-%H%M")
    except ValueError as exc:
        raise BridgeBuildError(f"{label} build ID has an invalid timestamp: {build_id!r}") from exc


def derive_bootstrap_build_id(final_build_id: str) -> str:
    final_stamp = _parse_build_stamp(final_build_id, "Final")
    match = BUILD_STAMP_RE.search(final_build_id)
    assert match is not None
    prefix = final_build_id[: match.start()].rstrip("-")
    if not prefix:
        raise BridgeBuildError(f"Final build ID has no version prefix: {final_build_id!r}")
    bootstrap_stamp = final_stamp - timedelta(minutes=1)
    return f"{prefix}-bootstrap-{bootstrap_stamp:%Y%m%d-%H%M}"


def validate_build_order(
    legacy_build_id: str,
    bootstrap_build_id: str,
    final_build_id: str,
) -> None:
    legacy_stamp = _parse_build_stamp(legacy_build_id, "Legacy")
    bootstrap_stamp = _parse_build_stamp(bootstrap_build_id, "Bootstrap")
    final_stamp = _parse_build_stamp(final_build_id, "Final")
    if not legacy_stamp < bootstrap_stamp < final_stamp:
        raise BridgeBuildError(
            "Build timestamps must satisfy legacy < bootstrap < final; got "
            f"{legacy_build_id!r}, {bootstrap_build_id!r}, {final_build_id!r}."
        )


def _safe_relative_zip_path(entry_name: str) -> PurePosixPath:
    if "\\" in entry_name:
        raise BridgeBuildError(f"Legacy ZIP contains a backslash path: {entry_name!r}")
    path = PurePosixPath(entry_name)
    if path.is_absolute() or ".." in path.parts:
        raise BridgeBuildError(f"Legacy ZIP contains an unsafe path: {entry_name!r}")
    if not path.parts or path.parts[0] != ZIP_ROOT:
        raise BridgeBuildError(
            f"Legacy ZIP entry is not rooted at {ZIP_ROOT}/: {entry_name!r}"
        )
    relative = PurePosixPath(*path.parts[1:])
    if not relative.parts:
        raise BridgeBuildError(f"Legacy ZIP contains an invalid root file path: {entry_name!r}")
    return relative


def inspect_legacy_package(
    legacy_zip: Path,
    expected_build_id: str = EXPECTED_LEGACY_BUILD_ID,
    expected_sha256: str = EXPECTED_LEGACY_SHA256,
) -> tuple[str, list[str]]:
    if not legacy_zip.is_file():
        raise BridgeBuildError(f"Legacy package does not exist: {legacy_zip}")
    actual_sha256 = hashlib.sha256(legacy_zip.read_bytes()).hexdigest()
    if actual_sha256.lower() != expected_sha256.lower():
        raise BridgeBuildError(
            "Legacy package SHA-256 did not match the exact v0.7.32 archive: "
            f"{actual_sha256}."
        )

    managed_files: list[str] = []
    build_id: str | None = None
    casefold_paths: dict[str, str] = {}
    try:
        with zipfile.ZipFile(legacy_zip, "r") as archive:
            for info in archive.infolist():
                if info.is_dir():
                    continue
                relative = _safe_relative_zip_path(info.filename)
                normalized = relative.as_posix()
                folded = normalized.casefold()
                previous = casefold_paths.get(folded)
                if previous is not None:
                    raise BridgeBuildError(
                        "Legacy ZIP contains duplicate case-insensitive paths: "
                        f"{previous!r} and {normalized!r}."
                    )
                casefold_paths[folded] = normalized

                if normalized == "BUILD_ID.txt":
                    build_id = archive.read(info).decode("ascii").strip()

                if normalized.casefold() in {"settings.json", "package_files.json"}:
                    continue
                if any(part.casefold() == ".venv" for part in relative.parts):
                    continue
                managed_files.append(normalized)
    except (OSError, zipfile.BadZipFile, UnicodeError) as exc:
        raise BridgeBuildError(f"Could not inspect legacy package {legacy_zip}: {exc}") from exc

    if build_id != expected_build_id:
        raise BridgeBuildError(
            f"Legacy package build ID was {build_id!r}; expected {expected_build_id!r}."
        )
    if "Shape-Azoid.exe" not in managed_files or "Update Shape-Azoid.ps1" not in managed_files:
        raise BridgeBuildError("Legacy package is missing its game executable or updater.")
    return build_id, sorted(managed_files, key=lambda value: (value.casefold(), value))


def _read_final_build_id(final_package_root: Path) -> str:
    build_path = final_package_root / "BUILD_ID.txt"
    try:
        final_build_id = build_path.read_text(encoding="ascii").strip()
    except OSError as exc:
        raise BridgeBuildError(f"Could not read final build ID at {build_path}: {exc}") from exc
    if not final_build_id:
        raise BridgeBuildError(f"Final build ID is empty: {build_path}")
    return final_build_id


def _read_payload_file(path: Path, final_package_root: Path) -> bytes:
    try:
        if path.is_symlink():
            raise BridgeBuildError(f"Bridge payload must not contain symlinks: {path}")
        return path.read_bytes()
    except OSError as exc:
        relative = path.relative_to(final_package_root)
        raise BridgeBuildError(f"Could not read bridge payload file {relative}: {exc}") from exc


def collect_bridge_payload(final_package_root: Path) -> dict[str, bytes]:
    if not final_package_root.is_dir():
        raise BridgeBuildError(f"Final package root does not exist: {final_package_root}")

    payload: dict[str, bytes] = {}
    for relative in REQUIRED_FINAL_FILES:
        source = final_package_root / relative
        if not source.is_file():
            raise BridgeBuildError(f"Final package is missing required bridge file: {source}")
        payload[relative.as_posix()] = _read_payload_file(source, final_package_root)

    try:
        updater_text = payload[Path("Update Shape-Azoid.ps1").as_posix()].decode(
            "ascii", errors="strict"
        )
    except UnicodeError as exc:
        raise BridgeBuildError("Final package updater is not ASCII text.") from exc
    missing_markers = [marker for marker in UPDATER_MARKERS if marker not in updater_text]
    if missing_markers:
        raise BridgeBuildError(
            "Final package updater is not the manifest/hash/package-inventory updater; "
            f"missing: {', '.join(missing_markers)}. Rebuild the final package first."
        )

    support_root = final_package_root / SUPPORT_DIRECTORY
    if not support_root.is_dir():
        raise BridgeBuildError(f"Final package is missing support directory: {support_root}")
    for source in sorted(support_root.rglob("*")):
        if not source.is_file():
            continue
        relative = source.relative_to(final_package_root)
        if any(part.casefold() == ".venv" for part in relative.parts):
            continue
        payload[relative.as_posix()] = _read_payload_file(source, final_package_root)

    if not any(name.startswith(f"{SUPPORT_DIRECTORY.as_posix()}/") for name in payload):
        raise BridgeBuildError("Final package support directory did not contain any bridge files.")
    return payload


def _zip_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, date_time=FIXED_ZIP_TIMESTAMP)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.create_system = 3
    info.external_attr = (0o100644 & 0xFFFF) << 16
    info.flag_bits |= 0x800
    return info


def _write_deterministic_zip(output_path: Path, entries: dict[str, bytes]) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temp_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            prefix=f".{output_path.name}.", suffix=".tmp", dir=output_path.parent, delete=False
        ) as handle:
            temp_name = handle.name
        with zipfile.ZipFile(
            temp_name, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
        ) as archive:
            for name in sorted(entries, key=lambda value: (value.casefold(), value)):
                archive.writestr(
                    _zip_info(name),
                    entries[name],
                    compress_type=zipfile.ZIP_DEFLATED,
                    compresslevel=9,
                )
        Path(temp_name).replace(output_path)
        temp_name = None
    finally:
        if temp_name is not None:
            Path(temp_name).unlink(missing_ok=True)


def build_bridge(
    legacy_zip: Path,
    final_package_root: Path,
    output_path: Path,
    *,
    bootstrap_build_id: str | None = None,
    expected_legacy_build_id: str = EXPECTED_LEGACY_BUILD_ID,
    expected_legacy_sha256: str = EXPECTED_LEGACY_SHA256,
    max_bytes: int = DEFAULT_MAX_BYTES,
) -> BridgeBuildResult:
    legacy_zip = legacy_zip.resolve()
    final_package_root = final_package_root.resolve()
    output_path = output_path.resolve()
    if max_bytes <= 0:
        raise BridgeBuildError("Maximum bridge size must be greater than zero.")
    if output_path == legacy_zip:
        raise BridgeBuildError("Output path must not overwrite the legacy package.")
    try:
        output_path.relative_to(final_package_root)
    except ValueError:
        pass
    else:
        raise BridgeBuildError("Output path must be outside the final package root.")

    legacy_build_id, managed_files = inspect_legacy_package(
        legacy_zip,
        expected_build_id=expected_legacy_build_id,
        expected_sha256=expected_legacy_sha256,
    )
    final_build_id = _read_final_build_id(final_package_root)
    bootstrap_build_id = bootstrap_build_id or derive_bootstrap_build_id(final_build_id)
    validate_build_order(legacy_build_id, bootstrap_build_id, final_build_id)

    payload = collect_bridge_payload(final_package_root)
    package_manifest = {
        "version": 1,
        "files": managed_files,
    }
    payload["BUILD_ID.txt"] = (bootstrap_build_id + "\n").encode("ascii")
    payload["PACKAGE_FILES.json"] = (
        json.dumps(package_manifest, indent=2, ensure_ascii=True) + "\n"
    ).encode("ascii")

    entries = {f"{ZIP_ROOT}/{name}": content for name, content in payload.items()}
    _write_deterministic_zip(output_path, entries)
    size_bytes = output_path.stat().st_size
    if size_bytes > max_bytes:
        output_path.unlink(missing_ok=True)
        raise BridgeBuildError(
            f"Bridge ZIP was {size_bytes:,} bytes, above the {max_bytes:,}-byte limit."
        )
    sha256 = hashlib.sha256(output_path.read_bytes()).hexdigest()
    return BridgeBuildResult(
        output_path=output_path,
        legacy_build_id=legacy_build_id,
        final_build_id=final_build_id,
        bootstrap_build_id=bootstrap_build_id,
        managed_file_count=len(managed_files),
        payload_file_count=len(payload),
        size_bytes=size_bytes,
        sha256=sha256,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--legacy-zip", required=True, type=Path)
    parser.add_argument("--final-package-root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--bootstrap-build-id")
    parser.add_argument(
        "--expected-legacy-build-id",
        default=EXPECTED_LEGACY_BUILD_ID,
    )
    parser.add_argument(
        "--expected-legacy-sha256",
        default=EXPECTED_LEGACY_SHA256,
    )
    parser.add_argument("--max-bytes", type=int, default=DEFAULT_MAX_BYTES)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        result = build_bridge(
            args.legacy_zip,
            args.final_package_root,
            args.output,
            bootstrap_build_id=args.bootstrap_build_id,
            expected_legacy_build_id=args.expected_legacy_build_id,
            expected_legacy_sha256=args.expected_legacy_sha256,
            max_bytes=args.max_bytes,
        )
    except BridgeBuildError as exc:
        print(f"ERROR: {exc}")
        return 1

    print(f"Built: {result.output_path}")
    print(f"Legacy build: {result.legacy_build_id}")
    print(f"Bootstrap build: {result.bootstrap_build_id}")
    print(f"Final build: {result.final_build_id}")
    print(f"Old managed files: {result.managed_file_count}")
    print(f"Bridge payload files: {result.payload_file_count}")
    print(f"ZIP size: {result.size_bytes:,} bytes")
    print(f"SHA-256: {result.sha256}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
