import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import shape_azoid_core as core


def main():
    failures = []
    if "pygame" in sys.modules:
        failures.append("shape_azoid_core imported pygame")

    card = core.make_card("square", 2, wild=True)
    if core.card_label(card) != "Yellow square":
        failures.append(f"bad card label: {core.card_label(card)}")
    if not core.cycle_wild_card(card) or core.card_kind(card) != "triangle":
        failures.append(f"wild cycle failed: {card}")

    square = core.build_points_for_shape("square", board_center=(100, 100))
    if len(square) != 4:
        failures.append(f"square point count was {len(square)}")
    if not core.point_in_polygon((100, 100), square):
        failures.append("square center was not inside generated square")

    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        return 1
    print("OK: shape_azoid_core imports without pygame and basic helpers work.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
