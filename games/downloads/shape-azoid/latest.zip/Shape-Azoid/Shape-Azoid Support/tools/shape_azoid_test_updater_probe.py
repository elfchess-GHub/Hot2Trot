import hashlib
import importlib.util
import json
import subprocess
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BUILD_SCRIPT = ROOT / "tools" / "build_portable_zip.py"
NORMAL_UPDATER_SHA256 = "2a892091cc1597dc20ea6e57cb3fa3b7aebf638d2a15b742b58667cab919ee71"


def load_build_module():
    spec = importlib.util.spec_from_file_location("shape_azoid_build_portable_zip", BUILD_SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def written_hash(text):
    with tempfile.TemporaryDirectory(prefix="shape_azoid_updater_hash_") as temp_dir:
        path = Path(temp_dir) / "Update Shape-Azoid.ps1"
        path.write_text(text, encoding="ascii")
        return hashlib.sha256(path.read_bytes()).hexdigest()


def run_guarded_test_updater(text, build_id):
    with tempfile.TemporaryDirectory(prefix="shape_azoid_test_updater_") as temp_dir:
        root = Path(temp_dir)
        updater_path = root / "Update Shape-Azoid.ps1"
        updater_path.write_text(text, encoding="ascii")
        (root / "BUILD_ID.txt").write_text(build_id + "\n", encoding="ascii")
        (root / "Shape-Azoid.exe").write_bytes(b"isolated-test-placeholder")

        command = (
            "function Invoke-WebRequest { throw 'NETWORK CONTACT ATTEMPTED' }; "
            f"& '{updater_path}'"
        )
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
            capture_output=True,
            text=True,
            timeout=15,
        )
        output = result.stdout + result.stderr
        assert result.returncode == 0, output
        assert "public updates are disabled for this package" in output, output
        assert "NETWORK CONTACT ATTEMPTED" not in output, output
        assert "Update check skipped" not in output, output


def powershell_literal(value):
    return str(value).replace("'", "''")


def run_release_manifest_updater(text, valid_hash):
    with tempfile.TemporaryDirectory(prefix="shape_azoid_release_updater_") as temp_dir:
        root = Path(temp_dir) / "installed"
        package_root = Path(temp_dir) / "package" / "Shape-Azoid"
        root.mkdir(parents=True)
        package_root.mkdir(parents=True)

        old_build = "v0.7.32-20260708-1311"
        new_build = "v0.7.33-20991231-2359"
        old_exe = b"old-game-executable"
        new_exe = b"new-game-executable"
        updater_path = root / "Update Shape-Azoid.ps1"
        updater_path.write_text(text, encoding="ascii")
        (root / "BUILD_ID.txt").write_text(old_build + "\n", encoding="ascii")
        (root / "Shape-Azoid.exe").write_bytes(old_exe)
        old_manifest = {
            "version": 1,
            "files": [
                "BUILD_ID.txt",
                "Shape-Azoid.exe",
                "music/obsolete-packaged-track.mp3",
            ],
        }
        (root / "PACKAGE_FILES.json").write_text(
            json.dumps(old_manifest, indent=2) + "\n",
            encoding="ascii",
        )
        (root / "music").mkdir()
        obsolete_track = root / "music" / "obsolete-packaged-track.mp3"
        obsolete_track.write_bytes(b"obsolete-package-content")
        custom_track = root / "music" / "custom-track.mp3"
        custom_track.write_bytes(b"player-content")
        settings_path = root / "settings.json"
        settings_path.write_text('{"theme":"atomic_dark"}\n', encoding="ascii")
        runtime_marker = root / ".venv" / "local-runtime.txt"
        runtime_marker.parent.mkdir()
        runtime_marker.write_text("player runtime\n", encoding="ascii")
        (package_root / "BUILD_ID.txt").write_text(new_build + "\n", encoding="ascii")
        (package_root / "Shape-Azoid.exe").write_bytes(new_exe)
        new_manifest = {
            "version": 1,
            "files": ["BUILD_ID.txt", "Shape-Azoid.exe"],
        }
        (package_root / "PACKAGE_FILES.json").write_text(
            json.dumps(new_manifest, indent=2) + "\n",
            encoding="ascii",
        )

        zip_path = Path(temp_dir) / "release.zip"
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for source in package_root.rglob("*"):
                if source.is_file():
                    archive.write(source, Path("Shape-Azoid") / source.relative_to(package_root))
        package_hash = hashlib.sha256(zip_path.read_bytes()).hexdigest()
        manifest = {
            "build_id": new_build,
            "download_url": "https://github.com/elfchess-GHub/Hot2Trot/releases/download/shape-azoid-v0.7.33/Shape-Azoid-v0.7.33.zip",
            "sha256": package_hash if valid_hash else "0" * 64,
        }
        manifest_text = json.dumps(manifest, separators=(",", ":"))
        command = f"""
function Invoke-WebRequest {{
    param([string]$Uri, [string]$OutFile, [switch]$UseBasicParsing, [int]$TimeoutSec)
    if ($OutFile) {{
        Copy-Item -LiteralPath '{powershell_literal(zip_path)}' -Destination $OutFile -Force
        return
    }}
    [pscustomobject]@{{ Content = '{powershell_literal(manifest_text)}' }}
}}
& '{powershell_literal(updater_path)}'
"""
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
            capture_output=True,
            text=True,
            timeout=15,
        )
        output = result.stdout + result.stderr
        assert result.returncode == 0, output
        if valid_hash:
            assert "Shape-Azoid update complete." in output, output
            assert (root / "Shape-Azoid.exe").read_bytes() == new_exe
            assert (root / "BUILD_ID.txt").read_text(encoding="ascii").strip() == new_build
            assert not obsolete_track.exists()
            assert custom_track.read_bytes() == b"player-content"
            assert settings_path.read_text(encoding="ascii") == '{"theme":"atomic_dark"}\n'
            assert runtime_marker.read_text(encoding="ascii") == "player runtime\n"
        else:
            assert "failed SHA-256 verification" in output, output
            assert (root / "Shape-Azoid.exe").read_bytes() == old_exe
            assert (root / "BUILD_ID.txt").read_text(encoding="ascii").strip() == old_build
            assert obsolete_track.read_bytes() == b"obsolete-package-content"


def main():
    module = load_build_module()
    test_build_id = "v0.7.32-20991231-2359-TEST"
    normal_build_id = "v0.7.32-20991231-2359"

    normal = module.render_updater(test_mode=False, build_id=normal_build_id)
    test = module.render_updater(test_mode=True, build_id=test_build_id)

    assert written_hash(normal) == NORMAL_UPDATER_SHA256
    assert "public updates are disabled for this package" not in normal
    assert "latest-release.json" in normal
    assert "/releases/download/" in normal
    assert "System.Security.Cryptography.SHA256" in normal
    assert "latest.zip" not in normal
    assert normal.count("Invoke-WebRequest") == 2

    guard_index = test.index("public updates are disabled for this package")
    first_network_index = test.index("Invoke-WebRequest")
    assert guard_index < first_network_index
    assert f'$testBuild = "{test_build_id}"' in test
    assert test.count("Invoke-WebRequest") == 2
    run_guarded_test_updater(test, test_build_id)
    run_release_manifest_updater(normal, valid_hash=True)
    run_release_manifest_updater(normal, valid_hash=False)

    print("PASS: normal updater uses a hashed GitHub Release asset")
    print("PASS: TEST updater exits before public update access")
    print("PASS: valid release manifest updates the game, removes obsolete package files, and preserves player files")
    print("PASS: invalid release package hash is rejected")
    print("Shape-Azoid updater probe: 4/4 passed")


if __name__ == "__main__":
    main()
