import os
import sys
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import shape_azoid
import shape_azoid_core


def make_two_square_state(module, game):
    first = module.build_points_for_shape("square")
    first_center = module.centroid(first)
    attach_side = max(module.side_list(first), key=lambda side: module.midpoint(side[0], side[1])[0])
    second = module.build_points_for_shape("square", attach_side[0], attach_side[1], first_center)
    game.pieces = [
        {"shape": "square", "points": first, "owner": 0, "played_by": 0},
        {"shape": "square", "points": second, "owner": 0, "played_by": 1},
    ]
    game.zoids = []
    game.open_walls = set()
    game.round_light_scores = [99, 99]
    game.round_scores = [0, 0]
    game.total_scores = [0, 0]
    return next(key for key, entries in game.shared_edges().items() if len(entries) == 2)


def assert_lights(label, game, expected):
    breakdown = game.score_breakdown()
    actual = [parts["lights"] for parts in breakdown]
    if actual != expected:
        raise AssertionError(f"{label}: expected lights {expected}, got {actual}; breakdown={breakdown}")


def run_cases(label, module, game_factory):
    game = game_factory()
    game.player_count = 2
    if hasattr(game, "setup"):
        game.setup()
    wall = make_two_square_state(module, game)

    assert_lights(f"{label} closed same-color wall", game, [0, 0])

    game.open_walls.add(wall)
    assert_lights(f"{label} open same-color wall", game, [1, 0])

    game.pieces[1]["owner"] = 1
    assert_lights(f"{label} open different-color wall", game, [0, 0])

    game.pieces[1]["owner"] = 0
    assert_lights(f"{label} restored open same-color wall", game, [1, 0])
    game.pieces[0]["owner"] = 1
    assert_lights(f"{label} owner changed before scoring", game, [0, 0])

    game.pieces[0]["owner"] = 0
    game.round_light_scores = [12, 7]
    game.finish_round()
    final_lights = [parts["lights"] for parts in game.last_score_breakdown]
    if final_lights != [1, 0]:
        raise AssertionError(f"{label} finish_round used stale round_light_scores: got {final_lights}")

    print(f"PASS {label} circuit scoring is based on round-end open same-color walls")


def main():
    run_cases("desktop", shape_azoid, shape_azoid.Game)
    run_cases("core", shape_azoid_core, shape_azoid_core.ShapeAzoidMatch)
    print("RESULT 2/2 scoring probes passed")


if __name__ == "__main__":
    main()
