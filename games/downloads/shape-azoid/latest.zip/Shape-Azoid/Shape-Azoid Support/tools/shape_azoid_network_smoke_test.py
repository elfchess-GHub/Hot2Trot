import argparse
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from network.shape_azoid_http_client import ShapeAzoidHttpClient, ShapeAzoidHttpError


class SmokeFailure(RuntimeError):
    pass


def parse_args():
    parser = argparse.ArgumentParser(description="Run a live HTTP smoke test for the Shape-Azoid network prototype.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=0, help="Port for the temporary server. Use 0 to auto-pick a free port.")
    return parser.parse_args()


def free_port(host):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind((host, 0))
        return int(probe.getsockname()[1])


def wait_for_server(client, timeout_seconds=12.0):
    deadline = time.time() + timeout_seconds
    last_error = "server did not answer"
    while time.time() < deadline:
        try:
            payload = client.version()
            if payload and payload.get("ok"):
                return payload
            last_error = f"unexpected payload {payload}"
        except Exception as exc:
            last_error = str(exc)
        time.sleep(0.2)
    raise SmokeFailure(f"Temporary server did not start in time: {last_error}")


def run_smoke_test(host, port):
    port = free_port(host) if int(port or 0) == 0 else port
    base_url = f"http://{host}:{port}"
    temp_dir = tempfile.TemporaryDirectory()
    env = {
        **dict(__import__("os").environ),
        "SHAPE_AZOID_ROOM_SAVE_DIR": temp_dir.name,
    }
    process = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "network.shape_azoid_server:app", "--host", host, "--port", str(port)],
        cwd=str(ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        env=env,
    )
    client = ShapeAzoidHttpClient(base_url)
    passed = []

    def record(name):
        passed.append(name)
        print(f"PASS {name}")

    try:
        wait_for_server(client)
        record("server_start")

        created = client.create_room(host_name="Jeremy", player_count=2, ai_players=[], start=False)
        room_code = created["room_code"]
        host_token = created["host_seat_token"]
        record("create_room")

        listed = client.list_rooms()
        assert listed["ok"] is True
        assert listed["rooms"][0]["room_code"] == room_code
        assert listed["rooms"][0]["phase"] == "lobby"
        record("list_rooms")

        host_view = client.snapshot(room_code, seat_token=host_token)
        assert host_view["viewer_player"] == 0
        assert host_view["phase"] == "lobby"
        assert host_view["state"]["deck_count"] == 0
        record("lobby_snapshot")

        joined = client.join_room(room_code, player_name="Guest")
        guest_token = joined["seat_token"]
        assert joined["seat_index"] == 1
        record("join_room")

        try:
            client.start_room(room_code, guest_token)
            raise SmokeFailure("Guest start unexpectedly succeeded.")
        except ShapeAzoidHttpError as exc:
            if exc.status != 403:
                raise
        record("guest_start_rejected")

        started = client.start_room(room_code, host_token)
        assert started["ok"] is True
        assert started["phase"] == "playing"
        record("host_start")

        host_view = client.snapshot(room_code, seat_token=host_token)
        assert isinstance(host_view["state"]["hands"][1], dict)
        record("sanitized_playing_snapshot")

        try:
            client.apply_command(room_code, "not-a-real-seat-token", {"type": "end_turn"})
            raise SmokeFailure("Bad token command unexpectedly succeeded.")
        except ShapeAzoidHttpError as exc:
            if exc.status != 403:
                raise
        record("bad_token_rejected")

        result = client.apply_command(room_code, host_token, {"type": "discard", "card_index": 0})
        assert result["ok"] is True
        assert result["state_revision"] == 1
        record("active_command")

        updated = client.snapshot(room_code, seat_token=host_token)
        assert updated["state"]["action_log"][-1]["type"] == "discard"
        record("updated_snapshot")

        saved = client.save_room(room_code)
        assert saved["ok"] is True
        record("save_room")

        loaded = client.load_room(room_code)
        assert loaded["state"]["state_revision"] == 1
        assert loaded["state"]["action_log"][-1]["type"] == "discard"
        record("load_room")

        print(f"RESULT {len(passed)}/{len(passed)} live network smoke steps passed")
    finally:
        process.terminate()
        try:
            process.wait(timeout=8)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=8)
        if process.stdout:
            output = process.stdout.read()
            if process.returncode not in (0, -15, 1) and output:
                print(output[-2000:])
        temp_dir.cleanup()


def main():
    args = parse_args()
    run_smoke_test(args.host, args.port)


if __name__ == "__main__":
    main()
