import json
import os
import sys
import tempfile
import json
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from network.shape_azoid_room_service import ShapeAzoidRoomService
from shape_azoid_core import BOARD_CENTER, make_card, midpoint, side_list, centroid, dist


def near_wall_click(wall, pixels=38):
    a, b = wall
    mid = midpoint(a, b)
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    length = dist(a, b) or 1.0
    return (mid[0] - dy / length * pixels, mid[1] + dx / length * pixels)


def main():
    service = ShapeAzoidRoomService()
    lobby = service.create_room(host_name="Jeremy", player_count=2, ai_players=[], start=False)
    lobby_code = lobby["room_code"]
    host_lobby_token = lobby["host_seat_token"]
    listed = service.list_rooms()
    assert listed["ok"] is True
    assert listed["rooms"][0]["room_code"] == lobby_code
    assert listed["rooms"][0]["phase"] == "lobby"
    print("PASS room listing")
    lobby_view = service.snapshot(lobby_code, seat_token=host_lobby_token)
    assert lobby_view["phase"] == "lobby"
    assert lobby_view["state"]["mode"] == "lobby"
    assert lobby_view["state"]["deck_count"] == 0
    assert lobby_view["state"]["hands"] == [{"count": 0}]
    joined = service.join_room(lobby_code, player_name="Guest")
    assert joined["ok"], joined
    assert joined["seat_index"] == 1
    guest_lobby_token = joined["seat_token"]
    joined_again = service.join_room(lobby_code, player_name="Guest", seat_token=guest_lobby_token)
    assert joined_again["ok"], joined_again
    assert joined_again["seat_index"] == 1
    assert len(joined_again["seats"]) == 2
    color_changed = service.update_seat(lobby_code, guest_lobby_token, color_index=2)
    assert color_changed["ok"], color_changed
    assert color_changed["seats"][1]["color_name"] == "Yellow"
    color_taken = service.update_seat(lobby_code, guest_lobby_token, color_index=0)
    assert not color_taken["ok"] and "taken" in color_taken["error"]
    guest_lobby_view = service.snapshot(lobby_code, seat_token=guest_lobby_token)
    assert guest_lobby_view["viewer_player"] == 1
    assert len(guest_lobby_view["seats"]) == 2
    assert guest_lobby_view["seats"][1]["color_name"] == "Yellow"
    not_started = service.apply_command(lobby_code, host_lobby_token, {"type": "end_turn"})
    assert not not_started["ok"] and "not started" in not_started["error"]
    bad_start = service.start_room(lobby_code, guest_lobby_token)
    assert not bad_start["ok"] and "host" in bad_start["error"].lower()
    started = service.start_room(lobby_code, host_lobby_token)
    assert started["ok"], started
    assert "pygame" not in sys.modules
    assert service.snapshot(lobby_code, seat_token=host_lobby_token)["phase"] == "playing"
    print("PASS lobby join and host start")

    created = service.create_room(host_name="Jeremy", player_count=2, ai_players=[])
    assert "pygame" not in sys.modules
    room_code = created["room_code"]
    host_token = created["host_seat_token"]
    guest_token = service.rooms[room_code]["seat_tokens"][1]

    host_view = service.snapshot(room_code, seat_token=host_token)
    guest_view = service.snapshot(room_code, seat_token=guest_token)
    assert host_view["viewer_player"] == 0
    assert guest_view["viewer_player"] == 1
    assert isinstance(host_view["state"]["hands"][1], dict)
    assert isinstance(guest_view["state"]["hands"][0], dict)
    json.dumps(host_view)
    json.dumps(guest_view)
    print("PASS sanitized per-seat snapshots")

    bad_token = service.apply_command(room_code, "not-a-token", {"type": "end_turn"})
    assert not bad_token["ok"] and "Seat token" in bad_token["error"]
    print("PASS bad token rejected")

    wrong_turn = service.apply_command(room_code, guest_token, {"type": "end_turn"})
    assert not wrong_turn["ok"] and "not that player's turn" in wrong_turn["error"]
    print("PASS inactive seat rejected")

    game = service.rooms[room_code]["game"]
    game.hands[0] = [make_card("hex", 0)]
    placed = service.apply_command(room_code, host_token, {"type": "play_at", "card_index": 0, "pos": BOARD_CENTER})
    assert placed["ok"], placed
    assert placed["state_revision"] == 1
    shape_snapshot = service.snapshot(room_code, seat_token=host_token)
    assert len(shape_snapshot["state"]["pieces"]) == 1
    assert shape_snapshot["state"]["pieces"][0]["shape"] == "hex"
    assert shape_snapshot["state"]["pieces"][0]["owner"] == 0
    game.hands[0] = [make_card("square", 0)]
    attach_pos = midpoint(*side_list(game.pieces[0]["points"])[0])
    attached = service.apply_command(room_code, host_token, {"type": "play_at", "card_index": 0, "pos": attach_pos})
    assert attached["ok"], attached
    assert attached["state_revision"] == 2
    attached_snapshot = service.snapshot(room_code, seat_token=host_token)
    assert len(attached_snapshot["state"]["pieces"]) == 2
    assert attached_snapshot["state"]["pieces"][1]["shape"] == "square"
    print("PASS active shape placement and attachment applied")

    shared_wall = next(key for key, entries in game.shared_edges().items() if len(entries) == 2)
    wall_midpoint = near_wall_click(shared_wall)
    game.hands[0] = [make_card("line", 0)]
    opened = service.apply_command(room_code, host_token, {"type": "play_at", "card_index": 0, "pos": wall_midpoint})
    assert opened["ok"], opened
    assert opened["state_revision"] == 3
    opened_snapshot = service.snapshot(room_code, seat_token=host_token)
    assert len(opened_snapshot["state"]["open_walls"]) == 1
    print("PASS active line card opened near-clicked shared wall")

    missing_card = service.apply_command(room_code, host_token, {"type": "play_at", "card_index": None, "pos": wall_midpoint})
    assert not missing_card["ok"] and "Select a card" in missing_card["error"]
    print("PASS empty online card selection rejected cleanly")

    ball_pos = centroid(game.pieces[0]["points"])
    game.hands[0] = [make_card("zoid", 0)]
    zoid = service.apply_command(room_code, host_token, {"type": "play_at", "card_index": 0, "pos": ball_pos})
    assert zoid["ok"], zoid
    assert zoid["state_revision"] == 4
    zoid_snapshot = service.snapshot(room_code, seat_token=host_token)
    assert len(zoid_snapshot["state"]["zoids"]) == 1
    assert zoid_snapshot["state"]["zoids"][0]["kind"] == "zoid"

    penta_pos = (ball_pos[0], ball_pos[1] + 45)
    game.hands[0] = [make_card("pentagon", 0)]
    penta = service.apply_command(room_code, host_token, {"type": "play_at", "card_index": 0, "pos": penta_pos})
    assert penta["ok"], penta
    assert penta["state_revision"] == 5
    assert len(game.zoids) == 2
    assert game.zoids[1]["kind"] == "penta"
    game.zoids[0]["pos"] = [ball_pos[0], ball_pos[1]]
    game.zoids[0]["vel"] = [0.0, 0.0]
    game.zoids[1]["pos"] = [ball_pos[0], ball_pos[1] + 45]
    game.zoids[1]["vel"] = [0.0, 0.0]
    penta_snapshot = service.snapshot(room_code, seat_token=host_token)
    assert len(penta_snapshot["state"]["zoids"]) == 2
    assert penta_snapshot["state"]["zoids"][1]["kind"] == "penta"

    game.hands[0] = [make_card("zoid", 1)]
    wrong_color = service.apply_command(room_code, host_token, {"type": "play_at", "card_index": 0, "pos": ball_pos})
    assert not wrong_color["ok"] and "Orange" in wrong_color["error"]
    assert len(game.hands[0]) == 1
    print("PASS active Zoid and Penta-Zoid placement applied")

    game.pieces[1]["owner"] = 1
    first_center = centroid(game.pieces[0]["points"])
    second_center = centroid(game.pieces[1]["points"])
    dx = second_center[0] - first_center[0]
    dy = second_center[1] - first_center[1]
    length = dist(first_center, second_center) or 1.0
    game.zoids[0]["pos"] = [first_center[0], first_center[1]]
    game.zoids[0]["piece"] = 0
    game.zoids[0]["vel"] = [dx / length * 8.0, dy / length * 8.0]
    game.zoids[1]["pos"] = [first_center[0], first_center[1] + 45]
    game.zoids[1]["vel"] = [0.0, 0.0]
    for _ in range(80):
        game.update_zoids()
        if game.zoids[0]["piece"] == 1:
            break
    assert game.zoids[0]["piece"] == 1
    assert game.pieces[1]["owner"] == 0
    assert 1 in game.zoids[0]["visited"]
    moved_snapshot = service.snapshot(room_code, seat_token=host_token)
    assert moved_snapshot["state"]["zoids"][0]["piece"] == 1
    assert moved_snapshot["state"]["pieces"][1]["owner"] == 0
    print("PASS active Zoid moved through opened wall")

    game.zoids = [
        {
            "pos": [first_center[0], first_center[1]],
            "vel": [0.0, 0.0],
            "owner": 0,
            "played_by": 0,
            "piece": 0,
            "kind": "zoid",
            "visited": {0},
        },
        {
            "pos": [first_center[0] + 1, first_center[1]],
            "vel": [0.0, 0.0],
            "owner": 1,
            "played_by": 1,
            "piece": 0,
            "kind": "penta",
            "visited": {0},
        },
    ]
    game.update_zoids()
    assert len(game.zoids) == 1
    assert game.zoids[0]["kind"] == "penta"
    game.zoids = [
        {
            "pos": [first_center[0], first_center[1]],
            "vel": [0.0, 0.0],
            "owner": 0,
            "played_by": 0,
            "piece": 0,
            "kind": "penta",
            "visited": {0},
        },
        {
            "pos": [first_center[0] + 1, first_center[1]],
            "vel": [0.0, 0.0],
            "owner": 1,
            "played_by": 1,
            "piece": 0,
            "kind": "penta",
            "visited": {0},
        },
    ]
    game.update_zoids()
    assert len(game.zoids) == 0
    print("PASS Penta-Zoid collision rules")

    game.zoids = [
        {
            "pos": [first_center[0], first_center[1]],
            "vel": [0.0, 0.0],
            "owner": 0,
            "played_by": 0,
            "piece": 0,
            "kind": "zoid",
            "visited": {0},
        },
        {
            "pos": [second_center[0], second_center[1]],
            "vel": [0.0, 0.0],
            "owner": 1,
            "played_by": 1,
            "piece": 1,
            "kind": "penta",
            "visited": {1},
        },
    ]

    game.hands[0] = [make_card("square", 0)]
    before_deck = len(game.deck)
    result = service.apply_command(room_code, host_token, {"type": "discard", "card_index": 0})
    assert result["ok"], result
    assert result["state_revision"] == 6
    assert len(game.hands[0]) == 0
    assert len(game.deck) == before_deck + 1
    print("PASS active discard command applied")

    updated = service.snapshot(room_code, seat_token=host_token)
    assert updated["state"]["state_revision"] == 6
    assert updated["state"]["action_log"][-1]["type"] == "discard"
    json.dumps(updated)
    print("PASS updated snapshot includes action log")

    with tempfile.TemporaryDirectory() as tmp:
        service.save_dir = Path(tmp)
        saved_path = service.save_room(room_code)
        assert saved_path.exists()
        restored_service = ShapeAzoidRoomService(save_dir=tmp)
        restored = restored_service.load_room(room_code)
        assert restored["state"]["state_revision"] == 6
        assert restored["state"]["action_log"][-1]["type"] == "discard"
        assert len(restored["state"]["pieces"]) == 2
        assert len(restored["state"]["open_walls"]) == 1
        assert len(restored["state"]["zoids"]) == 2
        assert isinstance(restored["state"]["hands"][1], dict)
    print("PASS authoritative save and load")

    ufo_room = service.create_room(host_name="Jeremy", player_count=2, ai_players=[])
    ufo_code = ufo_room["room_code"]
    ufo_token = ufo_room["host_seat_token"]
    ufo_game = service.rooms[ufo_code]["game"]
    ufo_game.hands[0] = [make_card("hex", 0)]
    ufo_placed = service.apply_command(ufo_code, ufo_token, {"type": "play_at", "card_index": 0, "pos": BOARD_CENTER})
    assert ufo_placed["ok"], ufo_placed
    ufo_game.next_ufo_at = 1000
    ufo_game.update_ufo(1000)
    assert ufo_game.active_ufo is not None
    assert ufo_game.active_ufo["target_idx"] == 0
    ufo_snapshot = ufo_game.state_snapshot(viewer_player=0)
    assert ufo_snapshot["active_ufo"]["target_idx"] == 0
    with tempfile.TemporaryDirectory() as tmp:
        service.save_dir = Path(tmp)
        ufo_path = service.save_room(ufo_code)
        saved_ufo = json.loads(ufo_path.read_text(encoding="utf-8"))
        assert saved_ufo["game"]["active_ufo"]["target_idx"] == 0
    ufo_game.update_ufo(ufo_game.active_ufo["hit_at"])
    assert len(ufo_game.pieces) == 0
    assert ufo_game.message.startswith("UFO blasted")
    ufo_game.update_ufo(ufo_game.active_ufo["ends_at"])
    assert ufo_game.active_ufo is None
    assert ufo_game.next_ufo_at > 0
    print("PASS UFO tile destruction and save/load state")

    game.mode = "playing"
    game.current_player = 0
    game.last_card_drawn = True
    game.no_discard_turns_after_empty = game.player_count - 1
    game.discarded_this_turn = False
    scored = service.apply_command(room_code, host_token, {"type": "end_turn"})
    assert scored["ok"], scored
    scored_snapshot = service.snapshot(room_code, seat_token=host_token)
    assert scored_snapshot["phase"] == "playing"
    assert scored_snapshot["state"]["mode"] == "score"
    score_state = scored_snapshot["state"]
    score_breakdown = score_state["last_score_breakdown"]
    assert score_state["players"][0]["score_round"] == 6, score_breakdown
    assert score_state["players"][0]["score_total"] == 6, score_breakdown
    assert score_state["players"][1]["score_round"] == 5, score_breakdown
    assert score_state["players"][1]["score_total"] == 5, score_breakdown
    assert score_breakdown[0]["placed"] == 2, score_breakdown
    assert score_breakdown[0]["color"] == 2, score_breakdown
    assert score_breakdown[0]["zoid"] == 2, score_breakdown
    assert score_breakdown[0]["lights"] == 0, score_breakdown
    assert score_breakdown[1]["color"] == 2, score_breakdown
    assert score_breakdown[1]["penta"] == 3, score_breakdown
    print("PASS round-end scoring")

    game.action_log = [
        {"revision": idx, "actor": 0, "type": "noise", "payload": {}, "message": "old"}
        for idx in range(100)
    ]
    stream_view = service.stream_snapshot(room_code, seat_token=host_token)
    assert stream_view["state"]["mode"] == "score"
    assert len(stream_view["state"]["action_log"]) <= 12
    assert stream_view["state"]["action_log"][0]["revision"] == 88
    print("PASS live stream snapshot trims old action log")

    next_round = service.apply_command(room_code, guest_token, {"type": "next_round"})
    assert next_round["ok"], next_round
    assert next_round["state"]["mode"] == "playing"
    assert next_round["state"]["current_player"] == 0
    assert next_round["state"]["players"][0]["score_total"] == 6
    assert next_round["state"]["players"][1]["score_total"] == 5
    assert next_round["state"]["action_log"][-1]["type"] == "next_round"
    print("PASS server-owned next round after online scoring")

    print("RESULT room service probes passed")


if __name__ == "__main__":
    main()
