import importlib.util
import os
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "shape_azoid.py"


def load_game_module():
    spec = importlib.util.spec_from_file_location("shape_azoid", SOURCE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    module = load_game_module()
    game = module.Game()

    fractional_wall = [[642.63, 272.19], [735.47, 295.88]]
    expected = module.edge_key(fractional_wall[0], fractional_wall[1])
    imported = game.wall_tuple_from_snapshot(fractional_wall)
    if imported != expected:
        raise SystemExit(f"FAIL snapshot wall key drifted: expected {expected}, got {imported}")
    if any(float(value).is_integer() for point in imported for value in point):
        raise SystemExit(f"FAIL snapshot wall key was truncated to integers: {imported}")

    game.player_count = 2
    game.setup()
    first = module.build_points_for_shape("hex")
    first_center = module.centroid(first)
    attach_side = max(module.side_list(first), key=lambda side: module.midpoint(side[0], side[1])[0])
    second = module.build_points_for_shape("square", attach_side[0], attach_side[1], first_center)
    game.pieces = [
        {"shape": "hex", "points": first, "owner": 0, "played_by": 0},
        {"shape": "square", "points": second, "owner": 0, "played_by": 0},
    ]
    shared_wall = next(key for key, entries in game.shared_edges().items() if len(entries) == 2)
    game.open_walls.add(shared_wall)
    snapshot_wall = game.state_snapshot()["open_walls"][0]
    imported_snapshot_wall = game.wall_tuple_from_snapshot(snapshot_wall)
    if imported_snapshot_wall != shared_wall:
        raise SystemExit(
            f"FAIL real snapshot wall did not round-trip: expected {shared_wall}, got {imported_snapshot_wall}"
        )

    print("PASS snapshot walls preserve engine edge_key identity")
    print("RESULT 2/2 wall identity probes passed")


if __name__ == "__main__":
    main()
