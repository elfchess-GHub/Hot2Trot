import json
import os
import sys
import tempfile
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")


def main():
    with tempfile.TemporaryDirectory() as temp_dir:
        os.environ["SHAPE_AZOID_TELEMETRY"] = "1"
        os.environ["SHAPE_AZOID_TELEMETRY_DIR"] = temp_dir

        root = Path(__file__).resolve().parents[1]
        sys.path.insert(0, str(root))
        import shape_azoid

        game = shape_azoid.GAME
        try:
            assert game.telemetry.path.startswith(temp_dir)

            game.player_count = 2
            game.ai_players = set()
            game.setup()
            game.start()
            board_center = shape_azoid.BOARD_RECT.center
            game.hands[0] = [shape_azoid.make_card("hex", 0)]
            first = game.apply_player_command({"type": "play_at", "card_index": 0, "pos": board_center})
            assert first["ok"], first

            game.current_player = 0
            game.cards_used_this_turn = 0
            game.hands[0] = [shape_azoid.make_card("square", 0)]
            attach_pos = shape_azoid.midpoint(*shape_azoid.side_list(game.pieces[0]["points"])[0])
            second = game.apply_player_command({"type": "play_at", "card_index": 0, "pos": attach_pos})
            assert second["ok"], second

            shared_wall = next(key for key, entries in game.shared_edges().items() if len(entries) == 2 and key not in game.open_walls)
            game.current_player = 0
            game.cards_used_this_turn = 0
            game.hands[0] = [shape_azoid.make_card("line", 0)]
            line_pos = shape_azoid.midpoint(shared_wall[0], shared_wall[1])
            opened = game.apply_player_command({"type": "play_at", "card_index": 0, "pos": line_pos})
            assert opened["ok"], opened
            game.telemetry_tick(16.7, phase_times={
                "events_ms": 1.0,
                "update_ms": 2.0,
                "draw_ms": 3.0,
                "flip_ms": 4.0,
                "work_ms": 10.0,
                "wait_ms": 6.7,
            })
        finally:
            game.telemetry.close()

        rows = [
            json.loads(line)
            for line in Path(game.telemetry.path).read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        line_rows = [row for row in rows if row.get("kind") == "line_attempt"]
        assert line_rows, "missing line_attempt telemetry row"
        assert line_rows[-1]["ok"] is True
        assert line_rows[-1]["diagnostic"]["target_found"] is True
        assert any(row.get("kind") == "play_state" for row in rows)
        play_rows = [row for row in rows if row.get("kind") == "play_state"]
        assert any(row.get("phase_ms", {}).get("draw_ms") == 3.0 for row in play_rows), "missing phase timing"
        assert any(row.get("kind") == "run_start" for row in rows)
        assert any(row.get("kind") == "run_end" for row in rows)

        print(f"PASS telemetry log captured line attempt at {game.telemetry.path}")
        print("RESULT 1/1 telemetry probes passed")


if __name__ == "__main__":
    main()
