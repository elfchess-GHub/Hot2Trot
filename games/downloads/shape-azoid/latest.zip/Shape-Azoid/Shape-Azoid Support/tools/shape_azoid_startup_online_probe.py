import os
import sys
import tempfile
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from network.shape_azoid_http_client import ShapeAzoidHttpClient


class ProbeFailure(RuntimeError):
    pass


def wait_for_server(client, timeout_seconds=12.0):
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        try:
            if client.health().get("ok"):
                return
        except Exception:
            pass
        time.sleep(0.2)
    raise ProbeFailure("Server did not become ready.")


def main():
    temp_dir = tempfile.TemporaryDirectory()
    env = {
        **dict(os.environ),
        "SHAPE_AZOID_ROOM_SAVE_DIR": temp_dir.name,
        "SDL_VIDEODRIVER": "dummy",
        "SDL_AUDIODRIVER": "dummy",
    }
    try:
        code = (
            "import sys, pygame, shape_azoid; "
            "from network.shape_azoid_http_client import ShapeAzoidHttpClient; "
            "sys.argv=['shape_azoid.py','--online','--online-create','--online-name','Jeremy']; "
            "shape_azoid.apply_startup_args(); "
            "pygame.time.wait(250); "
            "client=ShapeAzoidHttpClient(shape_azoid.GAME.online_server_url); "
            "rooms=client.list_rooms()['rooms']; "
            "print('online', shape_azoid.GAME.online_server_url, shape_azoid.GAME.online_room_code, len(rooms), rooms[0]['phase']); "
            "shape_azoid.GAME.online_server_process.terminate(); "
            "shape_azoid.GAME.online_server_process.wait(timeout=8)"
        )
        import subprocess

        result = subprocess.run(
            [sys.executable, "-c", code],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            env=env,
            timeout=18,
        )
        if result.returncode != 0:
            raise ProbeFailure(result.stderr or result.stdout)
        lines = [line for line in result.stdout.splitlines() if line.startswith("online ")]
        if not lines:
            raise ProbeFailure(f"Startup process did not report online room: {result.stdout!r}")
        parts = lines[-1].split()
        if int(parts[3]) != 1:
            raise ProbeFailure(f"Expected one created room, got {parts[3]}.")
        if parts[4] != "lobby":
            raise ProbeFailure(f"Expected lobby room, got {parts[4]}.")
        print("PASS startup online auto-create")
        print("RESULT 1/1 startup online probes passed")
    finally:
        temp_dir.cleanup()


if __name__ == "__main__":
    main()
