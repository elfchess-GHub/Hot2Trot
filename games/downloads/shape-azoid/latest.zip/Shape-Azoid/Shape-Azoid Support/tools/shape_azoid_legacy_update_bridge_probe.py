#!/usr/bin/env python3
"""Focused contract probe for build_legacy_update_bridge.py."""

from __future__ import annotations

import argparse
import hashlib
import json
import tempfile
import zipfile
from pathlib import Path

import build_legacy_update_bridge as bridge


LEGACY_ID = bridge.EXPECTED_LEGACY_BUILD_ID
FINAL_ID = "v0.7.33-20260831-1900"
MANIFEST_UPDATER = """$manifestUrl = "latest-release.json"
$manifest = "{}" | ConvertFrom-Json
$expectedSha256 = "0" * 64
function Read-PackageFiles([string]$manifestPath) { return @() }
"""


def write_zip(path: Path, files: dict[str, bytes]) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, content in files.items():
            archive.writestr(name, content)


def create_legacy_fixture(path: Path, game_payload: bytes = b"old-game") -> None:
    write_zip(
        path,
        {
            "Shape-Azoid/BUILD_ID.txt": (LEGACY_ID + "\n").encode("ascii"),
            "Shape-Azoid/Shape-Azoid.exe": game_payload,
            "Shape-Azoid/Update Shape-Azoid.ps1": b"old-updater",
            "Shape-Azoid/Play Shape-Azoid.exe": b"old-launcher",
            "Shape-Azoid/music/old-track.mp3": b"old-track",
            "Shape-Azoid/Settings.json": b"user-settings",
            "Shape-Azoid/PACKAGE_FILES.JSON": b"protected-inventory",
            "Shape-Azoid/Shape-Azoid Support/network/server.py": b"old-support",
            "Shape-Azoid/Shape-Azoid Support/.VENV/Scripts/python.exe": b"old-python",
        },
    )


def create_final_fixture(root: Path) -> None:
    (root / "Shape-Azoid Support" / "network").mkdir(parents=True)
    (root / "Shape-Azoid Support" / ".VENV" / "Scripts").mkdir(parents=True)
    (root / "BUILD_ID.txt").write_text(FINAL_ID + "\n", encoding="ascii")
    (root / "Shape-Azoid.exe").write_bytes(b"new-game")
    (root / "Update Shape-Azoid.ps1").write_text(MANIFEST_UPDATER, encoding="ascii")
    (root / "Install_Shape_Azoid_Requirements.cmd").write_bytes(b"install-support")
    (root / "Shape-Azoid Support" / "network" / "server.py").write_bytes(b"new-support")
    (root / "Shape-Azoid Support" / ".VENV" / "Scripts" / "python.exe").write_bytes(
        b"must-not-ship"
    )
    (root / "settings.json").write_bytes(b"must-not-ship")
    (root / "music").mkdir()
    (root / "music" / "full-release-only.mp3").write_bytes(b"must-not-ship")


def inspect_bridge(
    path: Path,
    expected_updater: bytes,
) -> tuple[list[str], dict[str, object]]:
    with zipfile.ZipFile(path, "r") as archive:
        names = archive.namelist()
        manifest = json.loads(archive.read("Shape-Azoid/PACKAGE_FILES.json"))
        assert archive.read("Shape-Azoid/BUILD_ID.txt").decode("ascii").strip() == (
            "v0.7.33-bootstrap-20260831-1859"
        )
        assert archive.read("Shape-Azoid/Shape-Azoid.exe") == b"new-game"
        assert archive.read("Shape-Azoid/Update Shape-Azoid.ps1") == expected_updater
        assert archive.read("Shape-Azoid/Shape-Azoid Support/network/server.py") == (
            b"new-support"
        )
    return names, manifest


def run_fixture_probe() -> list[str]:
    checks: list[str] = []
    with tempfile.TemporaryDirectory(prefix="ShapeAzoidBridgeProbe_") as temp:
        temp_root = Path(temp)
        legacy_zip = temp_root / "legacy.zip"
        final_root = temp_root / "final" / "Shape-Azoid"
        final_root.mkdir(parents=True)
        create_legacy_fixture(legacy_zip)
        create_final_fixture(final_root)
        legacy_hash = hashlib.sha256(legacy_zip.read_bytes()).hexdigest()

        first_zip = temp_root / "bridge-one.zip"
        second_zip = temp_root / "bridge-two.zip"
        first = bridge.build_bridge(
            legacy_zip,
            final_root,
            first_zip,
            expected_legacy_sha256=legacy_hash,
        )
        second = bridge.build_bridge(
            legacy_zip,
            final_root,
            second_zip,
            expected_legacy_sha256=legacy_hash,
        )
        assert first.bootstrap_build_id == "v0.7.33-bootstrap-20260831-1859"
        assert first.sha256 == second.sha256
        assert first_zip.read_bytes() == second_zip.read_bytes()
        checks.append("deterministic bridge and strictly earlier bootstrap ID")

        names, manifest = inspect_bridge(
            first_zip,
            (final_root / "Update Shape-Azoid.ps1").read_bytes(),
        )
        assert all(name.startswith("Shape-Azoid/") for name in names)
        assert "Shape-Azoid/settings.json" not in names
        assert not any("/.venv/" in name.casefold() for name in names)
        assert "Shape-Azoid/music/full-release-only.mp3" not in names
        checks.append("small Shape-Azoid-rooted migration payload only")

        managed = manifest["files"]
        assert manifest["version"] == 1
        assert "music/old-track.mp3" in managed
        assert "Play Shape-Azoid.exe" in managed
        assert not any(name.casefold() == "settings.json" for name in managed)
        assert not any(name.casefold() == "package_files.json" for name in managed)
        assert not any(".venv" in name.casefold().split("/") for name in managed)
        checks.append("old managed inventory excludes settings and every .venv file")

        altered_zip = temp_root / "altered-same-id.zip"
        create_legacy_fixture(altered_zip, game_payload=b"altered-game")
        try:
            bridge.build_bridge(
                altered_zip,
                final_root,
                temp_root / "altered-must-fail.zip",
                expected_legacy_sha256=legacy_hash,
            )
        except bridge.BridgeBuildError as exc:
            assert "SHA-256 did not match" in str(exc)
        else:
            raise AssertionError("same-ID altered legacy package was accepted")
        checks.append("same-ID altered legacy archive rejected by pinned SHA-256")

        stale_updater_root = temp_root / "stale" / "Shape-Azoid"
        create_final_fixture(stale_updater_root)
        (stale_updater_root / "Update Shape-Azoid.ps1").write_text(
            "$downloadUrl = 'latest.zip'\n", encoding="ascii"
        )
        try:
            bridge.build_bridge(
                legacy_zip,
                stale_updater_root,
                temp_root / "must-fail.zip",
                expected_legacy_sha256=legacy_hash,
            )
        except bridge.BridgeBuildError as exc:
            assert "not the manifest/hash/package-inventory updater" in str(exc)
        else:
            raise AssertionError("stale updater was accepted")
        checks.append("stale updater rejected before a bridge is written")

    return checks


def inspect_real_legacy(path: Path) -> str:
    build_id, managed = bridge.inspect_legacy_package(path)
    assert build_id == LEGACY_ID
    assert not any(name.casefold() == "settings.json" for name in managed)
    assert not any(name.casefold() == "package_files.json" for name in managed)
    assert not any(".venv" in name.casefold().split("/") for name in managed)
    return f"real {build_id} inventory accepted ({len(managed)} managed files)"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--legacy-zip", type=Path)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    checks = run_fixture_probe()
    if args.legacy_zip is not None:
        checks.append(inspect_real_legacy(args.legacy_zip.resolve()))
    for index, message in enumerate(checks, start=1):
        print(f"PASS {index}: {message}")
    print(f"PASS: legacy update bridge probe ({len(checks)}/{len(checks)})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
