import importlib.util
import json
import os
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "shape_azoid.py"


def load_game_module():
    spec = importlib.util.spec_from_file_location("shape_azoid", SOURCE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def fresh_game(module):
    game = module.Game()
    game.player_count = 2
    game.ai_players = set()
    game.setup()
    game.mode = "playing"
    game.reset_match_sync_state()
    return game


def test_first_shape_command(module):
    game = fresh_game(module)
    game.hands[0] = [module.make_card("square", 0)]
    game.hands[1] = [module.make_card("zoid", 1)]

    wrong_turn = game.apply_player_command({"type": "end_turn"}, actor=1)
    assert not wrong_turn["ok"] and "not that player" in wrong_turn["error"]

    result = game.apply_player_command(
        {
            "type": "play_at",
            "card_index": 0,
            "pos": [module.BOARD_RECT.centerx, module.BOARD_RECT.centery],
        }
    )
    assert result["ok"], result
    assert len(game.pieces) == 1
    assert game.state_revision == 1
    assert game.action_log[-1]["type"] == "play_at"
    json.dumps(game.state_snapshot(viewer_player=0))


def test_discard_command(module):
    game = fresh_game(module)
    game.hands[0] = [module.make_card("line", 0)]
    before_deck = len(game.deck)

    result = game.apply_player_command({"type": "discard", "card_index": 0})
    assert result["ok"], result
    assert len(game.hands[0]) == 0
    assert len(game.deck) == before_deck + 1
    assert game.action_log[-1]["type"] == "discard"


def test_wild_command_and_private_snapshot(module):
    game = fresh_game(module)
    game.round_wild_kind = "square"
    game.hands[0] = [module.make_card("square", 0, wild=True)]

    result = game.apply_player_command({"type": "cycle_wild", "card_index": 0})
    assert result["ok"], result
    assert module.card_kind(game.hands[0][0]) != "square"
    assert game.action_log[-1]["type"] == "cycle_wild"

    viewer = game.state_snapshot(viewer_player=0)
    assert isinstance(viewer["hands"][1], dict)
    assert viewer["hands"][1]["count"] == len(game.hands[1])
    json.dumps(viewer)


def main():
    module = load_game_module()
    tests = [
        test_first_shape_command,
        test_discard_command,
        test_wild_command_and_private_snapshot,
    ]
    for test in tests:
        test(module)
        print(f"PASS {test.__name__}")
    print(f"RESULT {len(tests)}/{len(tests)} command seam probes passed")


if __name__ == "__main__":
    main()
