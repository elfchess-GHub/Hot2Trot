import math
import os
import sys
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import shape_azoid


def close_point(a, b, tolerance=1.0):
    return math.hypot(float(a[0]) - float(b[0]), float(a[1]) - float(b[1])) <= tolerance


def make_two_square_game():
    game = shape_azoid.Game()
    game.player_count = 2
    game.setup()
    first = shape_azoid.build_points_for_shape("square")
    first_center = shape_azoid.centroid(first)
    attach_side = max(shape_azoid.side_list(first), key=lambda side: shape_azoid.midpoint(side[0], side[1])[0])
    second = shape_azoid.build_points_for_shape("square", attach_side[0], attach_side[1], first_center)
    game.pieces = [
        {"shape": "square", "points": first, "owner": 0, "played_by": 0},
        {"shape": "square", "points": second, "owner": 0, "played_by": 0},
    ]
    shared_wall = next(key for key, entries in game.shared_edges().items() if len(entries) == 2)
    return game, shared_wall


def count_spokes_to_wall(game, wall):
    old_game = shape_azoid.GAME
    old_line = shape_azoid.pygame.draw.line
    shared = game.shared_edges()
    centers = [shape_azoid.centroid(piece["points"]) for piece in game.pieces]
    wall_mid = shape_azoid.midpoint(wall[0], wall[1])
    hits = []

    def record_line(surface, color, start_pos, end_pos, width=1):
        if (
            any(close_point(start_pos, center) for center in centers)
            and close_point(end_pos, wall_mid)
        ) or (
            any(close_point(end_pos, center) for center in centers)
            and close_point(start_pos, wall_mid)
        ):
            hits.append((tuple(color), start_pos, end_pos, width))
        return old_line(surface, color, start_pos, end_pos, width)

    try:
        shape_azoid.GAME = game
        shape_azoid.pygame.draw.line = record_line
        for idx, piece in enumerate(game.pieces):
            shape_azoid.draw_shape_circuit(idx, piece, shared)
    finally:
        shape_azoid.pygame.draw.line = old_line
        shape_azoid.GAME = old_game
    return hits


def render_wall_edges(edges):
    old_screen = shape_azoid.SCREEN
    surface = shape_azoid.pygame.Surface((128, 128), shape_azoid.pygame.SRCALPHA)
    try:
        shape_azoid.SCREEN = surface
        shape_azoid.draw_wall_network(edges, (78, 88, 104), 5, dark=True)
        return surface
    finally:
        shape_azoid.SCREEN = old_screen


def surface_bytes(surface):
    return shape_azoid.pygame.image.tobytes(surface, "RGBA")


def perpendicular_thickness(surface, a, b):
    dx, dy = float(b[0]) - float(a[0]), float(b[1]) - float(a[1])
    length = math.hypot(dx, dy)
    ux, uy = dx / length, dy / length
    cap_margin = 10.0
    alpha_weight = 0.0
    for y in range(surface.get_height()):
        for x in range(surface.get_width()):
            along = (x - float(a[0])) * ux + (y - float(a[1])) * uy
            if cap_margin <= along <= length - cap_margin:
                alpha_weight += surface.get_at((x, y)).a / 255.0
    if not alpha_weight:
        raise SystemExit(f"FAIL no wall pixels found for edge {a}->{b}")
    return alpha_weight / (length - cap_margin * 2.0)


def render_board(game):
    old_game = shape_azoid.GAME
    old_screen = shape_azoid.SCREEN
    surface = shape_azoid.pygame.Surface(
        (shape_azoid.WIDTH, shape_azoid.HEIGHT),
        shape_azoid.pygame.SRCALPHA,
    )
    try:
        shape_azoid.GAME = game
        shape_azoid.SCREEN = surface
        shape_azoid.draw_board()
        return surface
    finally:
        shape_azoid.SCREEN = old_screen
        shape_azoid.GAME = old_game


def wall_palette_pixel_count(surface, wall):
    palette = {
        tuple(color)
        for color, _ in shape_azoid.wall_layer_styles((78, 88, 104), 5, dark=True)
    }
    count = 0
    for index in range(15, 86):
        if 44 <= index <= 56:
            continue
        t = index / 100.0
        x = round(wall[0][0] + (wall[1][0] - wall[0][0]) * t)
        y = round(wall[0][1] + (wall[1][1] - wall[0][1]) * t)
        for px in range(x - 5, x + 6):
            for py in range(y - 5, y + 6):
                if tuple(surface.get_at((px, py))[:3]) in palette:
                    count += 1
    return count


def matching_outer_wall(game, wall):
    target_dx = wall[1][0] - wall[0][0]
    target_dy = wall[1][1] - wall[0][1]
    target_length = math.hypot(target_dx, target_dy)
    for entries in game.shared_edges().values():
        if len(entries) != 1:
            continue
        _, _, a, b = entries[0]
        dx, dy = b[0] - a[0], b[1] - a[1]
        length = math.hypot(dx, dy)
        cross = abs(dx * target_dy - dy * target_dx)
        if abs(length - target_length) <= 1.0 and cross <= target_length * length * 0.001:
            return shape_azoid.edge_key(a, b)
    raise SystemExit("FAIL no actual-board outer wall matches the shared wall orientation")


def edge_at_angle(degrees, radius=42.0):
    angle = math.radians(degrees)
    dx = math.cos(angle) * radius
    dy = math.sin(angle) * radius
    return ((64.0 - dx, 64.0 - dy), (64.0 + dx, 64.0 + dy))


def verify_wall_cache_key(network):
    old_build = shape_azoid.build_wall_network_surface
    old_screen = shape_azoid.SCREEN
    build_calls = []

    def record_build(canonical_edges, color, width, dark=False):
        build_calls.append((canonical_edges, tuple(color), width, dark))
        return old_build(canonical_edges, color, width, dark=dark)

    try:
        shape_azoid.WALL_NETWORK_CACHE.clear()
        shape_azoid.WALL_NETWORK_CACHE_ORDER.clear()
        shape_azoid.build_wall_network_surface = record_build
        shape_azoid.SCREEN = shape_azoid.pygame.Surface((128, 128), shape_azoid.pygame.SRCALPHA)
        shape_azoid.draw_wall_network(network, (78, 88, 104), 5, dark=True)
        shape_azoid.draw_wall_network(list(reversed(network)), (78, 88, 104), 5, dark=True)
        shape_azoid.draw_wall_network(
            [(b, a) for a, b in reversed(network)],
            (78, 88, 104),
            5,
            dark=True,
        )
        shape_azoid.draw_wall_network(network[:-1], (78, 88, 104), 5, dark=True)
        shape_azoid.draw_wall_network(network, (79, 88, 104), 5, dark=True)
        shape_azoid.draw_wall_network(network, (78, 88, 104), 6, dark=True)
        shape_azoid.draw_wall_network(network, (78, 88, 104), 5, dark=False)
    finally:
        shape_azoid.SCREEN = old_screen
        shape_azoid.build_wall_network_surface = old_build

    if len(build_calls) != 5:
        raise SystemExit(
            "FAIL canonical cache should reuse reversals and invalidate edge/style changes: "
            f"builds={len(build_calls)}"
        )
    if len(shape_azoid.WALL_NETWORK_CACHE) != shape_azoid.WALL_NETWORK_CACHE_LIMIT:
        raise SystemExit(
            "FAIL wall cache should retain only its configured recent entries: "
            f"{len(shape_azoid.WALL_NETWORK_CACHE)}"
        )


def count_board_wall_marks(game, wall):
    old_game = shape_azoid.GAME
    old_network = shape_azoid.draw_wall_network
    old_line = shape_azoid.pygame.draw.line
    edge_hits = []
    line_hits = []
    wall_mid = shape_azoid.midpoint(wall[0], wall[1])
    centers = [shape_azoid.centroid(piece["points"]) for piece in game.pieces]

    def same_edge(a, b):
        return (
            close_point(a, wall[0]) and close_point(b, wall[1])
        ) or (
            close_point(a, wall[1]) and close_point(b, wall[0])
        )

    def record_network(edges, color, width, dark=False):
        edges = list(edges)
        for a, b in edges:
            if same_edge(a, b):
                edge_hits.append((a, b, width))
        return old_network(edges, color, width, dark=dark)

    def record_line(surface, color, start_pos, end_pos, width=1):
        if same_edge(start_pos, end_pos) or (
            width >= 10
            and (
                any(close_point(start_pos, center) for center in centers)
                and close_point(end_pos, wall_mid)
            )
        ) or (
            width >= 10
            and (
                any(close_point(end_pos, center) for center in centers)
                and close_point(start_pos, wall_mid)
            )
        ):
            line_hits.append((start_pos, end_pos, width))
        return old_line(surface, color, start_pos, end_pos, width)

    try:
        shape_azoid.GAME = game
        shape_azoid.draw_wall_network = record_network
        shape_azoid.pygame.draw.line = record_line
        shape_azoid.draw_board()
    finally:
        shape_azoid.pygame.draw.line = old_line
        shape_azoid.draw_wall_network = old_network
        shape_azoid.GAME = old_game
    return len(edge_hits), len(line_hits)


def board_edge_signatures(game):
    old_game = shape_azoid.GAME
    old_network = shape_azoid.draw_wall_network
    signatures = []

    def record_network(edges, color, width, dark=False):
        edges = list(edges)
        signatures.append((len(edges), tuple(color), width, dark))

    try:
        shape_azoid.GAME = game
        shape_azoid.draw_wall_network = record_network
        shape_azoid.draw_board()
    finally:
        shape_azoid.draw_wall_network = old_network
        shape_azoid.GAME = old_game
    return signatures


def main():
    game, wall = make_two_square_game()
    closed_spokes = count_spokes_to_wall(game, wall)
    if len(closed_spokes) != 2 or any(hit[0] != (2, 4, 8) for hit in closed_spokes):
        raise SystemExit(f"FAIL closed wall should draw 2 dark center spokes, got {closed_spokes}")
    closed_edges, _ = count_board_wall_marks(game, wall)
    if closed_edges != 1:
        raise SystemExit(f"FAIL closed shared wall should draw 1 edge, got {closed_edges}")
    signatures = board_edge_signatures(game)
    if len(signatures) != 1 or signatures[0][0] < 2 or signatures[0][1:] != ((78, 88, 104), 5, True):
        raise SystemExit(f"FAIL board should issue one uniform batched wall network: {signatures}")
    closed_wall_pixels = wall_palette_pixel_count(render_board(game), wall)
    if closed_wall_pixels < 50:
        raise SystemExit(f"FAIL actual board raster is missing the closed wall: {closed_wall_pixels}")
    outer_wall = matching_outer_wall(game, wall)
    outer_wall_pixels = wall_palette_pixel_count(render_board(game), outer_wall)
    wall_pixel_difference = abs(closed_wall_pixels - outer_wall_pixels)
    if wall_pixel_difference > max(12, round(max(closed_wall_pixels, outer_wall_pixels) * 0.08)):
        raise SystemExit(
            "FAIL actual-board inner and outer walls have different raster coverage: "
            f"inner={closed_wall_pixels} outer={outer_wall_pixels}"
        )

    game.open_walls.add(wall)
    open_spokes = count_spokes_to_wall(game, wall)
    if len(open_spokes) != 2 or any(hit[0] != shape_azoid.WHITE for hit in open_spokes):
        raise SystemExit(f"FAIL open same-color wall should draw 2 white center spokes, got {open_spokes}")
    open_edges, open_fake_lines = count_board_wall_marks(game, wall)
    if open_edges != 0:
        raise SystemExit(f"FAIL open shared wall should draw 0 edges, got {open_edges}")
    if open_fake_lines != 0:
        raise SystemExit(f"FAIL open shared wall should draw 0 fake eraser lines, got {open_fake_lines}")
    same_color_open_pixels = wall_palette_pixel_count(render_board(game), wall)
    if same_color_open_pixels != 0:
        raise SystemExit(
            f"FAIL actual board raster retained wall pixels in same-color opening: {same_color_open_pixels}"
        )

    game.pieces[1]["owner"] = 1
    different_spokes = count_spokes_to_wall(game, wall)
    if different_spokes:
        raise SystemExit(f"FAIL open different-color wall should draw 0 spokes, got {different_spokes}")
    different_edges, different_fake_lines = count_board_wall_marks(game, wall)
    if different_edges != 0 or different_fake_lines != 0:
        raise SystemExit(
            "FAIL open different-color wall should leave an empty doorway, "
            f"got edges={different_edges} fake_lines={different_fake_lines}"
        )
    different_open_pixels = wall_palette_pixel_count(render_board(game), wall)
    if different_open_pixels != 0:
        raise SystemExit(
            f"FAIL actual board raster retained wall pixels in different-color opening: {different_open_pixels}"
        )

    forward = render_wall_edges([((18, 27), (78, 69))])
    reverse = render_wall_edges([((78, 69), (18, 27))])
    if surface_bytes(forward) != surface_bytes(reverse):
        raise SystemExit("FAIL shaped edge pixels change when endpoints reverse")

    thickness_angles = (0, 15, 30, 45, 60, 75, 90, 105, 120, 135, 150, 165)
    thickness_edges = {f"{angle}deg": edge_at_angle(angle) for angle in thickness_angles}
    thicknesses = {
        name: perpendicular_thickness(render_wall_edges([edge]), *edge)
        for name, edge in thickness_edges.items()
    }
    if max(thicknesses.values()) - min(thicknesses.values()) > 0.35:
        raise SystemExit(f"FAIL wall perpendicular thickness varies by direction: {thicknesses}")

    network = [
        ((20, 64), (64, 64)),
        ((64, 64), (98, 30)),
        ((64, 64), (98, 98)),
        ((64, 64), (64, 108)),
    ]
    network_forward = render_wall_edges(network)
    network_reverse = render_wall_edges(list(reversed(network)))
    if surface_bytes(network_forward) != surface_bytes(network_reverse):
        raise SystemExit("FAIL joined wall network pixels depend on edge-list draw order")
    if network_forward.get_at((64, 64)).a == 0:
        raise SystemExit("FAIL joined wall network leaves a gap at the shared endpoint")
    verify_wall_cache_key(network)

    print("PASS actual-board inner and outer walls use equivalent batched raster coverage")
    print("PASS open same-color wall draws 2 white spokes and an empty raster doorway")
    print("PASS open different-color wall draws no spokes and an empty raster doorway")
    print(f"PASS alpha-weighted perpendicular thickness is constant across actual shape angles: {thicknesses}")
    print("PASS endpoint/list reversal is exact and canonical wall cache remains bounded")
    print("RESULT 5/5 wall visual probe groups passed")


if __name__ == "__main__":
    main()
