import argparse
import math
import os
import sys
import time
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ.setdefault("SHAPE_AZOID_TELEMETRY", "0")

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import shape_azoid
import shape_azoid_core


ITERATIONS = 4000


def square(x, y=0.0, size=100.0):
    return [
        (float(x), float(y)),
        (float(x + size), float(y)),
        (float(x + size), float(y + size)),
        (float(x), float(y + size)),
    ]


def make_piece(points, owner=0):
    return {"shape": "square", "points": list(points), "owner": owner, "played_by": owner}


def make_ball(pos, vel=(0.0, 0.0), piece=0, kind="zoid", owner=0):
    return {
        "pos": [float(pos[0]), float(pos[1])],
        "vel": [float(vel[0]), float(vel[1])],
        "owner": owner,
        "played_by": owner,
        "piece": piece,
        "kind": kind,
        "visited": {piece} if isinstance(piece, int) and piece >= 0 else set(),
    }


def fresh_game(factory, piece_count=1):
    game = factory()
    game.pieces = [make_piece(square(index * 100.0), owner=index % 6) for index in range(piece_count)]
    game.zoids = []
    game.open_walls = set()
    return game


def measured_updates(module, factory, piece_count, iterations):
    game = fresh_game(factory, piece_count)
    game.zoids = [make_ball((50.0, 50.0))]

    original_piece_at = game.piece_at
    original_point_in_polygon = module.point_in_polygon
    piece_at_calls = 0
    piece_at_seconds = 0.0
    polygon_calls = 0

    def counted_piece_at(pos):
        nonlocal piece_at_calls, piece_at_seconds
        piece_at_calls += 1
        started = time.perf_counter()
        result = original_piece_at(pos)
        piece_at_seconds += time.perf_counter() - started
        return result

    def counted_point_in_polygon(point, polygon):
        nonlocal polygon_calls
        polygon_calls += 1
        return original_point_in_polygon(point, polygon)

    game.piece_at = counted_piece_at
    module.point_in_polygon = counted_point_in_polygon
    started = time.perf_counter()
    try:
        for _ in range(iterations):
            game.update_zoids()
    finally:
        elapsed = time.perf_counter() - started
        module.point_in_polygon = original_point_in_polygon

    return {
        "pieces": piece_count,
        "updates": iterations,
        "piece_at_calls": piece_at_calls,
        "polygon_calls": polygon_calls,
        "piece_at_ms": piece_at_seconds * 1000.0,
        "elapsed_ms": elapsed * 1000.0,
    }


def counted_transition(factory, setup):
    game = setup(factory)
    original_piece_at = game.piece_at
    calls = 0

    def counted_piece_at(pos):
        nonlocal calls
        calls += 1
        return original_piece_at(pos)

    game.piece_at = counted_piece_at
    game.update_zoids()
    return game, calls


def open_wall_setup(factory):
    game = fresh_game(factory, 2)
    shared_wall = next(key for key, entries in game.shared_edges().items() if len(entries) == 2)
    game.open_walls.add(shared_wall)
    game.zoids = [make_ball((99.0, 50.0), (2.9, 0.0))]
    return game


def stale_valid_setup(factory):
    game = fresh_game(factory, 2)
    game.zoids = [make_ball((50.0, 50.0), piece=1)]
    return game


def stale_invalid_setup(factory):
    game = fresh_game(factory, 2)
    game.zoids = [make_ball((50.0, 50.0), piece=99)]
    return game


def deletion_case(factory):
    game = fresh_game(factory, 3)
    ball = make_ball((250.0, 50.0), piece=2)
    game.zoids = [ball]
    removed = game.remove_piece(0)
    if removed is False:
        raise AssertionError("piece deletion unexpectedly failed")
    original_piece_at = game.piece_at
    calls = 0

    def counted_piece_at(pos):
        nonlocal calls
        calls += 1
        return original_piece_at(pos)

    game.piece_at = counted_piece_at
    game.update_zoids()
    return (tuple(ball["pos"]), ball.get("piece"), len(game.pieces), calls)


def penta_case(factory):
    game = fresh_game(factory)
    penta = make_ball((45.0, 50.0), kind="penta")
    normal = make_ball((60.0, 50.0), kind="zoid")
    game.zoids = [penta, normal]
    game.resolve_ball_collisions()
    first = tuple(zoid.get("kind") for zoid in game.zoids)

    game.zoids = [make_ball((45.0, 50.0), kind="penta"), make_ball((60.0, 50.0), kind="penta")]
    game.resolve_ball_collisions()
    return first, len(game.zoids)


def state(game, calls):
    ball = game.zoids[0]
    return (
        tuple(round(float(value), 6) for value in ball["pos"]),
        tuple(round(float(value), 6) for value in ball["vel"]),
        ball.get("piece"),
        calls,
    )


def run_semantics(label, factory):
    open_game, open_calls = counted_transition(factory, open_wall_setup)
    stale_valid_game, stale_valid_calls = counted_transition(factory, stale_valid_setup)
    stale_invalid_game, stale_invalid_calls = counted_transition(factory, stale_invalid_setup)
    result = {
        "open": state(open_game, open_calls),
        "stale_valid": state(stale_valid_game, stale_valid_calls),
        "stale_invalid": state(stale_invalid_game, stale_invalid_calls),
        "deletion": deletion_case(factory),
        "penta": penta_case(factory),
    }

    if result["open"][2] != 1 or result["open"][0][0] <= 100.0 or result["open"][3] < 1:
        raise AssertionError(f"{label}: open-wall transition failed: {result['open']}")
    for case in ("stale_valid", "stale_invalid"):
        if result[case][2] != 0 or result[case][3] != 1:
            raise AssertionError(f"{label}: {case} recovery failed: {result[case]}")
    if result["deletion"] != ((250.0, 50.0), 1, 2, 0):
        raise AssertionError(f"{label}: deletion reindexing failed: {result['deletion']}")
    if result["penta"] != (("penta",), 0):
        raise AssertionError(f"{label}: Penta interactions changed: {result['penta']}")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--measure-only", action="store_true")
    parser.add_argument("--iterations", type=int, default=ITERATIONS)
    args = parser.parse_args()

    measurements = {}
    for label, module, factory in (
        ("desktop", shape_azoid, shape_azoid.Game),
        ("core", shape_azoid_core, shape_azoid_core.ShapeAzoidMatch),
    ):
        measurements[label] = []
        for piece_count in (6, 18, 36):
            result = measured_updates(module, factory, piece_count, args.iterations)
            measurements[label].append(result)
            print(
                f"MEASURE {label} pieces={piece_count} updates={result['updates']} "
                f"piece_at_calls={result['piece_at_calls']} polygon_calls={result['polygon_calls']} "
                f"piece_at_ms={result['piece_at_ms']:.3f} elapsed_ms={result['elapsed_ms']:.3f}"
            )

    if args.measure_only:
        print("RESULT measurement only")
        return

    for label, results in measurements.items():
        for result in results:
            if result["piece_at_calls"] != 0:
                raise AssertionError(
                    f"{label}: cached same-piece motion used piece_at {result['piece_at_calls']} times"
                )
            maximum_polygon_calls = result["updates"] * 2
            if result["polygon_calls"] > maximum_polygon_calls:
                raise AssertionError(
                    f"{label}: same-piece polygon checks exceeded {maximum_polygon_calls}: "
                    f"{result['polygon_calls']}"
                )

    desktop = run_semantics("desktop", shape_azoid.Game)
    core = run_semantics("core", shape_azoid_core.ShapeAzoidMatch)
    if desktop != core:
        raise AssertionError(f"desktop/core lookup semantics differ: {desktop} != {core}")

    print("PASS same-piece updates avoid full-board piece_at scans")
    print("PASS open-wall, stale-cache, deletion, and Penta behavior")
    print("PASS desktop and core lookup traces match")
    print("RESULT 3/3 piece lookup probe groups passed")


if __name__ == "__main__":
    main()
