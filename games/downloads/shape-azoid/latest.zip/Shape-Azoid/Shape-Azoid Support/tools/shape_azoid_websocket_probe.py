import os
import sys
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


try:
    from fastapi.testclient import TestClient
except ImportError:
    print("SKIP FastAPI is not installed. Run: pip install -r requirements.txt")
    raise SystemExit(0)

from network.shape_azoid_server import app, service
from shape_azoid_core import BOARD_CENTER, make_card, centroid, dist


def main():
    service.rooms.clear()
    with TestClient(app) as client:
        response = client.post("/api/rooms", json={"host_name": "Jeremy", "player_count": 2, "ai_players": []})
        assert response.status_code == 200, response.text
        created = response.json()
        room_code = created["room_code"]
        host_token = created["host_seat_token"]

        with service.lock:
            game = service.rooms[room_code]["game"]
            game.hands[0] = [make_card("hex", 0)]
        response = client.post(
            f"/api/rooms/{room_code}/commands",
            json={"seat_token": host_token, "command": {"type": "play_at", "card_index": 0, "pos": BOARD_CENTER}},
        )
        assert response.status_code == 200, response.text

        with service.lock:
            game = service.rooms[room_code]["game"]
            ball_pos = centroid(game.pieces[0]["points"])
            game.hands[0] = [make_card("zoid", 0)]
        response = client.post(
            f"/api/rooms/{room_code}/commands",
            json={"seat_token": host_token, "command": {"type": "play_at", "card_index": 0, "pos": ball_pos}},
        )
        assert response.status_code == 200, response.text

        positions = []
        with client.websocket_connect(f"/ws/rooms/{room_code}?seat_token={host_token}") as websocket:
            for _ in range(8):
                payload = websocket.receive_json()
                assert payload["type"] == "room_snapshot", payload
                assert payload["phase"] == "playing", payload
                zoids = payload["state"]["zoids"]
                assert len(zoids) == 1, payload
                positions.append(tuple(zoids[0]["pos"]))
        moved = dist(positions[0], positions[-1])
        assert moved > 8.0, f"expected websocket motion, moved only {moved:.2f}px"
        print("PASS websocket stream emits moving zoid snapshots")

        with service.lock:
            game = service.rooms[room_code]["game"]
            game.next_ufo_at = game.now_ms() - 1
            game.active_ufo = None
            game.explosions = []

        active_ufo_seen = False
        with client.websocket_connect(f"/ws/rooms/{room_code}?seat_token={host_token}") as websocket:
            for _ in range(12):
                payload = websocket.receive_json()
                assert payload["type"] == "room_snapshot", payload
                if payload["state"].get("active_ufo"):
                    assert payload.get("server_time", 0) > 1000000, "server_time should be monotonic milliseconds"
                    event = payload["state"]["active_ufo"]
                    assert abs(float(event["started_at"]) - float(payload["server_time"])) < 10000, payload
                    active_ufo_seen = True
                    break
        assert active_ufo_seen, "expected live websocket stream to include active UFO state"
        print("PASS websocket stream emits active UFO snapshots")
        print("RESULT 2/2 websocket probes passed")


if __name__ == "__main__":
    main()
