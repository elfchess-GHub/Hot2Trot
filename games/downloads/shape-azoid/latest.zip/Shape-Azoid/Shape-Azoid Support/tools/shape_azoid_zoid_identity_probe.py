import copy
import math
import os
import sys
import tempfile
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ.setdefault("SHAPE_AZOID_TELEMETRY", "0")

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import shape_azoid
import shape_azoid_core
from network.shape_azoid_room_service import ShapeAzoidRoomService


SQUARE = [(0.0, 0.0), (120.0, 0.0), (120.0, 120.0), (0.0, 120.0)]


def piece(owner=0):
    return {"shape": "square", "points": list(SQUARE), "owner": owner, "played_by": owner}


def ball(zoid_id, pos, kind="zoid", owner=0, played_by=0):
    return {
        "zoid_id": zoid_id,
        "kind": kind,
        "owner": owner,
        "played_by": played_by,
        "piece": 0,
        "pos": [float(pos[0]), float(pos[1])],
        "vel": [0.0, 0.0],
        "visited": {0},
    }


def public_ball(zoid_id, pos, kind="zoid", owner=0, played_by=0):
    result = ball(zoid_id, pos, kind=kind, owner=owner, played_by=played_by)
    result["visited"] = [0]
    if zoid_id is None:
        result.pop("zoid_id")
    return result


def payload(zoids, next_zoid_id=1):
    return {
        "viewer_player": 0,
        "state": {
            "mode": "playing",
            "player_count": 1,
            "current_player": 0,
            "players": [
                {
                    "name": "Red",
                    "color_name": "Red",
                    "color_index": 0,
                    "is_ai": False,
                    "score_total": 0,
                    "score_round": 0,
                }
            ],
            "deck_count": 0,
            "discard": [],
            "hands": [[]],
            "pieces": [
                {
                    "shape": "square",
                    "points": [[x, y] for x, y in SQUARE],
                    "owner": 0,
                    "played_by": 0,
                }
            ],
            "zoids": zoids,
            "next_zoid_id": next_zoid_id,
            "open_walls": [],
            "round_slots": [],
            "round_wild_kind": None,
            "last_score_breakdown": [],
            "next_ufo_at": 0,
            "ufo_flight_index": 0,
            "active_ufo": None,
            "explosions": [],
            "cards_used_this_turn": 0,
            "last_card_drawn": False,
            "no_discard_turns_after_empty": 0,
            "action_log": [],
            "message": "Identity probe",
        },
    }


def assert_close(actual, expected, label):
    if not math.isclose(actual, expected, abs_tol=0.000001):
        raise AssertionError(f"{label}: {actual} != {expected}")


def creation_and_round_case():
    game = shape_azoid_core.ShapeAzoidMatch(player_count=1)
    game.pieces = [piece()]
    assert game.play_ball((30.0, 30.0), "zoid", 0)
    assert game.play_ball((90.0, 90.0), "penta", 0)
    ids = [z["zoid_id"] for z in game.zoids]
    assert ids == [1, 2]
    snapshot = game.state_snapshot(viewer_player=0)
    assert [z["zoid_id"] for z in snapshot["zoids"]] == ids
    assert snapshot["next_zoid_id"] == 3
    game.reset_round()
    assert not game.zoids
    assert game.next_zoid_id == 3
    game.pieces = [piece()]
    assert game.play_ball((60.0, 60.0), "zoid", 0)
    assert game.zoids[0]["zoid_id"] == 3


def deletion_and_reordering_case():
    game = shape_azoid.Game()
    game.apply_online_snapshot(
        payload(
            [
                public_ball(101, (20.0, 40.0)),
                public_ball(102, (72.0, 40.0)),
                public_ball(103, (105.0, 40.0)),
            ],
            next_zoid_id=104,
        )
    )
    game.apply_online_snapshot(
        payload(
            [
                public_ball(103, (103.0, 40.0)),
                public_ball(102, (74.0, 40.0)),
            ],
            next_zoid_id=104,
        )
    )
    by_id = {z["zoid_id"]: z for z in game.zoids}
    smoothing = shape_azoid.ONLINE_ZOID_SMOOTHING
    assert_close(by_id[102]["pos"][0], 72.0 + 2.0 * smoothing, "survivor interpolation")
    assert_close(by_id[103]["pos"][0], 105.0 - 2.0 * smoothing, "reordered interpolation")
    if by_id[102]["pos"][0] < 60.0:
        raise AssertionError("surviving Zoid inherited the deleted list entry's old position")

    game.apply_online_snapshot(
        payload(
            [
                public_ball(103, (101.0, 40.0)),
                public_ball(104, (30.0, 80.0)),
            ],
            next_zoid_id=105,
        )
    )
    new_by_id = {z["zoid_id"]: z for z in game.zoids}
    assert new_by_id[104]["pos"] == [30.0, 80.0]


def legacy_snapshot_case():
    game = shape_azoid.Game()
    game.apply_online_snapshot(payload([public_ball(None, (40.0, 40.0))]))
    game.apply_online_snapshot(payload([public_ball(None, (42.0, 40.0))]))
    expected = 40.0 + 2.0 * shape_azoid.ONLINE_ZOID_SMOOTHING
    assert_close(game.zoids[0]["pos"][0], expected, "legacy interpolation")
    assert game.zoids[0]["zoid_id"] is None


def save_load_and_backfill_case():
    with tempfile.TemporaryDirectory(prefix="shape_azoid_identity_") as temp_dir:
        service = ShapeAzoidRoomService(save_dir=temp_dir)
        created = service.create_room(host_name="Jeremy", player_count=1, ai_players=[])
        code = created["room_code"]
        game = service.rooms[code]["game"]
        game.pieces = [piece()]
        assert game.play_ball((30.0, 30.0), "zoid", 0)
        assert game.play_ball((90.0, 90.0), "penta", 0)
        original_ids = [z["zoid_id"] for z in game.zoids]
        original_next = game.next_zoid_id
        service.save_room(code)

        service.rooms.pop(code)
        loaded = service.load_room(code)
        restored = service.rooms[code]["game"]
        assert loaded["state"]["next_zoid_id"] == original_next
        assert [z["zoid_id"] for z in restored.zoids] == original_ids
        assert restored.next_zoid_id == original_next

        old_state = service.authoritative_game_state(restored)
        old_state.pop("next_zoid_id")
        for z in old_state["zoids"]:
            z.pop("zoid_id")
        old_state["zoids"].append(copy.deepcopy(old_state["zoids"][0]))
        backfilled = service.restore_game_state(old_state)
        backfilled_ids = [z["zoid_id"] for z in backfilled.zoids]
        assert len(backfilled_ids) == len(set(backfilled_ids))
        assert all(shape_azoid_core.ShapeAzoidMatch.valid_zoid_id(value) for value in backfilled_ids)
        assert backfilled.next_zoid_id > max(backfilled_ids)


def penta_removal_case():
    game = shape_azoid_core.ShapeAzoidMatch(player_count=2)
    game.pieces = [piece()]
    game.zoids = [
        ball(11, (30.0, 30.0), kind="zoid", owner=0),
        ball(12, (30.0, 30.0), kind="penta", owner=1, played_by=1),
        ball(13, (95.0, 95.0), kind="zoid", owner=0),
    ]
    game.next_zoid_id = 14
    game.resolve_ball_collisions()
    assert [z["zoid_id"] for z in game.zoids] == [12, 13]

    game.zoids = [
        ball(21, (30.0, 30.0), kind="penta", owner=0),
        ball(22, (30.0, 30.0), kind="penta", owner=1, played_by=1),
        ball(23, (95.0, 95.0), kind="zoid", owner=0),
    ]
    game.next_zoid_id = 24
    game.resolve_ball_collisions()
    assert [z["zoid_id"] for z in game.zoids] == [23]


def desktop_core_protocol_case():
    core = shape_azoid_core.ShapeAzoidMatch(player_count=1)
    core.start()
    core.pieces = [piece()]
    assert core.play_ball((50.0, 50.0), "zoid", 0)
    snapshot = core.state_snapshot(viewer_player=0)
    desktop = shape_azoid.Game()
    desktop.apply_online_snapshot({"viewer_player": 0, "state": snapshot})
    assert [z["zoid_id"] for z in desktop.zoids] == [core.zoids[0]["zoid_id"]]
    assert desktop.next_zoid_id == core.next_zoid_id

    local = shape_azoid.Game()
    local.pieces = [piece()]
    assert local.play_ball((50.0, 50.0), "zoid", 0)
    local_snapshot = local.state_snapshot(viewer_player=0)
    assert local_snapshot["zoids"][0]["zoid_id"] == local.zoids[0]["zoid_id"]
    assert local_snapshot["next_zoid_id"] == local.next_zoid_id


def main():
    cases = [
        ("authoritative creation, uniqueness, and round continuity", creation_and_round_case),
        ("deletion and reordering do not cause false interpolation jumps", deletion_and_reordering_case),
        ("legacy snapshots keep conservative index fallback", legacy_snapshot_case),
        ("room save/load and old-save backfill preserve unique IDs", save_load_and_backfill_case),
        ("Penta removals preserve survivor identities", penta_removal_case),
        ("desktop and core snapshot protocol remains compatible", desktop_core_protocol_case),
    ]
    for label, case in cases:
        case()
        print(f"PASS {label}")
    print(f"RESULT {len(cases)}/{len(cases)} Zoid identity probes passed")


if __name__ == "__main__":
    main()
