@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Show_Shape_Azoid_Home_Network_Info.ps1"
pause
