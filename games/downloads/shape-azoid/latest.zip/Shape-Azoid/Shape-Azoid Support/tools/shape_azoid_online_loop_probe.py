from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "shape_azoid.py"


def extract_branch(source, marker):
    start = source.index(marker)
    next_branch = source.index("\n        else:", start)
    return source[start:next_branch]


def main():
    source = SOURCE.read_text(encoding="utf-8")
    branch = extract_branch(source, 'elif GAME.mode == "online_playing":')
    if "GAME.update_zoids()" in branch:
        raise SystemExit("FAIL online_playing branch still runs local zoid physics")
    if "GAME.consume_online_stream()" not in branch:
        raise SystemExit("FAIL online_playing branch no longer consumes online stream")
    print("PASS online play loop uses server snapshots without local zoid physics")
    print("RESULT 1/1 online loop probes passed")


if __name__ == "__main__":
    main()
