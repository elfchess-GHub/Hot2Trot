import os
import sys
import tempfile
import time
import json
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import shape_azoid


class ProbeFailure(RuntimeError):
    pass


def main():
    temp_dir = tempfile.TemporaryDirectory()
    env = {
        **dict(os.environ),
        "SHAPE_AZOID_ROOM_SAVE_DIR": temp_dir.name,
    }
    os.environ["SHAPE_AZOID_ROOM_SAVE_DIR"] = temp_dir.name
    passed = []

    def record(name):
        passed.append(name)
        print(f"PASS {name}")

    try:
        shape_azoid.GAME.online_server_url = ""
        shape_azoid.GAME.online_server_input = ""
        shape_azoid.GAME.online_player_name = "Jeremy"
        shape_azoid.GAME.open_online()
        assert shape_azoid.GAME.mode == "online"
        record("open_online")

        shape_azoid.GAME.create_online_room()
        assert shape_azoid.GAME.online_room_code
        assert shape_azoid.GAME.online_seat_token
        assert shape_azoid.GAME.online_lobby["phase"] == "lobby"
        record("create_room")

        shape_azoid.GAME.cycle_online_seat_color()
        assert shape_azoid.GAME.online_lobby["seats"][0]["color_name"] == "Orange"
        record("cycle_lobby_color")

        shape_azoid.GAME.refresh_online_rooms()
        assert any(room["room_code"] == shape_azoid.GAME.online_room_code for room in shape_azoid.GAME.online_rooms)
        record("list_rooms")

        shape_azoid.GAME.start_online_room()
        assert shape_azoid.GAME.online_lobby["phase"] == "playing"
        assert shape_azoid.GAME.mode == "online_playing"
        record("host_start")

        shape_azoid.GAME.start_online_stream()
        deadline = time.time() + 5.0
        while time.time() < deadline:
            if shape_azoid.GAME.consume_online_stream():
                break
            time.sleep(0.05)
        assert shape_azoid.GAME.online_ws_last_frame_ms > 0
        assert shape_azoid.GAME.online_stream_healthy()
        record("client_websocket_stream")

        score_payload = json.loads(json.dumps(shape_azoid.GAME.online_lobby))
        score_payload["state"]["mode"] = "score"
        score_payload["state"]["last_score_breakdown"] = [
            {"placed": 1, "color": 2, "zoid": 0, "penta": 0, "lights": 0},
            {"placed": 0, "color": 0, "zoid": 0, "penta": 0, "lights": 0},
            {"placed": 0, "color": 0, "zoid": 0, "penta": 0, "lights": 0},
        ]
        shape_azoid.GAME.apply_online_snapshot(score_payload)
        shape_azoid.GAME.apply_online_mode(score_payload)
        assert shape_azoid.GAME.mode == "score"
        assert shape_azoid.GAME.last_score_breakdown[0]["color"] == 2
        record("online_score_snapshot_mode")

        shape_azoid.GAME.refresh_online_game()
        assert shape_azoid.GAME.mode == "online_playing"
        record("online_score_returns_to_playing")

        shape_azoid.draw_playing()
        record("draw_online_board")

        ufo_payload = json.loads(json.dumps(shape_azoid.GAME.online_lobby))
        server_time = time.monotonic()
        ufo_payload["server_time"] = server_time
        ufo_payload["state"]["active_ufo"] = {
            "start": [-shape_azoid.UFO_DRAW_W, 220],
            "end": [shape_azoid.WIDTH + shape_azoid.UFO_DRAW_W, 220],
            "started_at": server_time - 0.5,
            "ends_at": server_time + 3.8,
            "shot_at": server_time + 0.8,
            "hit_at": server_time + 2.4,
            "target_idx": 0,
            "target_pos": [shape_azoid.BOARD_RECT.centerx, shape_azoid.BOARD_RECT.centery],
            "hit_done": False,
            "left_to_right": True,
        }
        ufo_payload["state"]["next_ufo_at"] = 0
        ufo_payload["state"]["explosions"] = [
            {
                "pos": [shape_azoid.BOARD_RECT.centerx, shape_azoid.BOARD_RECT.centery],
                "started_at": server_time - 0.2,
                "duration": 760,
            }
        ]
        shape_azoid.GAME.apply_online_snapshot(ufo_payload)
        assert shape_azoid.GAME.active_ufo is not None
        assert shape_azoid.GAME.active_ufo["started_at"] <= shape_azoid.pygame.time.get_ticks() <= shape_azoid.GAME.active_ufo["ends_at"]
        assert len(shape_azoid.GAME.explosions) == 1
        old_ufo_image = shape_azoid.ufo_image
        old_ellipse = shape_azoid.pygame.draw.ellipse
        ellipse_calls = []
        shape_azoid.ufo_image = lambda: None

        def record_ellipse(surface, color, rect, width=0):
            ellipse_calls.append((color, rect, width))
            return old_ellipse(surface, color, rect, width)

        try:
            shape_azoid.pygame.draw.ellipse = record_ellipse
            shape_azoid.draw_playing()
        finally:
            shape_azoid.pygame.draw.ellipse = old_ellipse
            shape_azoid.ufo_image = old_ufo_image
        assert ellipse_calls, "online active UFO was not drawn"
        record("online_ufo_snapshot_draws")

        shape_azoid.GAME.selected_card = 0
        shape_azoid.GAME.refresh_online_game()
        assert shape_azoid.GAME.selected_card == 0
        record("refresh_preserves_selected_card")

        shape_azoid.GAME.selected_card = 0
        shape_azoid.GAME.send_online_command({"type": "discard", "card_index": 0})
        assert shape_azoid.GAME.state_revision == 1
        assert shape_azoid.GAME.action_log[-1]["type"] == "discard"
        assert shape_azoid.GAME.selected_card is None
        record("send_online_command")

        print(f"RESULT {len(passed)}/{len(passed)} online UI probes passed")
    finally:
        shape_azoid.GAME.stop_online_stream()
        if shape_azoid.GAME.online_server_process is not None:
            shape_azoid.GAME.online_server_process.terminate()
            try:
                shape_azoid.GAME.online_server_process.wait(timeout=8)
            except Exception:
                shape_azoid.GAME.online_server_process.kill()
                shape_azoid.GAME.online_server_process.wait(timeout=8)
        temp_dir.cleanup()


if __name__ == "__main__":
    main()
