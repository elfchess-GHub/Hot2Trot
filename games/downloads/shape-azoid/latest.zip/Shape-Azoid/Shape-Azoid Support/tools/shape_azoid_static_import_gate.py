from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ROOM_SERVICE = ROOT / "network" / "shape_azoid_room_service.py"

FORBIDDEN_IMPORTS = [
    "from shape_azoid import",
    "import shape_azoid",
    'import_module("shape_azoid")',
    "import_module('shape_azoid')",
]


def main():
    text = ROOM_SERVICE.read_text(encoding="utf-8")
    failures = [
        forbidden
        for forbidden in FORBIDDEN_IMPORTS
        if forbidden in text
    ]
    if failures:
        print("FAIL: network/shape_azoid_room_service.py still imports the desktop Pygame module.")
        for failure in failures:
            print(f"  found: {failure}")
        print("Expected final state: import shape_azoid_core / shape_azoid_actions only.")
        return 1
    print("OK: room service does not import the desktop Pygame module.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
