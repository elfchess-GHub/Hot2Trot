import os
import sys
import time
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ.setdefault("SHAPE_AZOID_TELEMETRY", "0")

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pygame
import shape_azoid


PARENT_BASELINE_SECONDS = 15.490


def old_prepare_character_image(image):
    surf = image.convert_alpha()
    w, h = surf.get_size()
    pixels = pygame.PixelArray(surf)
    seen = set()
    stack = []
    for x in range(w):
        stack.append((x, 0))
        stack.append((x, h - 1))
    for y in range(h):
        stack.append((0, y))
        stack.append((w - 1, y))

    while stack:
        x, y = stack.pop()
        if (x, y) in seen or not (0 <= x < w and 0 <= y < h):
            continue
        seen.add((x, y))
        color = surf.unmap_rgb(pixels[x, y])
        if not shape_azoid.is_checker_background(color):
            continue
        pixels[x, y] = (color.r, color.g, color.b, 0)
        stack.extend(((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)))

    del pixels

    mask = pygame.mask.from_surface(surf)
    component = mask.connected_component()
    if component.count() > 0:
        component_surface = component.to_surface(
            setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 0)
        ).convert_alpha()
        surf.blit(component_surface, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)

    bounds = surf.get_bounding_rect()
    if bounds.width <= 0 or bounds.height <= 0:
        return surf
    return surf.subsurface(bounds).copy()


def first_image(folder):
    paths = sorted(
        path
        for path in folder.iterdir()
        if path.suffix.lower() in (".png", ".webp", ".jpg", ".jpeg")
    )
    if not paths:
        raise AssertionError(f"no image found in {folder}")
    return paths[0]


def representative_cases():
    cases = [("base/red", Path(shape_azoid.ART_DIR) / "red.png", False)]
    for action, (folder_name, _) in shape_azoid.ACTION_IMAGE_FOLDERS.items():
        cases.append(
            (f"action/{action}", first_image(Path(shape_azoid.ART_DIR) / folder_name), True)
        )
    ufo_folder = Path(shape_azoid.ART_DIR) / "UFO"
    ufo_path = ufo_folder / "ufo_transparent.png"
    if not ufo_path.exists():
        ufo_path = first_image(ufo_folder)
    cases.append(("UFO", ufo_path, False))
    return cases


def load_for_game_path(path, action):
    image = pygame.image.load(path)
    if not action:
        return image
    image = image.convert_alpha()
    max_h = 420
    if image.get_height() > max_h:
        scale = max_h / image.get_height()
        size = (max(1, int(image.get_width() * scale)), max_h)
        image = pygame.transform.scale(image, size)
    return image


def equality_and_benchmark_probe():
    old_seconds = 0.0
    new_seconds = 0.0
    cases = representative_cases()
    for label, path, action in cases:
        image = load_for_game_path(path, action)

        started = time.perf_counter()
        old_output = old_prepare_character_image(image)
        old_elapsed = time.perf_counter() - started

        started = time.perf_counter()
        new_output = shape_azoid.prepare_character_image(image)
        new_elapsed = time.perf_counter() - started

        if old_output.get_size() != new_output.get_size():
            raise AssertionError(
                f"{label} dimensions differ: old={old_output.get_size()} new={new_output.get_size()}"
            )
        old_bytes = pygame.image.tobytes(old_output, "RGBA")
        new_bytes = pygame.image.tobytes(new_output, "RGBA")
        if old_bytes != new_bytes:
            raise AssertionError(f"{label} RGBA bytes differ")

        old_seconds += old_elapsed
        new_seconds += new_elapsed
        print(
            f"PASS {label}: {new_output.get_size()[0]}x{new_output.get_size()[1]}, "
            f"old={old_elapsed:.3f}s new={new_elapsed:.3f}s"
        )

    if new_seconds >= old_seconds * 0.75:
        raise AssertionError(
            f"representative preprocessing was not materially faster: "
            f"old={old_seconds:.3f}s new={new_seconds:.3f}s"
        )
    print(
        f"PASS {len(cases)} representative outputs are byte-identical; "
        f"old={old_seconds:.3f}s new={new_seconds:.3f}s "
        f"speedup={old_seconds / new_seconds:.2f}x"
    )


def actual_full_preload_probe():
    shape_azoid.CHARACTER_IMAGES.clear()
    shape_azoid.ACTION_CHARACTER_IMAGES.clear()
    shape_azoid.UFO_IMAGE = None

    started = time.perf_counter()
    shape_azoid.load_character_images()
    shape_azoid.load_action_character_images()
    shape_azoid.ufo_image()
    elapsed = time.perf_counter() - started

    base_count = len(shape_azoid.CHARACTER_IMAGES)
    action_count = sum(len(images) for images in shape_azoid.ACTION_CHARACTER_IMAGES.values())
    ufo_count = int(shape_azoid.UFO_IMAGE is not None)
    if (base_count, action_count, ufo_count) != (6, 30, 1):
        raise AssertionError(
            f"full preload counts differ: base={base_count} action={action_count} UFO={ufo_count}"
        )
    if elapsed >= PARENT_BASELINE_SECONDS * 0.75:
        raise AssertionError(
            f"full preload was not materially below the {PARENT_BASELINE_SECONDS:.3f}s baseline: "
            f"new={elapsed:.3f}s"
        )
    print(
        f"PASS actual full preload 6 base + 30 action + UFO: "
        f"baseline={PARENT_BASELINE_SECONDS:.3f}s new={elapsed:.3f}s "
        f"speedup={PARENT_BASELINE_SECONDS / elapsed:.2f}x"
    )


def main():
    equality_and_benchmark_probe()
    actual_full_preload_probe()
    print("RESULT 2/2 image preprocessing probe groups passed")


if __name__ == "__main__":
    main()
