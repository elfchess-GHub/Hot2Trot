from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "shape_azoid.py"


def main():
    source = SOURCE.read_text(encoding="utf-8")
    start = source.index("def draw_playing():")
    end = source.index("\n\ndef draw_score_screen():", start)
    body = source[start:end]
    checks = ["draw_board()", "draw_sidebar()", "draw_top_status()", "draw_gear_button(GAME.gear_rect)", "draw_ufo_event()"]
    positions = [body.index(check) for check in checks]
    if positions != sorted(positions):
        raise SystemExit("FAIL draw_playing should draw UFO after board and UI")
    print("PASS UFO draw order is above play UI")
    print("RESULT 1/1 draw order probes passed")


if __name__ == "__main__":
    main()
