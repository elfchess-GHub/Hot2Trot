import math
import os
import sys
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ.setdefault("SHAPE_AZOID_TELEMETRY", "0")

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import shape_azoid
import shape_azoid_core


SQUARE_LEFT = [(0.0, 0.0), (100.0, 0.0), (100.0, 100.0), (0.0, 100.0)]
SQUARE_RIGHT = [(100.0, 0.0), (200.0, 0.0), (200.0, 100.0), (100.0, 100.0)]
CLEARANCE_ASSERT_TOLERANCE = 0.00002


def fresh_game(factory, two_squares=False):
    game = factory()
    game.pieces = [
        {"shape": "square", "points": list(SQUARE_LEFT), "owner": 0, "played_by": 0},
    ]
    if two_squares:
        game.pieces.append(
            {"shape": "square", "points": list(SQUARE_RIGHT), "owner": 1, "played_by": 1}
        )
    game.zoids = []
    game.open_walls = set()
    return game


def add_ball(game, pos, vel, kind="zoid", owner=0):
    game.zoids = [{
        "pos": [float(pos[0]), float(pos[1])],
        "vel": [float(vel[0]), float(vel[1])],
        "owner": owner,
        "played_by": 0,
        "piece": 0,
        "kind": kind,
        "visited": {0},
    }]
    return game.zoids[0]


def replace_polygon(game, shape, points):
    game.pieces = [
        {"shape": shape, "points": list(points), "owner": 0, "played_by": 0},
    ]
    game.zoids = []
    game.open_walls = set()


def state(ball):
    return tuple(round(value, 6) for value in (*ball["pos"], *ball["vel"])) + (ball["piece"],)


def assert_state_close(label, left, right):
    if left[-1] != right[-1]:
        raise AssertionError(f"{label}: piece mismatch {left[-1]} != {right[-1]}")
    for index, (left_value, right_value) in enumerate(zip(left[:-1], right[:-1])):
        if not math.isclose(left_value, right_value, abs_tol=0.000001):
            raise AssertionError(f"{label}: value {index} mismatch {left_value} != {right_value}")


def closed_wall_case(module, factory, kind="zoid"):
    game = fresh_game(factory, two_squares=True)
    radius = module.PENTA_ZOID_RADIUS if kind == "penta" else module.ZOID_RADIUS
    speed = 2.55 if kind == "penta" else 2.9
    start_x = 100.0 - radius - 1.0
    ball = add_ball(game, (start_x, 50.0), (speed, 0.0), kind=kind)
    game.update_zoids()
    if ball["vel"][0] >= 0:
        raise AssertionError(f"{kind} did not bounce from the closed shared wall: {state(ball)}")
    if ball["pos"][0] + radius > 100.000001:
        raise AssertionError(f"{kind} visible radius crossed the closed wall: {state(ball)}")
    return state(ball)


def corner_case(module, factory):
    game = fresh_game(factory)
    radius = module.ZOID_RADIUS
    ball = add_ball(game, (radius + 1.0, radius + 1.0), (-2.9, -2.9))
    game.update_zoids()
    if ball["vel"][0] <= 0 or ball["vel"][1] <= 0:
        raise AssertionError(f"corner did not resolve both velocity components in one update: {state(ball)}")
    if ball["pos"][0] < radius or ball["pos"][1] < radius:
        raise AssertionError(f"corner correction left the visible ball through a wall: {state(ball)}")
    assert_corner_velocity_non_outward(module, SQUARE_LEFT, 0, ball)
    return state(ball)


def unequal_square_corner_case(module, factory):
    game = fresh_game(factory)
    radius = module.ZOID_RADIUS
    ball = add_ball(game, (radius + 1.0, radius + 0.4), (-3.0, -1.0))
    game.update_zoids()
    if not math.isclose(ball["vel"][0], 3.0, abs_tol=0.000001):
        raise AssertionError(f"unequal square corner changed x magnitude: {state(ball)}")
    if not math.isclose(ball["vel"][1], 1.0, abs_tol=0.000001):
        raise AssertionError(f"unequal square corner changed y magnitude: {state(ball)}")
    assert_wall_clearance(module, game, ball)
    assert_corner_velocity_non_outward(module, SQUARE_LEFT, 0, ball)
    return state(ball)


def assert_corner_velocity_non_outward(module, points, vertex_index, ball):
    center = module.centroid(points)
    vertex = points[vertex_index]
    incident_edges = (
        (points[(vertex_index - 1) % len(points)], vertex),
        (vertex, points[(vertex_index + 1) % len(points)]),
    )
    for a, b in incident_edges:
        nx, ny = module.inward_edge_normal(a, b, center)
        inward_speed = ball["vel"][0] * nx + ball["vel"][1] * ny
        if inward_speed < -CLEARANCE_ASSERT_TOLERANCE:
            raise AssertionError(
                f"corner response still points outward through contacted edge: {state(ball)}"
            )


def assert_wall_clearance(module, game, ball):
    radius = module.PENTA_ZOID_RADIUS if ball.get("kind") == "penta" else module.ZOID_RADIUS
    target = radius + module.WALL_COLLISION_MARGIN
    piece = game.pieces[ball["piece"]]
    center = module.centroid(piece["points"])
    minimum = float("inf")
    for a, b in module.side_list(piece["points"]):
        if module.edge_key(a, b) in game.open_walls:
            continue
        nx, ny = module.inward_edge_normal(a, b, center)
        mx, my = module.midpoint(a, b)
        clearance = (ball["pos"][0] - mx) * nx + (ball["pos"][1] - my) * ny
        minimum = min(minimum, clearance)
        if clearance < target - CLEARANCE_ASSERT_TOLERANCE:
            raise AssertionError(
                f"{piece['shape']} {ball['kind']} clearance {clearance:.8f} is below {target:.8f}: {state(ball)}"
            )
    return minimum


def inset_corner_point(module, points, vertex_index, radius):
    center = module.centroid(points)
    vertex = points[vertex_index]
    previous = points[(vertex_index - 1) % len(points)]
    following = points[(vertex_index + 1) % len(points)]
    edges = ((previous, vertex), (vertex, following))
    target = radius + module.WALL_COLLISION_MARGIN
    equations = []
    for a, b in edges:
        nx, ny = module.inward_edge_normal(a, b, center)
        mx, my = module.midpoint(a, b)
        equations.append((nx, ny, target + mx * nx + my * ny))
    n1x, n1y, c1 = equations[0]
    n2x, n2y, c2 = equations[1]
    determinant = n1x * n2y - n1y * n2x
    if abs(determinant) < 0.000001:
        raise AssertionError("corner offset lines are parallel")
    return (
        (c1 * n2y - n1y * c2) / determinant,
        (n1x * c2 - c1 * n2x) / determinant,
    )


def polygon_corner_case(module, factory, sides, kind, point_rotation=0):
    shape = {3: "triangle", 6: "hex"}[sides]
    base_points = module.regular_polygon((100.0, 100.0), 60.0, sides, -math.pi / 2)
    target_vertex = base_points[0]
    point_rotation %= sides
    points = base_points[point_rotation:] + base_points[:point_rotation]
    vertex_index = points.index(target_vertex)
    game = fresh_game(factory)
    replace_polygon(game, shape, points)
    radius = module.PENTA_ZOID_RADIUS if kind == "penta" else module.ZOID_RADIUS
    speed = 2.55 if kind == "penta" else 2.9
    inset = inset_corner_point(module, points, vertex_index, radius)
    center = module.centroid(points)
    inward_x = center[0] - inset[0]
    inward_y = center[1] - inset[1]
    inward_length = math.hypot(inward_x, inward_y)
    inward = (inward_x / inward_length, inward_y / inward_length)
    start = (inset[0] + inward[0] * 0.75, inset[1] + inward[1] * 0.75)
    velocity = (-inward[0] * speed, -inward[1] * speed)
    ball = add_ball(game, start, velocity, kind=kind)
    game.update_zoids()
    assert_wall_clearance(module, game, ball)
    assert_corner_velocity_non_outward(module, points, vertex_index, ball)
    if not math.isclose(math.hypot(*ball["vel"]), speed, abs_tol=0.000001):
        raise AssertionError(f"{shape} {kind} corner changed ball speed: {state(ball)}")
    return state(ball)


def polygon_rotation_case(module, factory, sides, kind):
    results = [
        polygon_corner_case(module, factory, sides, kind, point_rotation=rotation)
        for rotation in range(sides)
    ]
    baseline_state = results[0][:4]
    for rotation, result in enumerate(results[1:], start=1):
        for actual, expected in zip(result[:4], baseline_state):
            if not math.isclose(actual, expected, abs_tol=0.000001):
                shape = {3: "triangle", 6: "hex"}[sides]
                raise AssertionError(
                    f"{shape} {kind} point-list rotation {rotation} changed position/velocity: "
                    f"{result[:4]} != {baseline_state}"
                )
    return results[0]


def velocity_for_normal_dots(first_normal, second_normal, first_dot, second_dot):
    n1x, n1y = first_normal
    n2x, n2y = second_normal
    determinant = n1x * n2y - n1y * n2x
    if abs(determinant) < 0.000001:
        raise AssertionError("wedge normals are parallel")
    return (
        (first_dot * n2y - n1y * second_dot) / determinant,
        (n1x * second_dot - first_dot * n2x) / determinant,
    )


def wedge_transfer_case(module, factory, kind="zoid"):
    points = module.regular_polygon((100.0, 100.0), 60.0, 3, -math.pi / 2)
    game = fresh_game(factory)
    replace_polygon(game, "triangle", points)
    radius = module.PENTA_ZOID_RADIUS if kind == "penta" else module.ZOID_RADIUS
    center = module.centroid(points)
    vertex = points[0]
    incident_edges = ((points[-1], vertex), (vertex, points[1]))
    normals = [module.inward_edge_normal(a, b, center) for a, b in incident_edges]
    velocity = velocity_for_normal_dots(normals[0], normals[1], -3.0, 1.5)
    incoming_dots = [velocity[0] * nx + velocity[1] * ny for nx, ny in normals]
    if not math.isclose(incoming_dots[0], -3.0, abs_tol=0.000001):
        raise AssertionError(f"wedge first incoming dot drifted: {incoming_dots}")
    if not math.isclose(incoming_dots[1], 1.5, abs_tol=0.000001):
        raise AssertionError(f"wedge second incoming dot drifted: {incoming_dots}")

    start = inset_corner_point(module, points, 0, radius)
    ball = add_ball(game, start, velocity, kind=kind)
    original_speed = math.hypot(*velocity)
    game.update_zoids()
    assert_wall_clearance(module, game, ball)
    first_velocity = tuple(ball["vel"])
    first_state = state(ball)
    for nx, ny in normals:
        if first_velocity[0] * nx + first_velocity[1] * ny < -CLEARANCE_ASSERT_TOLERANCE:
            raise AssertionError(f"wedge response transferred violation to another wall: {first_state}")
    if not math.isclose(math.hypot(*first_velocity), original_speed, abs_tol=0.000001):
        raise AssertionError(f"wedge response changed speed: {first_state}")

    game.update_zoids()
    assert_wall_clearance(module, game, ball)
    second_velocity = tuple(ball["vel"])
    for actual, expected in zip(second_velocity, first_velocity):
        if not math.isclose(actual, expected, abs_tol=0.000001):
            raise AssertionError(
                f"wedge velocity changed on the second update: {second_velocity} != {first_velocity}"
            )
    return first_state


def open_wall_case(module, factory):
    game = fresh_game(factory, two_squares=True)
    shared_wall = next(key for key, entries in game.shared_edges().items() if len(entries) == 2)
    game.open_walls.add(shared_wall)
    ball = add_ball(game, (99.0, 50.0), (2.9, 0.0))
    game.update_zoids()
    if ball["piece"] != 1 or ball["pos"][0] <= 100.0 or ball["vel"][0] <= 0:
        raise AssertionError(f"ball did not traverse the opened shared wall: {state(ball)}")
    return state(ball)


def eager_lookup_case(factory):
    game = fresh_game(factory)
    add_ball(game, (50.0, 50.0), (0.0, 0.0))
    original_piece_at = game.piece_at
    calls = 0

    def counted_piece_at(pos):
        nonlocal calls
        calls += 1
        return original_piece_at(pos)

    game.piece_at = counted_piece_at
    game.update_zoids()
    if calls != 0:
        raise AssertionError(f"cached ball piece triggered {calls} piece_at calls; expected none")
    return calls


def stale_piece_case(factory):
    game = fresh_game(factory)
    ball = add_ball(game, (50.0, 50.0), (0.0, 0.0))
    ball["piece"] = 99
    game.update_zoids()
    if ball["piece"] != 0:
        raise AssertionError(f"invalid cached piece was not recovered from position: {state(ball)}")
    return state(ball)


def penta_collision_case(factory):
    game = fresh_game(factory)
    penta = add_ball(game, (45.0, 50.0), (0.0, 0.0), kind="penta")
    zoid = {
        "pos": [60.0, 50.0],
        "vel": [0.0, 0.0],
        "owner": 0,
        "played_by": 0,
        "piece": 0,
        "kind": "zoid",
        "visited": {0},
    }
    game.zoids = [penta, zoid]
    game.resolve_ball_collisions()
    if len(game.zoids) != 1 or game.zoids[0].get("kind") != "penta":
        raise AssertionError("Penta-Zoid no longer eats a touching normal Zoid")

    first = dict(penta, pos=[45.0, 50.0])
    second = dict(penta, pos=[60.0, 50.0])
    game.zoids = [first, second]
    game.resolve_ball_collisions()
    if game.zoids:
        raise AssertionError("two touching Penta-Zoids no longer remove each other")


def run_engine(label, module, factory):
    results = {
        "closed_zoid": closed_wall_case(module, factory),
        "closed_penta": closed_wall_case(module, factory, kind="penta"),
        "corner": corner_case(module, factory),
        "unequal_square_corner": unequal_square_corner_case(module, factory),
        "triangle_zoid_corner": polygon_rotation_case(module, factory, 3, "zoid"),
        "triangle_penta_corner": polygon_rotation_case(module, factory, 3, "penta"),
        "hex_zoid_corner": polygon_rotation_case(module, factory, 6, "zoid"),
        "hex_penta_corner": polygon_rotation_case(module, factory, 6, "penta"),
        "wedge_zoid": wedge_transfer_case(module, factory, "zoid"),
        "wedge_penta": wedge_transfer_case(module, factory, "penta"),
        "open_wall": open_wall_case(module, factory),
        "stale_piece": stale_piece_case(factory),
        "piece_at_calls": eager_lookup_case(factory),
    }
    penta_collision_case(factory)
    print(f"PASS {label} square radius and equal/unequal corner cases")
    print(f"PASS {label} triangle/hex normal and Penta corner clearance/rotation cases")
    print(f"PASS {label} wedge stability and non-outward velocity cases")
    print(f"PASS {label} open-wall, stale-piece, Penta-contact, and eager-lookup cases")
    return results


def main():
    desktop = run_engine("desktop", shape_azoid, shape_azoid.Game)
    core = run_engine("core", shape_azoid_core, shape_azoid_core.ShapeAzoidMatch)
    state_cases = (
        "closed_zoid",
        "closed_penta",
        "corner",
        "unequal_square_corner",
        "triangle_zoid_corner",
        "triangle_penta_corner",
        "hex_zoid_corner",
        "hex_penta_corner",
        "wedge_zoid",
        "wedge_penta",
        "open_wall",
        "stale_piece",
    )
    for case in state_cases:
        assert_state_close(f"desktop/core {case}", desktop[case], core[case])
    if desktop["piece_at_calls"] != core["piece_at_calls"]:
        raise AssertionError("desktop/core eager-lookup call counts differ")
    print("PASS desktop and core collision traces match")
    print("RESULT 9/9 wall collision probe groups passed")


if __name__ == "__main__":
    main()
