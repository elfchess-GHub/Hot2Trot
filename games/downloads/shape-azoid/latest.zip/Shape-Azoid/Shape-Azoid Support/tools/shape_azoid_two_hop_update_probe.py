#!/usr/bin/env python3
"""Exercise the exact public v0.7.32 updater through bridge and release updates."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import tempfile
import zipfile
from pathlib import Path


OLD_RENAMED_TRACKS = (
    "SadRocket Theremin Hiss (1).mp3",
    "ARocket Tire Swing.mp3",
)
NEW_RENAMED_TRACKS = (
    "BeASadRocket Theremin Hiss (1).mp3",
    "A2Rocket Tire Swing.mp3",
)
RELEASE_URL = (
    "https://github.com/elfchess-GHub/Hot2Trot/releases/download/"
    "shape-azoid-v0.7.33/Shape-Azoid-v0.7.33.zip"
)


def ps_literal(value: object) -> str:
    return str(value).replace("'", "''")


def package_build_id(package: Path) -> str:
    with zipfile.ZipFile(package) as archive:
        return archive.read("Shape-Azoid/BUILD_ID.txt").decode("ascii").strip()


def run_updater(updater: Path, package: Path, response_text: str) -> str:
    command = f"""
function Invoke-WebRequest {{
    param([string]$Uri, [string]$OutFile, [switch]$UseBasicParsing, [int]$TimeoutSec)
    if ($OutFile) {{
        Copy-Item -LiteralPath '{ps_literal(package)}' -Destination $OutFile -Force
        return
    }}
    [pscustomobject]@{{ Content = '{ps_literal(response_text)}' }}
}}
& '{ps_literal(updater)}'
"""
    result = subprocess.run(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
        capture_output=True,
        text=True,
        timeout=300,
    )
    output = result.stdout + result.stderr
    assert result.returncode == 0, output
    assert "Shape-Azoid update complete." in output, output
    return output


def safe_extract(package: Path, destination: Path) -> None:
    with zipfile.ZipFile(package) as archive:
        names = [info.filename for info in archive.infolist()]
        assert all(
            name == "Shape-Azoid/" or name.startswith("Shape-Azoid/")
            for name in names
        )
        assert not any(".." in Path(name).parts for name in names)
        archive.extractall(destination)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--legacy-zip", required=True, type=Path)
    parser.add_argument("--bridge-zip", required=True, type=Path)
    parser.add_argument("--release-zip", required=True, type=Path)
    args = parser.parse_args()

    legacy_zip = args.legacy_zip.resolve()
    bridge_zip = args.bridge_zip.resolve()
    release_zip = args.release_zip.resolve()
    legacy_build = package_build_id(legacy_zip)
    bridge_build = package_build_id(bridge_zip)
    release_build = package_build_id(release_zip)
    release_hash = hashlib.sha256(release_zip.read_bytes()).hexdigest()

    with tempfile.TemporaryDirectory(prefix="ShapeAzoidTwoHop_") as temp:
        temp_root = Path(temp)
        safe_extract(legacy_zip, temp_root / "installed")
        game_root = temp_root / "installed" / "Shape-Azoid"
        updater = game_root / "Update Shape-Azoid.ps1"

        custom_settings = '{"graphics":{"theme":"atomic_dark"},"proof":"keep"}\n'
        (game_root / "settings.json").write_text(custom_settings, encoding="ascii")
        custom_music = game_root / "music" / "jeremys-custom-track.mp3"
        custom_music.write_bytes(b"player-added-music")
        runtime_marker = (
            game_root / "Shape-Azoid Support" / ".venv" / "two-hop-runtime-marker.txt"
        )
        runtime_marker.parent.mkdir(parents=True, exist_ok=True)
        runtime_marker.write_text("keep player runtime\n", encoding="ascii")

        old_updater = updater.read_text(encoding="ascii")
        assert "latest-build.txt" in old_updater
        assert "latest-release.json" not in old_updater
        run_updater(updater, bridge_zip, bridge_build)
        assert (game_root / "BUILD_ID.txt").read_text(encoding="ascii").strip() == bridge_build
        bridged_updater = updater.read_text(encoding="ascii")
        assert "latest-release.json" in bridged_updater
        assert "Read-PackageFiles" in bridged_updater
        assert (game_root / "PACKAGE_FILES.json").is_file()

        manifest = json.dumps(
            {
                "build_id": release_build,
                "download_url": RELEASE_URL,
                "sha256": release_hash,
            },
            separators=(",", ":"),
        )
        run_updater(updater, release_zip, manifest)
        assert (game_root / "BUILD_ID.txt").read_text(encoding="ascii").strip() == release_build
        assert (game_root / "settings.json").read_text(encoding="ascii") == custom_settings
        assert custom_music.read_bytes() == b"player-added-music"
        assert runtime_marker.read_text(encoding="ascii") == "keep player runtime\n"
        assert all(not (game_root / "music" / name).exists() for name in OLD_RENAMED_TRACKS)
        assert all((game_root / "music" / name).is_file() for name in NEW_RENAMED_TRACKS)

        with zipfile.ZipFile(release_zip) as release_archive:
            expected_exe = release_archive.read("Shape-Azoid/Shape-Azoid.exe")
            expected_manifest = release_archive.read("Shape-Azoid/PACKAGE_FILES.json")
        assert (game_root / "Shape-Azoid.exe").read_bytes() == expected_exe
        assert (game_root / "PACKAGE_FILES.json").read_bytes() == expected_manifest

    print(f"PASS: exact legacy updater advanced {legacy_build} to {bridge_build}")
    print(f"PASS: bridged updater advanced to hash-verified {release_build}")
    print("PASS: obsolete packaged tracks were removed and renamed tracks installed")
    print("PASS: settings, custom music, and local .venv content were preserved")
    print("Shape-Azoid two-hop update probe: 4/4 passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
