import json
import os
import json
import shutil
import subprocess
import sys
import textwrap
import zipfile
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ZIP_ROOT_NAME = "Shape-Azoid"
SUPPORT_DIR_NAME = "Shape-Azoid Support"
RELEASE_VERSION = "v0.7.33"
BUILD_STAMP = datetime.now().strftime("%Y%m%d-%H%M")

# TEST_MODE builds into a separate, timestamped folder instead of overwriting
# the live Shape-Azoid-portable folder / published zips. It's opt-in via
# SHAPE_AZOID_TEST_BUILD=1 so the normal release flow (used by the real
# publish step) is completely unchanged by default.
TEST_MODE = os.environ.get("SHAPE_AZOID_TEST_BUILD") == "1"
BUILD_ID = f"{RELEASE_VERSION}-{BUILD_STAMP}" + ("-TEST" if TEST_MODE else "")

if TEST_MODE:
    TEST_TAG = f"TEST-{BUILD_STAMP}"
    PACKAGE_ROOT = ROOT.parent / f"Shape-Azoid-portable-{TEST_TAG}"
    ZIP_PATH = ROOT.parent / f"Shape-Azoid-portable-{TEST_TAG}.zip"
    VERSIONED_ZIP_PATH = ROOT.parent / f"shape-azoid-{TEST_TAG}.zip"
else:
    PACKAGE_ROOT = ROOT.parent / "Shape-Azoid-portable"
    ZIP_PATH = ROOT.parent / "Shape-Azoid-portable.zip"
    VERSIONED_ZIP_PATH = ROOT.parent / f"shape-azoid-{RELEASE_VERSION}.zip"
RELEASE_MANIFEST_URL = "https://raw.githubusercontent.com/elfchess-GHub/Hot2Trot/main/games/downloads/shape-azoid/latest-release.json"
ICON_DIR = ROOT / "assets" / "icons"
ICON_PATH = ICON_DIR / "shape-azoid.ico"

IMAGE_EXTS = {".png", ".jpg", ".jpeg"}
MUSIC_EXTS = {".mp3", ".ogg", ".wav", ".flac", ".mid", ".midi"}

try:
    from PIL import Image
except ImportError:
    Image = None


def copy_file(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def rebuild_game_executable():
    pyinstaller = shutil.which("pyinstaller")
    if pyinstaller:
        command = [pyinstaller, str(ROOT / "Shape-Azoid.spec"), "--noconfirm"]
    else:
        command = [sys.executable, "-m", "PyInstaller", str(ROOT / "Shape-Azoid.spec"), "--noconfirm"]
    subprocess.run(command, cwd=ROOT, check=True)
    dist_exe = ROOT / "dist" / "Shape-Azoid.exe"
    if not dist_exe.exists():
        raise FileNotFoundError(f"PyInstaller did not create {dist_exe}")
    if not TEST_MODE:
        # Test builds leave the source-folder Shape-Azoid.exe alone; only the
        # isolated PACKAGE_ROOT test folder gets the freshly built exe.
        copy_file(dist_exe, ROOT / "Shape-Azoid.exe")


def copy_image(src, dst, max_size=None, exact_size=None):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if Image is None:
        shutil.copy2(src, dst)
        return
    try:
        with Image.open(src) as img:
            img = img.convert("RGBA")
            if exact_size:
                img.thumbnail(exact_size, Image.Resampling.LANCZOS)
                canvas = Image.new("RGBA", exact_size, (0, 0, 0, 0))
                x = (exact_size[0] - img.width) // 2
                y = (exact_size[1] - img.height) // 2
                canvas.alpha_composite(img, (x, y))
                img = canvas
            elif max_size:
                img.thumbnail(max_size, Image.Resampling.LANCZOS)
            img.save(dst, optimize=True)
    except Exception:
        shutil.copy2(src, dst)


def copy_tree(src_dir, dst_dir, include_exts=None):
    if not src_dir.exists():
        return 0
    count = 0
    for src in src_dir.rglob("*"):
        if not src.is_file():
            continue
        if "__pycache__" in src.parts:
            continue
        if include_exts and src.suffix.lower() not in include_exts:
            continue
        copy_file(src, dst_dir / src.relative_to(src_dir))
        count += 1
    return count


def write_default_settings():
    settings = """{
  "audio": {
    "music_enabled": true,
    "music_volume": 0.45,
    "sound_effects_volume": 0.78
  },
  "gameplay": {
    "ai_players": [
      1
    ],
    "player_count": 2
  },
  "graphics": {
    "display_mode": "windowed",
    "theme": "adam_sphere"
  },
  "sound": {
    "glass_button": "glass",
    "key": "C Major",
    "pluck_button": "pluck"
  },
  "version": 1
}
"""
    (PACKAGE_ROOT / "settings.json").write_text(settings, encoding="ascii")


def write_package_file_manifest():
    managed = []
    for source in sorted(PACKAGE_ROOT.rglob("*")):
        if not source.is_file():
            continue
        relative = source.relative_to(PACKAGE_ROOT)
        if relative.as_posix() in {"PACKAGE_FILES.json", "settings.json"}:
            continue
        if ".venv" in relative.parts:
            continue
        managed.append(relative.as_posix())
    manifest = {"version": 1, "files": managed}
    (PACKAGE_ROOT / "PACKAGE_FILES.json").write_text(
        json.dumps(manifest, indent=2) + "\n",
        encoding="ascii",
    )


def build_icon():
    ICON_DIR.mkdir(parents=True, exist_ok=True)
    source = ROOT / "art" / "opening.png"
    if Image is None or not source.exists():
        return False
    try:
        with Image.open(source) as img:
            img = img.convert("RGBA")
            w, h = img.size
            crop_size = min(w, h)
            left = max(0, (w - crop_size) // 2)
            top = max(0, (h - crop_size) // 2)
            img = img.crop((left, top, left + crop_size, top + crop_size))
            img.save(ICON_PATH, sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)])
        return True
    except Exception:
        return False


def copy_runtime_venv():
    src_dir = ROOT / ".venv"
    dst_dir = PACKAGE_ROOT / SUPPORT_DIR_NAME / ".venv"
    if not src_dir.exists():
        return 0
    skip_dirs = {"__pycache__", ".pytest_cache"}
    count = 0
    for src in src_dir.rglob("*"):
        if not src.is_file():
            continue
        if any(part in skip_dirs for part in src.parts):
            continue
        copy_file(src, dst_dir / src.relative_to(src_dir))
        count += 1
    return count


def copy_music():
    src_dir = ROOT / "music"
    dst_dir = PACKAGE_ROOT / "music"
    dst_dir.mkdir(parents=True, exist_ok=True)
    count = 0
    if not src_dir.exists():
        return count
    for src in sorted(src_dir.iterdir(), key=lambda item: item.name.lower()):
        if not src.is_file():
            continue
        if src.suffix.lower() in MUSIC_EXTS or src.name.lower() == "readme.txt":
            copy_file(src, dst_dir / src.name)
            count += 1
    return count


def copy_art():
    src_dir = ROOT / "art"
    dst_dir = PACKAGE_ROOT / "art"
    count = 0
    if not src_dir.exists():
        return count
    action_dirs = {"thinking", "sad", "Angry", "pointleftohno", "pointright"}
    for src in src_dir.iterdir():
        if src.is_file() and src.suffix.lower() in IMAGE_EXTS:
            copy_file(src, dst_dir / src.name)
            count += 1
    for folder in action_dirs:
        action_src = src_dir / folder
        if not action_src.exists():
            continue
        for src in action_src.rglob("*"):
            if src.is_file() and src.suffix.lower() in IMAGE_EXTS:
                copy_file(src, dst_dir / folder / src.relative_to(action_src))
                count += 1
    ufo_src = src_dir / "UFO"
    if ufo_src.exists():
        for src in ufo_src.rglob("*"):
            if src.is_file() and src.suffix.lower() in IMAGE_EXTS:
                copy_image(src, dst_dir / "UFO" / src.relative_to(ufo_src), max_size=(256, 120))
                count += 1
    return count


def copy_ufo():
    src_dir = ROOT / "UFO"
    dst_dir = PACKAGE_ROOT / "UFO"
    count = 0
    if not src_dir.exists():
        return count
    for src in src_dir.rglob("*"):
        if src.is_file() and src.suffix.lower() in IMAGE_EXTS:
            copy_image(src, dst_dir / src.relative_to(src_dir), max_size=(256, 120))
            count += 1
    return count


def copy_themes():
    src_dir = ROOT / "themes"
    dst_dir = PACKAGE_ROOT / "themes"
    count = 0
    for theme in ["atomic_dark", "rocket_garden", "olive_party_platter"]:
        theme_src = src_dir / theme
        if not theme_src.exists():
            continue
        for src in theme_src.rglob("*"):
            if not src.is_file():
                continue
            rel = src.relative_to(src_dir)
            if src.suffix.lower() in IMAGE_EXTS:
                copy_image(src, dst_dir / rel, exact_size=(1400, 900))
            else:
                copy_file(src, dst_dir / rel)
            count += 1
    return count


def compile_csharp(source_path, output_path, icon_path=None):
    csc = Path(r"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe")
    if not csc.exists():
        raise FileNotFoundError(f"C# compiler not found: {csc}")
    command = [
        str(csc),
        "/nologo",
        "/target:winexe",
        f"/out:{output_path}",
        str(source_path),
        "/reference:System.Windows.Forms.dll",
    ]
    if icon_path and Path(icon_path).exists():
        command.insert(3, f"/win32icon:{icon_path}")
    subprocess.run(command, check=True, cwd=str(PACKAGE_ROOT))


def write_installer_tools():
    installer_source = r"""
using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

internal static class Program
{
    private const string AppName = "Shape-Azoid";
    private const string Publisher = "Elfchess";
    private const string DefaultUninstallKeyName = "Elfchess Shape-Azoid";

    [STAThread]
    private static int Main(string[] args)
    {
        bool quiet = Array.Exists(args, arg => arg.Equals("/quiet", StringComparison.OrdinalIgnoreCase));
        string uninstallKeyName = ReadArg(args, "/uninstall-key=", DefaultUninstallKeyName);
        string sourceRoot = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
        string defaultInstallRoot = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Elfchess",
            "Shape-Azoid");
        string installRoot = ReadArg(args, "/install-root=", defaultInstallRoot);
        try
        {
            Directory.CreateDirectory(installRoot);
            CopyDirectory(sourceRoot, installRoot);
            RegisterInstalledApp(installRoot, uninstallKeyName);
            CreateStartMenuShortcut(installRoot, uninstallKeyName);
            if (!quiet) MessageBox.Show("Shape-Azoid was installed. Windows Installed Apps can now uninstall it.", "Shape-Azoid Installer");
            return 0;
        }
        catch (Exception ex)
        {
            if (!quiet) MessageBox.Show(ex.Message, "Shape-Azoid install failed");
            return 1;
        }
    }

    private static string ReadArg(string[] args, string prefix, string fallback)
    {
        foreach (string arg in args)
        {
            if (arg.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            {
                string value = arg.Substring(prefix.Length).Trim().Trim('"');
                if (!string.IsNullOrWhiteSpace(value)) return value;
            }
        }
        return fallback;
    }

    private static void CopyDirectory(string sourceRoot, string installRoot)
    {
        foreach (string directory in Directory.GetDirectories(sourceRoot, "*", SearchOption.AllDirectories))
        {
            string relative = directory.Substring(sourceRoot.Length).TrimStart(Path.DirectorySeparatorChar);
            if (ShouldSkip(relative)) continue;
            Directory.CreateDirectory(Path.Combine(installRoot, relative));
        }
        foreach (string file in Directory.GetFiles(sourceRoot, "*", SearchOption.AllDirectories))
        {
            string relative = file.Substring(sourceRoot.Length).TrimStart(Path.DirectorySeparatorChar);
            if (ShouldSkip(relative)) continue;
            string target = Path.Combine(installRoot, relative);
            Directory.CreateDirectory(Path.GetDirectoryName(target));
            if (relative.Equals("settings.json", StringComparison.OrdinalIgnoreCase) && File.Exists(target))
            {
                continue;
            }
            File.Copy(file, target, true);
        }
    }

    private static bool ShouldSkip(string relative)
    {
        string normalized = relative.Replace('/', '\\');
        return normalized.StartsWith("logs\\", StringComparison.OrdinalIgnoreCase)
            || normalized.Equals("logs", StringComparison.OrdinalIgnoreCase)
            || normalized.Equals("Shape_Azoid_Network_Server.txt", StringComparison.OrdinalIgnoreCase)
            || normalized.Equals("HOST_SERVER_ADDRESS.txt", StringComparison.OrdinalIgnoreCase)
            || normalized.Equals("shape_azoid_online_server.log", StringComparison.OrdinalIgnoreCase);
    }

    private static void RegisterInstalledApp(string installRoot, string uninstallKeyName)
    {
        string uninstallKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\" + uninstallKeyName;
        string buildIdPath = Path.Combine(installRoot, "BUILD_ID.txt");
        string version = File.Exists(buildIdPath) ? File.ReadAllText(buildIdPath).Trim() : "v0.7.33";
        long estimatedSizeKb = DirectorySize(new DirectoryInfo(installRoot)) / 1024;
        using (RegistryKey key = Registry.CurrentUser.CreateSubKey(uninstallKey))
        {
            key.SetValue("DisplayName", AppName, RegistryValueKind.String);
            key.SetValue("DisplayVersion", version, RegistryValueKind.String);
            key.SetValue("Publisher", Publisher, RegistryValueKind.String);
            key.SetValue("InstallLocation", installRoot, RegistryValueKind.String);
            key.SetValue("DisplayIcon", Quote(Path.Combine(installRoot, "Play Shape-Azoid.exe")), RegistryValueKind.String);
            string uninstallArgs = "";
            if (!uninstallKeyName.Equals(DefaultUninstallKeyName, StringComparison.OrdinalIgnoreCase))
            {
                uninstallArgs = " /uninstall-key=" + Quote(uninstallKeyName) + " /install-root=" + Quote(installRoot);
            }
            key.SetValue("UninstallString", Quote(Path.Combine(installRoot, "Uninstall Shape-Azoid.exe")) + uninstallArgs, RegistryValueKind.String);
            key.SetValue("QuietUninstallString", Quote(Path.Combine(installRoot, "Uninstall Shape-Azoid.exe")) + " /quiet" + uninstallArgs, RegistryValueKind.String);
            key.SetValue("NoModify", 1, RegistryValueKind.DWord);
            key.SetValue("NoRepair", 1, RegistryValueKind.DWord);
            key.SetValue("EstimatedSize", (int)Math.Min(int.MaxValue, estimatedSizeKb), RegistryValueKind.DWord);
        }
    }

    private static void CreateStartMenuShortcut(string installRoot, string uninstallKeyName)
    {
        if (!uninstallKeyName.Equals(DefaultUninstallKeyName, StringComparison.OrdinalIgnoreCase)) return;
        string programs = Environment.GetFolderPath(Environment.SpecialFolder.Programs);
        string folder = Path.Combine(programs, "Elfchess");
        Directory.CreateDirectory(folder);
        string shortcut = Path.Combine(folder, "Shape-Azoid.lnk");
        string target = Path.Combine(installRoot, "Play Shape-Azoid.exe");
        string ps = "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('" + shortcut.Replace("'", "''") + "');"
            + "$s.TargetPath='" + target.Replace("'", "''") + "';"
            + "$s.WorkingDirectory='" + installRoot.Replace("'", "''") + "';"
            + "$s.Save()";
        ProcessStartInfo start = new ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps + "\"");
        start.CreateNoWindow = true;
        start.UseShellExecute = false;
        using (Process proc = Process.Start(start))
        {
            proc.WaitForExit();
        }
    }

    private static long DirectorySize(DirectoryInfo directory)
    {
        long size = 0;
        foreach (FileInfo file in directory.GetFiles()) size += file.Length;
        foreach (DirectoryInfo child in directory.GetDirectories()) size += DirectorySize(child);
        return size;
    }

    private static string Quote(string value)
    {
        return "\"" + value + "\"";
    }
}
"""
    uninstaller_source = r"""
using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

internal static class Program
{
    private const string DefaultUninstallKeyName = "Elfchess Shape-Azoid";

    [STAThread]
    private static int Main(string[] args)
    {
        bool quiet = Array.Exists(args, arg => arg.Equals("/quiet", StringComparison.OrdinalIgnoreCase));
        string uninstallKeyName = ReadArg(args, "/uninstall-key=", DefaultUninstallKeyName);
        string installRoot = ReadArg(
            args,
            "/install-root=",
            AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
        try
        {
            if (!quiet)
            {
                DialogResult result = MessageBox.Show(
                    "Remove Shape-Azoid from this computer?",
                    "Uninstall Shape-Azoid",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);
                if (result != DialogResult.Yes) return 0;
            }
            string uninstallKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\" + uninstallKeyName;
            Registry.CurrentUser.DeleteSubKeyTree(uninstallKey, false);
            if (uninstallKeyName.Equals(DefaultUninstallKeyName, StringComparison.OrdinalIgnoreCase))
            {
                DeleteStartMenuShortcut();
            }
            ScheduleDirectoryRemoval(installRoot);
            return 0;
        }
        catch (Exception ex)
        {
            if (!quiet) MessageBox.Show(ex.Message, "Shape-Azoid uninstall failed");
            return 1;
        }
    }

    private static string ReadArg(string[] args, string prefix, string fallback)
    {
        foreach (string arg in args)
        {
            if (arg.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            {
                string value = arg.Substring(prefix.Length).Trim().Trim('"');
                if (!string.IsNullOrWhiteSpace(value)) return value;
            }
        }
        return fallback;
    }

    private static void DeleteStartMenuShortcut()
    {
        string shortcut = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.Programs),
            "Elfchess",
            "Shape-Azoid.lnk");
        if (File.Exists(shortcut)) File.Delete(shortcut);
    }

    private static void ScheduleDirectoryRemoval(string installRoot)
    {
        string command = "/C \"ping 127.0.0.1 -n 3 > nul & rmdir /s /q \"\"" + installRoot + "\"\"\"";
        ProcessStartInfo start = new ProcessStartInfo("cmd.exe", command);
        start.CreateNoWindow = true;
        start.UseShellExecute = false;
        start.WorkingDirectory = Path.GetTempPath();
        Process.Start(start);
    }
}
"""
    installer_source_path = PACKAGE_ROOT / "Install Shape-Azoid.cs"
    uninstaller_source_path = PACKAGE_ROOT / "Uninstall Shape-Azoid.cs"
    installer_source_path.write_text(textwrap.dedent(installer_source).strip() + "\n", encoding="ascii")
    uninstaller_source_path.write_text(textwrap.dedent(uninstaller_source).strip() + "\n", encoding="ascii")
    try:
        compile_csharp(installer_source_path, PACKAGE_ROOT / "Install Shape-Azoid.exe", ICON_PATH)
        compile_csharp(uninstaller_source_path, PACKAGE_ROOT / "Uninstall Shape-Azoid.exe", ICON_PATH)
    finally:
        installer_source_path.unlink(missing_ok=True)
        uninstaller_source_path.unlink(missing_ok=True)


def render_updater(test_mode=TEST_MODE, build_id=BUILD_ID):
    updater = f"""$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$currentBuildFile = Join-Path $root "BUILD_ID.txt"
$currentBuild = if (Test-Path $currentBuildFile) {{ (Get-Content $currentBuildFile -Raw).Trim() }} else {{ "" }}
$manifestUrl = "{RELEASE_MANIFEST_URL}"
$tempRoot = Join-Path $env:TEMP ("ShapeAzoidUpdate_" + [Guid]::NewGuid().ToString("N"))
$zipPath = Join-Path $tempRoot "Shape-Azoid-update.zip"
function Read-PackageFiles([string]$manifestPath) {{
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {{ return @() }}
    try {{
        $packageManifest = (Get-Content -LiteralPath $manifestPath -Raw) | ConvertFrom-Json
        return @($packageManifest.files | ForEach-Object {{ [string]$_ }})
    }} catch {{
        return @()
    }}
}}
try {{
    New-Item -ItemType Directory -Force -Path $tempRoot | Out-Null
    try {{
        $manifestText = (Invoke-WebRequest -UseBasicParsing -Uri $manifestUrl -TimeoutSec 10).Content
        $manifest = $manifestText | ConvertFrom-Json
    }} catch {{
        Write-Host "Update check skipped: could not read the Shape-Azoid release manifest."
        exit 0
    }}
    $latestBuild = [string]$manifest.build_id
    $downloadUrl = [string]$manifest.download_url
    $expectedSha256 = ([string]$manifest.sha256).ToLowerInvariant()
    if (-not $latestBuild) {{ throw "Release manifest did not contain a build ID." }}
    if ($downloadUrl -notmatch '^https://github\\.com/elfchess-GHub/Hot2Trot/releases/download/') {{
        throw "Release manifest contained an unapproved download address."
    }}
    if ($expectedSha256 -notmatch '^[0-9a-f]{{64}}$') {{ throw "Release manifest contained an invalid SHA-256." }}
    if ($latestBuild -and $currentBuild -and $latestBuild -eq $currentBuild) {{
        Write-Host "Shape-Azoid is already current ($currentBuild)."
        exit 0
    }}
    $currentStamp = ""
    $latestStamp = ""
    if ($currentBuild -match "(\\d{{8}}-\\d{{4}})$") {{ $currentStamp = $Matches[1] }}
    if ($latestBuild -match "(\\d{{8}}-\\d{{4}})$") {{ $latestStamp = $Matches[1] }}
    if ($currentStamp -and $latestStamp -and $currentStamp -gt $latestStamp) {{
        Write-Host "Update check skipped: local build $currentBuild is newer than published build $latestBuild."
        exit 0
    }}
    Invoke-WebRequest -UseBasicParsing -Uri $downloadUrl -OutFile $zipPath -TimeoutSec 300
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    $zipStream = [System.IO.File]::OpenRead($zipPath)
    try {{
        $actualSha256 = ([System.BitConverter]::ToString($sha256.ComputeHash($zipStream))).Replace("-", "").ToLowerInvariant()
    }} finally {{
        $zipStream.Dispose()
        $sha256.Dispose()
    }}
    if ($actualSha256 -ne $expectedSha256) {{
        throw "Downloaded package failed SHA-256 verification."
    }}
    Expand-Archive -LiteralPath $zipPath -DestinationPath $tempRoot -Force
    $candidate = Get-ChildItem -Path $tempRoot -Recurse -Filter "Shape-Azoid.exe" | Select-Object -First 1
    if (-not $candidate) {{ throw "Downloaded package did not contain Shape-Azoid.exe." }}
    $newRoot = Split-Path -Parent $candidate.FullName
    $newBuildFile = Join-Path $newRoot "BUILD_ID.txt"
    $newBuild = if (Test-Path $newBuildFile) {{ (Get-Content $newBuildFile -Raw).Trim() }} else {{ "" }}
    if ($latestBuild -and $newBuild -and $latestBuild -ne $newBuild) {{ throw "Downloaded build $newBuild did not match published build $latestBuild." }}
    Write-Host "Updating Shape-Azoid from $currentBuild to $newBuild..."
    $oldFiles = @(Read-PackageFiles (Join-Path $root "PACKAGE_FILES.json"))
    $newFiles = @(Read-PackageFiles (Join-Path $newRoot "PACKAGE_FILES.json"))
    $rootPrefix = [System.IO.Path]::GetFullPath($root).TrimEnd('\\') + '\\'
    foreach ($relativePath in $oldFiles) {{
        if ($newFiles -contains $relativePath) {{ continue }}
        if ([System.IO.Path]::IsPathRooted($relativePath) -or $relativePath -match '(^|[\\\\/])\\.\\.([\\\\/]|$)') {{ continue }}
        $obsoletePath = [System.IO.Path]::GetFullPath((Join-Path $root ($relativePath -replace '/', '\\')))
        if ($obsoletePath.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase) -and (Test-Path -LiteralPath $obsoletePath -PathType Leaf)) {{
            Remove-Item -LiteralPath $obsoletePath -Force
        }}
    }}
    $preserveExisting = @("Play Shape-Azoid.exe", "settings.json")
    Get-ChildItem -LiteralPath $newRoot -Force | Where-Object {{ $preserveExisting -notcontains $_.Name -or -not (Test-Path (Join-Path $root $_.Name)) }} | ForEach-Object {{
        Copy-Item -LiteralPath $_.FullName -Destination $root -Recurse -Force
    }}
    foreach ($runtimeFile in @("Shape_Azoid_Network_Server.txt", "HOST_SERVER_ADDRESS.txt", "shape_azoid_online_server.log")) {{
        $runtimePath = Join-Path $root $runtimeFile
        if (Test-Path $runtimePath) {{
            Remove-Item -LiteralPath $runtimePath -Force -ErrorAction SilentlyContinue
        }}
    }}
    Write-Host "Shape-Azoid update complete."
}} catch {{
    Write-Host "Shape-Azoid update skipped: $($_.Exception.Message)"
}} finally {{
    if (Test-Path $tempRoot) {{
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }}
}}
"""
    if not test_mode:
        return updater

    marker = '$root = Split-Path -Parent $MyInvocation.MyCommand.Path\n'
    test_guard = (
        "# Isolated TEST package: public update checks and replacement are disabled.\n"
        f'$testBuild = "{build_id}"\n'
        'Write-Host "Shape-Azoid TEST build ${testBuild}: public updates are disabled for this package."\n'
        "exit 0\n"
    )
    return updater.replace(marker, marker + test_guard, 1)


def write_update_launchers():
    build_id_path = PACKAGE_ROOT / "BUILD_ID.txt"
    build_id_path.write_text(BUILD_ID + "\n", encoding="ascii")

    updater = render_updater()
    (PACKAGE_ROOT / "Update Shape-Azoid.ps1").write_text(updater, encoding="ascii")

    launcher_cmd = """@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File ".\\Update Shape-Azoid.ps1"
start "" ".\\Shape-Azoid.exe"
"""
    (PACKAGE_ROOT / "Play Shape-Azoid.cmd").write_text(launcher_cmd, encoding="ascii")

    launcher_source = r"""
using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

internal static class Program
{
    [STAThread]
    private static int Main()
    {
        string root = AppDomain.CurrentDomain.BaseDirectory;
        try
        {
            string updater = Path.Combine(root, "Update Shape-Azoid.ps1");
            if (File.Exists(updater))
            {
                using (Process updateProcess = new Process())
                {
                    updateProcess.StartInfo.FileName = "powershell.exe";
                    updateProcess.StartInfo.Arguments = "-NoProfile -ExecutionPolicy Bypass -File \"" + updater + "\"";
                    updateProcess.StartInfo.WorkingDirectory = root;
                    updateProcess.StartInfo.UseShellExecute = false;
                    updateProcess.StartInfo.CreateNoWindow = true;
                    updateProcess.Start();
                    updateProcess.WaitForExit();
                }
            }

            string gameExe = Path.Combine(root, "Shape-Azoid.exe");
            if (!File.Exists(gameExe))
            {
                MessageBox.Show("Shape-Azoid.exe was not found beside this launcher.", "Shape-Azoid");
                return 1;
            }

            ProcessStartInfo startInfo = new ProcessStartInfo(gameExe);
            startInfo.WorkingDirectory = root;
            startInfo.UseShellExecute = true;
            Process.Start(startInfo);
            return 0;
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Shape-Azoid could not start");
            return 1;
        }
    }
}
"""
    source_path = PACKAGE_ROOT / "Play Shape-Azoid Launcher.cs"
    source_path.write_text(textwrap.dedent(launcher_source).strip() + "\n", encoding="ascii")
    try:
        compile_csharp(source_path, PACKAGE_ROOT / "Play Shape-Azoid.exe", ICON_PATH)
    finally:
        source_path.unlink(missing_ok=True)


def build_zip():
    icon_built = build_icon()
    rebuild_game_executable()
    if PACKAGE_ROOT.exists():
        shutil.rmtree(PACKAGE_ROOT)
    PACKAGE_ROOT.mkdir(parents=True)

    top_level = [
        "Shape-Azoid.exe",
        "README.md",
        "Install_Shape_Azoid_Requirements.cmd",
    ]
    support_level = [
        "shape_azoid.py",
        "shape_azoid_core.py",
        "requirements.txt",
    ]
    copied = {"top_level": 0}
    for name in top_level:
        src = ROOT / name
        if name == "Shape-Azoid.exe":
            dist_exe = ROOT / "dist" / name
            if dist_exe.exists():
                src = dist_exe
        if src.exists():
            copy_file(src, PACKAGE_ROOT / name)
            copied["top_level"] += 1
    copied["support_top_level"] = 0
    support_root = PACKAGE_ROOT / SUPPORT_DIR_NAME
    for name in support_level:
        src = ROOT / name
        if src.exists():
            copy_file(src, support_root / name)
            copied["support_top_level"] += 1
    support_scripts = ROOT / "support_scripts"
    if support_scripts.exists():
        for src in sorted(support_scripts.glob("*.cmd")):
            copy_file(src, support_root / src.name)
            copied["support_top_level"] += 1

    copied["network"] = copy_tree(ROOT / "network", support_root / "network", include_exts={".py"})
    copied["tools"] = copy_tree(ROOT / "tools", support_root / "tools", include_exts={".py", ".cmd"})
    # Do NOT ship the dev .venv (copy_runtime_venv, kept below for reference).
    # Its pyvenv.cfg hardcodes the path to the machine it was built on, so any
    # other player trying to host a game gets a venv that silently can't run -
    # local_online_python() finds the copied python.exe and uses it without
    # checking whether it actually works on that machine. Instead we ship
    # Install_Shape_Azoid_Requirements.cmd (already bundled below) so each
    # player builds their own working venv the first time they set up hosting.
    copied["runtime_venv"] = 0
    copied["music"] = copy_music()
    copied["art"] = copy_art()
    top_level_ufo = copy_ufo()
    if top_level_ufo:
        copied["top_level_ufo"] = top_level_ufo
    copied["themes"] = copy_themes()
    copied["icons"] = 0
    if ICON_PATH.exists():
        copy_file(ICON_PATH, PACKAGE_ROOT / "assets" / "icons" / ICON_PATH.name)
        copied["icons"] = 1
    write_default_settings()
    write_update_launchers()
    write_installer_tools()
    write_package_file_manifest()
    copied["settings"] = 1
    copied["update_launchers"] = 3
    copied["installer_tools"] = 2
    copied["package_manifest"] = 1
    copied["icon_built"] = int(icon_built)

    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for src in sorted(PACKAGE_ROOT.rglob("*")):
            if src.is_file():
                archive.write(src, Path(ZIP_ROOT_NAME) / src.relative_to(PACKAGE_ROOT))
    shutil.copy2(ZIP_PATH, VERSIONED_ZIP_PATH)

    if TEST_MODE:
        print("=== TEST BUILD (SHAPE_AZOID_TEST_BUILD=1) ===")
        print("Nothing in the live Shape-Azoid-portable folder or published zips was touched.")
    print(f"Built {PACKAGE_ROOT}")
    print(f"Built {ZIP_PATH}")
    print(f"Zip size: {ZIP_PATH.stat().st_size:,} bytes")
    print(f"Built {VERSIONED_ZIP_PATH}")
    for key, value in copied.items():
        print(f"{key}: {value}")


if __name__ == "__main__":
    build_zip()
