import os
import socket
import subprocess
import sys
import tempfile
import textwrap
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from network.shape_azoid_http_client import ShapeAzoidHttpClient


class ProbeFailure(RuntimeError):
    pass


def free_port(host):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind((host, 0))
        return int(probe.getsockname()[1])


def wait_for_server(client, timeout_seconds=12.0):
    deadline = time.time() + timeout_seconds
    last_error = "server did not answer"
    while time.time() < deadline:
        try:
            if client.health().get("ok"):
                return
        except Exception as exc:
            last_error = str(exc)
        time.sleep(0.2)
    raise ProbeFailure(f"Server did not become ready: {last_error}")


def run_joiner_process(work_dir, room_code, env):
    code = textwrap.dedent(
        f"""
        import json
        import os
        import sys
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
        sys.path.insert(0, {str(ROOT)!r})
        import shape_azoid

        shape_azoid.GAME.online_player_name = "Anna"
        shape_azoid.GAME.online_player_name_input = "Anna"
        shape_azoid.GAME.open_online()
        if shape_azoid.GAME.online_focus != "room_code":
            raise SystemExit("Online screen did not focus room code.")
        shape_azoid.GAME.online_room_code_input = {room_code!r}
        shape_azoid.GAME.join_online_room()
        if not shape_azoid.GAME.online_seat_token:
            raise SystemExit(shape_azoid.GAME.online_status)
        if shape_azoid.GAME.online_lobby.get("viewer_player") != 1:
            raise SystemExit("Joiner did not receive seat 2.")
        shape_azoid.GAME.join_online_room()
        if len(shape_azoid.GAME.online_lobby.get("seats", [])) != 2:
            raise SystemExit("Second Join created an extra seat.")
        shape_azoid.GAME.cycle_online_seat_color()
        if shape_azoid.GAME.online_lobby.get("seats", [{{}}, {{}}])[1].get("color_name") != "Yellow":
            raise SystemExit("Joiner could not change color after joining.")
        shape_azoid.GAME.poll_online_lobby()
        print(json.dumps({{
            "server": shape_azoid.GAME.online_server_url,
            "room_code": shape_azoid.GAME.online_room_code,
            "seat_token": shape_azoid.GAME.online_seat_token,
            "status": shape_azoid.GAME.online_status,
            "viewer": shape_azoid.GAME.online_lobby.get("viewer_player"),
            "seats": [seat.get("name") for seat in shape_azoid.GAME.online_lobby.get("seats", [])],
        }}))
        """
    )
    result = subprocess.run(
        [sys.executable, "-c", code],
        cwd=str(work_dir),
        capture_output=True,
        text=True,
        env=env,
        timeout=18,
    )
    if result.returncode != 0:
        raise ProbeFailure(result.stderr.strip() or result.stdout.strip())
    lines = [line for line in result.stdout.splitlines() if line.strip().startswith("{")]
    if not lines:
        raise ProbeFailure(f"Joiner did not print JSON result: {result.stdout!r}")
    import json

    return json.loads(lines[-1])


def main():
    host = "127.0.0.1"
    port = free_port(host)
    base_url = f"http://{host}:{port}"
    temp_dir = tempfile.TemporaryDirectory()
    temp_path = Path(temp_dir.name)
    room_save_dir = tempfile.TemporaryDirectory()
    env = {
        **dict(os.environ),
        "SHAPE_AZOID_ROOM_SAVE_DIR": room_save_dir.name,
        "SDL_VIDEODRIVER": "dummy",
        "SDL_AUDIODRIVER": "dummy",
    }
    env.pop("SHAPE_AZOID_NETWORK_SERVER", None)
    server = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "network.shape_azoid_server:app", "--host", host, "--port", str(port)],
        cwd=str(ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        env=env,
    )
    passed = []

    def record(name):
        passed.append(name)
        print(f"PASS {name}")

    try:
        client = ShapeAzoidHttpClient(base_url)
        wait_for_server(client)
        record("server_start")

        created = client.create_room(host_name="Jeremy", player_count=2, ai_players=[], start=False)
        room_code = created["room_code"]
        host_token = created["host_seat_token"]
        record("host_create_lobby")

        (temp_path / "Shape_Azoid_Network_Server.txt").write_text(base_url + "\n", encoding="utf-8")
        joined = run_joiner_process(temp_path, room_code, env)
        if joined["server"] != base_url:
            raise ProbeFailure(f"Joiner used wrong server: {joined['server']!r}")
        if joined["seats"] != ["Jeremy", "Anna"]:
            raise ProbeFailure(f"Unexpected joiner lobby seats: {joined['seats']!r}")
        record("joiner_file_join")

        host_lobby = client.snapshot(room_code, seat_token=host_token)
        host_names = [seat["name"] for seat in host_lobby["seats"]]
        if host_names != ["Jeremy", "Anna"]:
            raise ProbeFailure(f"Host lobby did not show joiner: {host_names!r}")
        if host_lobby["seats"][1]["color_name"] != "Yellow":
            raise ProbeFailure(f"Host did not see joiner color change: {host_lobby['seats']!r}")
        record("host_sees_joiner")

        started = client.start_room(room_code, host_token)
        if not started.get("ok") or started.get("phase") != "playing":
            raise ProbeFailure(f"Host start failed: {started!r}")
        record("host_start")

        joiner_playing = client.snapshot(room_code, seat_token=joined["seat_token"])
        if joiner_playing.get("phase") != "playing":
            raise ProbeFailure(f"Joiner did not see playing phase: {joiner_playing!r}")
        if joiner_playing.get("viewer_player") != 1:
            raise ProbeFailure("Joiner viewer seat changed after start.")
        players = [player["name"] for player in joiner_playing["state"]["players"]]
        if players != ["Jeremy", "Anna"]:
            raise ProbeFailure(f"Unexpected playing players: {players!r}")
        record("joiner_playing_snapshot")

        print(f"RESULT {len(passed)}/{len(passed)} network file join probes passed")
    finally:
        server.terminate()
        try:
            server.wait(timeout=8)
        except subprocess.TimeoutExpired:
            server.kill()
            server.wait(timeout=8)
        if server.returncode not in (0, -15, 1):
            stderr = server.stderr.read() if server.stderr else ""
            if stderr.strip():
                print(stderr.strip())
        temp_dir.cleanup()
        room_save_dir.cleanup()


if __name__ == "__main__":
    main()
