import os
import sys
import time
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


try:
    from fastapi.testclient import TestClient
except ImportError:
    print("SKIP FastAPI is not installed. Run: pip install -r requirements.txt")
    raise SystemExit(0)

from network.shape_azoid_server import app, service
from shape_azoid_core import BOARD_CENTER, make_card, centroid, dist


def main():
    service.rooms.clear()
    with TestClient(app) as client:
        response = client.post("/api/rooms", json={"host_name": "Jeremy", "player_count": 2, "ai_players": []})
        assert response.status_code == 200, response.text
        created = response.json()
        room_code = created["room_code"]
        host_token = created["host_seat_token"]
        with service.lock:
            game = service.rooms[room_code]["game"]
            game.hands[0] = [make_card("hex", 0)]
        response = client.post(
            f"/api/rooms/{room_code}/commands",
            json={"seat_token": host_token, "command": {"type": "play_at", "card_index": 0, "pos": BOARD_CENTER}},
        )
        assert response.status_code == 200, response.text
        with service.lock:
            game = service.rooms[room_code]["game"]
            ball_pos = centroid(game.pieces[0]["points"])
            game.hands[0] = [make_card("zoid", 0)]
        response = client.post(
            f"/api/rooms/{room_code}/commands",
            json={"seat_token": host_token, "command": {"type": "play_at", "card_index": 0, "pos": ball_pos}},
        )
        assert response.status_code == 200, response.text
        with service.lock:
            start_pos = tuple(service.rooms[room_code]["game"].zoids[0]["pos"])
        time.sleep(0.25)
        response = client.get(f"/api/rooms/{room_code}", params={"seat_token": host_token})
        assert response.status_code == 200, response.text
        end_pos = tuple(response.json()["state"]["zoids"][0]["pos"])
        moved = dist(start_pos, end_pos)
        assert moved > 10.0, f"expected background motion, moved only {moved:.2f}px"
        print("PASS server background tick moves zoids between snapshots")
        print("RESULT 1/1 background tick probes passed")


if __name__ == "__main__":
    main()
