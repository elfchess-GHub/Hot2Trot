import math
import os
import sys
import tempfile
import time
from pathlib import Path


os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ.setdefault("SHAPE_AZOID_TELEMETRY", "0")

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import shape_azoid
import shape_azoid_core
from network.shape_azoid_room_service import ShapeAzoidRoomService


FACTORIES = (
    ("desktop", shape_azoid, shape_azoid.Game),
    ("core", shape_azoid_core, shape_azoid_core.ShapeAzoidMatch),
)
ROTATIONS = (0.0, math.pi / 13.0, math.pi / 7.0)
SHAPES = (("triangle", 3), ("square", 4), ("hex", 6))


def polygon(sides, rotation=0.0, center=(300.0, 300.0), radius=90.0):
    return shape_azoid.ensure_ccw(
        shape_azoid.regular_polygon(center, radius, sides, rotation)
    )


def square(x, y=0.0, size=100.0):
    return [
        (float(x), float(y)),
        (float(x + size), float(y)),
        (float(x + size), float(y + size)),
        (float(x), float(y + size)),
    ]


def piece(points, owner=0, shape="square"):
    return {
        "shape": shape,
        "points": list(points),
        "owner": owner,
        "played_by": owner,
    }


def ball(pos, vel, kind="zoid", owner=0, piece_idx=0):
    return {
        "pos": [float(pos[0]), float(pos[1])],
        "vel": [float(vel[0]), float(vel[1])],
        "owner": owner,
        "played_by": owner,
        "piece": piece_idx,
        "kind": kind,
        "visited": {piece_idx},
    }


def game_with(factory, point_sets):
    game = factory()
    game.pieces = [piece(points, owner=index % 6) for index, points in enumerate(point_sets)]
    game.invalidate_wall_plane_geometry()
    game.zoids = []
    game.open_walls = set()
    return game


class CountingPieceList(list):
    def __init__(self, values):
        super().__init__(values)
        self.iterations = 0

    def __iter__(self):
        self.iterations += 1
        return super().__iter__()


def reference_planes(module, points):
    center = module.centroid(points)
    result = []
    for a, b in module.side_list(points):
        nx, ny = module.inward_edge_normal(a, b, center)
        mx, my = module.midpoint(a, b)
        result.append((module.edge_key(a, b), nx, ny, mx, my))
    return tuple(result)


def reference_contacts(module, game, piece_idx, pos, radius):
    contacts = []
    for key, nx, ny, mx, my in reference_planes(module, game.pieces[piece_idx]["points"]):
        if key in game.open_walls:
            continue
        clearance = (pos[0] - mx) * nx + (pos[1] - my) * ny
        penetration = radius + module.WALL_COLLISION_MARGIN - clearance
        if penetration > module.WALL_COLLISION_TOLERANCE:
            contacts.append((key, nx, ny, mx, my, penetration))
    return contacts


def reference_touching(module, game, piece_idx, pos, radius):
    target = radius + module.WALL_COLLISION_MARGIN
    result = []
    for key, nx, ny, mx, my in reference_planes(module, game.pieces[piece_idx]["points"]):
        if key in game.open_walls:
            continue
        clearance = (pos[0] - mx) * nx + (pos[1] - my) * ny
        if clearance <= target + module.WALL_COLLISION_TOLERANCE:
            result.append((key, nx, ny))
    return result


def assert_records_close(label, actual, expected):
    if len(actual) != len(expected):
        raise AssertionError(f"{label}: length {len(actual)} != {len(expected)}")
    for row_index, (left, right) in enumerate(zip(actual, expected)):
        if left[0] != right[0]:
            raise AssertionError(f"{label}: edge key {row_index} differs")
        for value_index, (left_value, right_value) in enumerate(zip(left[1:], right[1:]), 1):
            if not math.isclose(left_value, right_value, rel_tol=0.0, abs_tol=1e-12):
                raise AssertionError(
                    f"{label}: row {row_index} value {value_index} "
                    f"{left_value} != {right_value}"
                )


def assert_explicit_rebuild(label, factory, mutate):
    game = game_with(factory, (square(0.0), square(130.0), square(260.0)))
    before = game.wall_plane_geometry()
    mutate(game)
    game.invalidate_wall_plane_geometry()
    after = game.wall_plane_geometry()
    if after is before:
        raise AssertionError(f"{label}: cache was reused after geometry changed")
    expected = tuple(reference_planes(type_module(game), item["points"]) for item in game.pieces)
    if len(after) != len(expected):
        raise AssertionError(f"{label}: rebuilt piece count differs")
    for index, (actual_piece, expected_piece) in enumerate(zip(after, expected)):
        assert_records_close(f"{label} piece {index}", actual_piece, expected_piece)


def type_module(game):
    return shape_azoid if isinstance(game, shape_azoid.Game) else shape_azoid_core


def cache_contract(label, module, factory):
    game = game_with(factory, (square(0.0), square(130.0)))
    cached = game.wall_plane_geometry()
    if not isinstance(cached, tuple) or not all(isinstance(item, tuple) for item in cached):
        raise AssertionError(f"{label}: cache is not immutable tuples")
    if game.wall_plane_geometry() is not cached:
        raise AssertionError(f"{label}: unchanged geometry did not reuse cache")

    game.pieces[0]["owner"] = 4
    game.pieces[0]["color"] = (1, 2, 3)
    if game.wall_plane_geometry() is not cached:
        raise AssertionError(f"{label}: owner/color change rebuilt geometry cache")

    key, nx, ny, mx, my = cached[0][0]
    normal_pos = (mx + nx * (module.ZOID_RADIUS - 1.0), my + ny * (module.ZOID_RADIUS - 1.0))
    penta_pos = (mx + nx * (module.PENTA_ZOID_RADIUS - 1.0), my + ny * (module.PENTA_ZOID_RADIUS - 1.0))
    if not any(item[0] == key for item in game.wall_contacts(0, normal_pos, module.ZOID_RADIUS)):
        raise AssertionError(f"{label}: normal radius did not contact cached wall")
    if not any(item[0] == key for item in game.wall_contacts(0, penta_pos, module.PENTA_ZOID_RADIUS)):
        raise AssertionError(f"{label}: Penta radius did not contact cached wall")
    if game.wall_plane_geometry() is not cached:
        raise AssertionError(f"{label}: ball radius use rebuilt geometry cache")

    game.open_walls.add(key)
    if any(item[0] == key for item in game.wall_contacts(0, normal_pos, module.ZOID_RADIUS)):
        raise AssertionError(f"{label}: open wall remained collidable")
    if game.wall_plane_geometry() is not cached:
        raise AssertionError(f"{label}: open-wall change rebuilt geometry cache")
    game.open_walls.remove(key)
    if not any(item[0] == key for item in game.wall_contacts(0, normal_pos, module.ZOID_RADIUS)):
        raise AssertionError(f"{label}: reclosed wall did not become collidable")
    if game.wall_plane_geometry() is not cached:
        raise AssertionError(f"{label}: closing wall rebuilt geometry cache")

    def replace(game_to_change):
        old_piece = game_to_change.pieces[1]
        game_to_change._probe_old_piece = old_piece
        game_to_change.pieces[1] = piece(list(old_piece["points"]), owner=old_piece["owner"])

    assert_explicit_rebuild(f"{label} direct add", factory, lambda item: item.pieces.append(piece(square(390.0))))
    assert_explicit_rebuild(f"{label} direct remove", factory, lambda item: item.pieces.pop(1))
    assert_explicit_rebuild(f"{label} direct replace", factory, replace)
    assert_explicit_rebuild(f"{label} direct reorder", factory, lambda item: item.pieces.reverse())
    assert_explicit_rebuild(
        f"{label} point mutation",
        factory,
        lambda item: item.pieces[0]["points"].__setitem__(0, (-3.0, -2.0)),
    )


def clean_lookup_is_constant_time(label, factory):
    game = factory()
    game.pieces = CountingPieceList([piece(square(index * 130.0)) for index in range(36)])
    game.invalidate_wall_plane_geometry()
    cached = game.wall_plane_geometry()
    game.pieces.iterations = 0
    for _ in range(10000):
        if game.wall_plane_geometry() is not cached:
            raise AssertionError(f"{label}: clean lookup replaced the cache")
    if game.pieces.iterations != 0:
        raise AssertionError(
            f"{label}: clean lookup scanned the piece list {game.pieces.iterations} times"
        )


def assert_path_invalidates(label, game, action):
    before_cache = game.wall_plane_geometry()
    before_version = game._wall_plane_geometry_version
    action()
    if game._wall_plane_geometry_version <= before_version:
        raise AssertionError(f"{label}: production path did not advance geometry version")
    after_cache = game.wall_plane_geometry()
    if after_cache is before_cache:
        raise AssertionError(f"{label}: production path reused stale wall planes")


def ready_desktop():
    game = shape_azoid.Game()
    game.setup()
    return game


def ready_core():
    game = shape_azoid_core.ShapeAzoidMatch()
    game.start()
    return game


def real_mutation_paths():
    for label, make_game in (("desktop", ready_desktop), ("core", ready_core)):
        game = make_game()
        game.pieces = [piece(square(0.0)), piece(square(130.0))]
        game.invalidate_wall_plane_geometry()
        assert_path_invalidates(f"{label} round reset", game, game.reset_round)

        game = make_game()
        assert_path_invalidates(
            f"{label} shape append",
            game,
            lambda: game.place_shape("square", 0, (300.0, 300.0)),
        )

        game = make_game()
        game.pieces = [piece(square(0.0)), piece(square(130.0))]
        game.invalidate_wall_plane_geometry()
        assert_path_invalidates(f"{label} UFO/remove reindex", game, lambda: game.remove_piece(0))

    desktop = ready_desktop()
    desktop.pieces = [piece(square(0.0))]
    desktop.invalidate_wall_plane_geometry()
    snapshot = desktop.state_snapshot(viewer_player=0)
    snapshot["pieces"] = [piece(square(260.0)), piece(square(390.0))]
    assert_path_invalidates(
        "desktop online snapshot replacement",
        desktop,
        lambda: desktop.apply_online_snapshot(
            {"phase": "playing", "viewer_player": 0, "state": snapshot}
        ),
    )

    with tempfile.TemporaryDirectory(prefix="shape_azoid_wall_cache_") as temp_dir:
        service = ShapeAzoidRoomService(save_dir=temp_dir)
        created = service.create_room(host_name="Cache Probe", player_count=2, start=True)
        room_code = created["room_code"]
        source = service.rooms[room_code]["game"]
        source.pieces = [piece(square(0.0)), piece(square(130.0))]
        source.invalidate_wall_plane_geometry()
        source.wall_plane_geometry()
        service.save_room(room_code)
        service.rooms.clear()
        service.load_room(room_code)
        restored = service.rooms[room_code]["game"]
        if restored._wall_plane_geometry_version <= 0:
            raise AssertionError("saved-room restore did not invalidate wall geometry")
        if restored._wall_plane_cache_version == restored._wall_plane_geometry_version:
            raise AssertionError("saved-room restore incorrectly marked wall cache clean")
        restored_planes = restored.wall_plane_geometry()
        if len(restored_planes) != 2:
            raise AssertionError("saved-room restore rebuilt the wrong wall-plane count")


def corner_probe(module, points, corner_index, radius, penetration=1.25):
    center = module.centroid(points)
    vertex = points[corner_index]
    edges = (
        (points[(corner_index - 1) % len(points)], vertex),
        (vertex, points[(corner_index + 1) % len(points)]),
    )
    desired = radius + module.WALL_COLLISION_MARGIN - penetration
    equations = []
    normals = []
    for a, b in edges:
        nx, ny = module.inward_edge_normal(a, b, center)
        mx, my = module.midpoint(a, b)
        equations.append((nx, ny, desired + mx * nx + my * ny))
        normals.append((nx, ny))
    n1x, n1y, c1 = equations[0]
    n2x, n2y, c2 = equations[1]
    determinant = n1x * n2y - n1y * n2x
    if abs(determinant) < 1e-12:
        raise AssertionError("corner equations are parallel")
    pos = (
        (c1 * n2y - n1y * c2) / determinant,
        (n1x * c2 - c1 * n2x) / determinant,
    )
    outward_x = -(normals[0][0] + normals[1][0])
    outward_y = -(normals[0][1] + normals[1][1])
    length = math.hypot(outward_x, outward_y)
    velocity = (outward_x * 3.1 / length, outward_y * 3.1 / length)
    return pos, velocity


def state(zoid):
    return tuple(float(value) for value in (*zoid["pos"], *zoid["vel"])) + (zoid["piece"],)


def assert_state_close(label, left, right, tolerance=1e-9):
    if left[-1] != right[-1]:
        raise AssertionError(f"{label}: piece {left[-1]} != {right[-1]}")
    for index, (left_value, right_value) in enumerate(zip(left[:-1], right[:-1])):
        if not math.isclose(left_value, right_value, rel_tol=0.0, abs_tol=tolerance):
            raise AssertionError(f"{label}: value {index} {left_value} != {right_value}")


def geometry_and_corner_parity():
    cases = 0
    for shape_name, sides in SHAPES:
        for rotation in ROTATIONS:
            points = polygon(sides, rotation)
            desktop = game_with(shape_azoid.Game, (points,))
            core = game_with(shape_azoid_core.ShapeAzoidMatch, (points,))
            for kind, radius in (
                ("zoid", shape_azoid.ZOID_RADIUS),
                ("penta", shape_azoid.PENTA_ZOID_RADIUS),
            ):
                for corner_index in range(sides):
                    pos, velocity = corner_probe(shape_azoid, points, corner_index, radius)
                    for label, module, game in (
                        ("desktop", shape_azoid, desktop),
                        ("core", shape_azoid_core, core),
                    ):
                        actual_contacts = game.wall_contacts(0, pos, radius)
                        actual_touching = game.touching_wall_normals(0, pos, radius)
                        assert_records_close(
                            f"{label} {shape_name} contact",
                            actual_contacts,
                            reference_contacts(module, game, 0, pos, radius),
                        )
                        assert_records_close(
                            f"{label} {shape_name} touching",
                            actual_touching,
                            reference_touching(module, game, 0, pos, radius),
                        )

                    desktop_ball = ball(shape_azoid.centroid(points), velocity, kind=kind)
                    core_ball = ball(shape_azoid.centroid(points), velocity, kind=kind)
                    desktop.zoids = [desktop_ball]
                    core.zoids = [core_ball]
                    if not desktop.resolve_wall_collision(desktop_ball, 0, desktop_ball["pos"], pos):
                        raise AssertionError(f"desktop {shape_name} corner did not collide")
                    if not core.resolve_wall_collision(core_ball, 0, core_ball["pos"], pos):
                        raise AssertionError(f"core {shape_name} corner did not collide")
                    assert_state_close(
                        f"{shape_name} rotation={rotation} {kind} corner={corner_index}",
                        state(desktop_ball),
                        state(core_ball),
                    )
                    cases += 1
    return cases


def trajectory_parity():
    steps_checked = 0
    for shape_name, sides in SHAPES:
        for rotation in ROTATIONS:
            points = polygon(sides, rotation)
            center = shape_azoid.centroid(points)
            for kind, velocity in (("zoid", (2.73, 1.11)), ("penta", (2.31, -1.07))):
                desktop = game_with(shape_azoid.Game, (points,))
                core = game_with(shape_azoid_core.ShapeAzoidMatch, (points,))
                desktop.zoids = [ball(center, velocity, kind=kind)]
                core.zoids = [ball(center, velocity, kind=kind)]
                for frame in range(240):
                    desktop.update_zoids()
                    core.update_zoids()
                    assert_state_close(
                        f"trajectory {shape_name} rotation={rotation} {kind} frame={frame}",
                        state(desktop.zoids[0]),
                        state(core.zoids[0]),
                    )
                    steps_checked += 1
    return steps_checked


def install_signature_rescan(game):
    original = game.wall_plane_geometry
    previous_signature = None

    def rescanning_wall_plane_geometry():
        nonlocal previous_signature
        signature = tuple(
            (
                id(item),
                tuple((float(point[0]), float(point[1])) for point in item["points"]),
            )
            for item in game.pieces
        )
        if signature != previous_signature:
            previous_signature = signature
            game.invalidate_wall_plane_geometry()
        return original()

    game.wall_plane_geometry = rescanning_wall_plane_geometry


def benchmark_game(factory, piece_count, zoid_count):
    point_sets = tuple(
        square((index % 6) * 120.0, (index // 6) * 120.0)
        for index in range(piece_count)
    )
    game = game_with(factory, point_sets)
    zoids = []
    for index in range(zoid_count):
        piece_idx = index % piece_count
        center = type_module(game).centroid(point_sets[piece_idx])
        angle = 0.37 + index * 0.41
        zoids.append(
            ball(
                center,
                (math.cos(angle) * 2.9, math.sin(angle) * 2.9),
                owner=index % 6,
                piece_idx=piece_idx,
            )
        )
    game.zoids = zoids
    return game


def game_state(game):
    return tuple(
        (
            tuple(round(float(value), 9) for value in zoid["pos"]),
            tuple(round(float(value), 9) for value in zoid["vel"]),
            zoid.get("piece"),
        )
        for zoid in game.zoids
    )


def benchmark_update_case(factory, piece_count, zoid_count):
    signature_game = benchmark_game(factory, piece_count, zoid_count)
    explicit_game = benchmark_game(factory, piece_count, zoid_count)
    install_signature_rescan(signature_game)
    signature_game.wall_plane_geometry()
    explicit_game.wall_plane_geometry()

    iterations = {1: 4000, 6: 2000, 18: 1000, 36: 700}[zoid_count]
    signature_ns = 0
    explicit_ns = 0
    for iteration in range(iterations):
        if iteration % 2 == 0:
            started = time.perf_counter_ns()
            signature_game.update_zoids()
            signature_ns += time.perf_counter_ns() - started
            started = time.perf_counter_ns()
            explicit_game.update_zoids()
            explicit_ns += time.perf_counter_ns() - started
        else:
            started = time.perf_counter_ns()
            explicit_game.update_zoids()
            explicit_ns += time.perf_counter_ns() - started
            started = time.perf_counter_ns()
            signature_game.update_zoids()
            signature_ns += time.perf_counter_ns() - started

    if game_state(signature_game) != game_state(explicit_game):
        raise AssertionError(
            f"update benchmark trajectory changed for pieces={piece_count} zoids={zoid_count}"
        )
    if explicit_ns >= signature_ns:
        raise AssertionError(
            f"explicit invalidation did not improve total update time for "
            f"pieces={piece_count} zoids={zoid_count}: "
            f"{explicit_ns / 1e6:.3f}ms >= {signature_ns / 1e6:.3f}ms"
        )
    return {
        "iterations": iterations,
        "before_ms": signature_ns / 1e6,
        "after_ms": explicit_ns / 1e6,
        "speedup": signature_ns / explicit_ns,
    }


def benchmark_update_matrix():
    results = []
    for label, _, factory in FACTORIES:
        for piece_count in (6, 18, 36):
            for zoid_count in (1, 6, 18, 36):
                result = benchmark_update_case(factory, piece_count, zoid_count)
                results.append((label, piece_count, zoid_count, result))
                print(
                    f"BENCH {label} pieces={piece_count} zoids={zoid_count} "
                    f"updates={result['iterations']} signature={result['before_ms']:.3f}ms "
                    f"explicit={result['after_ms']:.3f}ms speedup={result['speedup']:.3f}x"
                )
    return results


def main():
    for label, module, factory in FACTORIES:
        cache_contract(label, module, factory)
        clean_lookup_is_constant_time(label, factory)
    print("PASS immutable cache reuse and dynamic owner/radius/open-wall behavior")
    print("PASS clean wall-plane lookups perform zero geometry scans")
    print("PASS explicit direct add/remove/replace/reorder/point invalidation")

    real_mutation_paths()
    print("PASS reset, placement, removal, snapshot, and saved-room restore invalidation")

    corner_cases = geometry_and_corner_parity()
    print(f"PASS {corner_cases} corner/radius/rotation geometry and parity cases")

    trajectory_steps = trajectory_parity()
    print(f"PASS {trajectory_steps} desktop/core trajectory steps")

    results = benchmark_update_matrix()
    print(f"PASS explicit invalidation improved all {len(results)} total-update benchmark cases")
    print("RESULT 7/7 wall-plane cache probe groups passed")


if __name__ == "__main__":
    main()
