"""Headless Shape-Azoid core helpers.

This module is intentionally safe for the multiplayer server to import. It must
not import pygame, open windows, load images, initialize sound, or touch the UI.
"""

import math
import random
import time
from collections import Counter


VERSION = "v0.7.33"
MAX_ACTION_LOG = 80
STREAM_ACTION_LOG_LIMIT = 12
BLACK = (8, 10, 16)
WHITE = (238, 243, 250)
NEUTRAL_FILL = (78, 88, 108)

PLAYER_COLORS = [
    ("Red", (225, 58, 64)),
    ("Orange", (242, 133, 44)),
    ("Yellow", (232, 208, 61)),
    ("Green", (65, 177, 92)),
    ("Blue", (66, 133, 235)),
    ("Violet", (147, 93, 214)),
]

CARD_TYPES = ["hex", "pentagon", "square", "triangle", "line", "zoid"]
SHAPE_SIDES = {"triangle": 3, "square": 4, "hex": 6}
SIDE_LEN = 96
ZOID_RADIUS = 9
PENTA_ZOID_RADIUS = 15
WALL_COLLISION_MARGIN = 0.05
WALL_COLLISION_TOLERANCE = 0.00001
WALL_CORRECTION_MAX_PASSES = 64
BOARD_X = 12
BOARD_Y = 82
BOARD_W = 1186
BOARD_H = 656
BOARD_CENTER = (BOARD_X + BOARD_W / 2, BOARD_Y + BOARD_H / 2)
SCREEN_W = 1400
UFO_DRAW_W = 128
UFO_FIRST_DELAY_MS = 30000
UFO_REPEAT_DELAY_MS = 10000
UFO_FLIGHT_MS = 4300
EDGE_CLICK_TOLERANCE = 30
LINE_CLICK_TOLERANCE = 48


def make_card(kind, color_index, wild=False):
    return {"kind": kind, "base_kind": kind, "color": color_index, "wild": wild}


def card_kind(card):
    return card.get("kind", card) if isinstance(card, dict) else card


def card_base_kind(card):
    return card.get("base_kind", card_kind(card)) if isinstance(card, dict) else card


def card_color(card):
    return card.get("color", 0) if isinstance(card, dict) else 0


def card_color_name(card):
    color_index = card_color(card)
    if 0 <= color_index < len(PLAYER_COLORS):
        return PLAYER_COLORS[color_index][0]
    return "Color"


def color_index_rgb(color_index):
    if color_index is not None and 0 <= color_index < len(PLAYER_COLORS):
        return PLAYER_COLORS[color_index][1]
    return NEUTRAL_FILL


def card_rgb(card):
    return color_index_rgb(card_color(card))


def card_label(card):
    return f"{card_color_name(card)} {card_kind(card)}"


def card_key(card):
    return (card_kind(card), card_color(card))


def base_card_key(card):
    return (card_base_kind(card), card_color(card))


def is_wild(card):
    return isinstance(card, dict) and card.get("wild", False)


def cycle_wild_card(card):
    if not is_wild(card):
        return False
    current = card_kind(card)
    idx = CARD_TYPES.index(current) if current in CARD_TYPES else 0
    card["kind"] = CARD_TYPES[(idx + 1) % len(CARD_TYPES)]
    return True


def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def midpoint(a, b):
    return ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)


def polygon_area(points):
    total = 0
    for i, p in enumerate(points):
        q = points[(i + 1) % len(points)]
        total += p[0] * q[1] - q[0] * p[1]
    return total / 2


def ensure_ccw(points):
    return points if polygon_area(points) > 0 else list(reversed(points))


def centroid(points):
    return (sum(p[0] for p in points) / len(points), sum(p[1] for p in points) / len(points))


def side_list(points):
    return [(points[i], points[(i + 1) % len(points)]) for i in range(len(points))]


def edge_key(a, b, precision=2):
    a2 = (round(a[0], precision), round(a[1], precision))
    b2 = (round(b[0], precision), round(b[1], precision))
    return tuple(sorted([a2, b2]))


def regular_polygon(center, radius, sides, rotation=0):
    cx, cy = center
    return ensure_ccw([
        (
            cx + math.cos(rotation + 2 * math.pi * i / sides) * radius,
            cy + math.sin(rotation + 2 * math.pi * i / sides) * radius,
        )
        for i in range(sides)
    ])


def point_in_polygon(point, polygon):
    x, y = point
    inside = False
    n = len(polygon)
    j = n - 1
    for i in range(n):
        xi, yi = polygon[i]
        xj, yj = polygon[j]
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) or 0.00001) + xi):
            inside = not inside
        j = i
    return inside


def point_segment_distance(p, a, b):
    ax, ay = a
    bx, by = b
    px, py = p
    dx, dy = bx - ax, by - ay
    denom = dx * dx + dy * dy
    if denom == 0:
        return dist(p, a), a
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / denom))
    q = (ax + t * dx, ay + t * dy)
    return dist(p, q), q


def weighted_edge_click_score(p, a, b, max_distance=EDGE_CLICK_TOLERANCE):
    d, _ = point_segment_distance(p, a, b)
    if d > max_distance:
        return None
    return d + dist(p, midpoint(a, b)) * 0.04


def project_polygon(points, axis):
    values = [p[0] * axis[0] + p[1] * axis[1] for p in points]
    return min(values), max(values)


def polygon_edges(points):
    return [(points[i], points[(i + 1) % len(points)]) for i in range(len(points))]


def polygons_overlap(poly_a, poly_b, eps=0.8):
    # Convex SAT test. Edge/point touching is allowed; real area overlap is not.
    for poly in (poly_a, poly_b):
        for a, b in polygon_edges(poly):
            ex, ey = b[0] - a[0], b[1] - a[1]
            length = math.hypot(ex, ey)
            if length == 0:
                continue
            axis = (-ey / length, ex / length)
            min_a, max_a = project_polygon(poly_a, axis)
            min_b, max_b = project_polygon(poly_b, axis)
            if min(max_a, max_b) - max(min_a, min_b) <= eps:
                return False
    return True


def polygon_from_shared_edge(a, b, sides_count, current_center, side_len_override=None):
    side_len = side_len_override if side_len_override is not None else dist(a, b)
    mx, my = midpoint(a, b)
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    edge_len_actual = math.hypot(dx, dy) or 0.00001
    edge_angle = math.atan2(dy, dx)
    apothem = side_len / (2 * math.tan(math.pi / sides_count))
    nx1, ny1 = -dy / edge_len_actual, dx / edge_len_actual
    nx2, ny2 = dy / edge_len_actual, -dx / edge_len_actual
    c1 = (mx + nx1 * apothem, my + ny1 * apothem)
    c2 = (mx + nx2 * apothem, my + ny2 * apothem)
    center = c1 if dist(c1, current_center) > dist(c2, current_center) else c2
    radius = side_len / (2 * math.sin(math.pi / sides_count))
    pts = regular_polygon(center, radius, sides_count, edge_angle - math.pi / 2 + math.pi / sides_count)

    best_i = 0
    best_score = float("inf")
    for i in range(len(pts)):
        p1 = pts[i]
        p2 = pts[(i + 1) % len(pts)]
        score = min(dist(p1, a) + dist(p2, b), dist(p1, b) + dist(p2, a))
        if score < best_score:
            best_i = i
            best_score = score
    return ensure_ccw(pts[best_i:] + pts[:best_i])


def build_points_for_shape(shape_name, a=None, b=None, current_center=None, board_center=BOARD_CENTER):
    sides_count = SHAPE_SIDES[shape_name]
    if a is None or b is None:
        radius = SIDE_LEN / (2 * math.sin(math.pi / sides_count))
        return regular_polygon(board_center, radius, sides_count, -math.pi / 2)
    if shape_name == "triangle":
        side_len = dist(a, b)
        mx, my = midpoint(a, b)
        dx, dy = b[0] - a[0], b[1] - a[1]
        edge_len = math.hypot(dx, dy) or 0.00001
        h = math.sqrt(3) / 2 * side_len
        nx1, ny1 = -dy / edge_len, dx / edge_len
        nx2, ny2 = dy / edge_len, -dx / edge_len
        p1 = (mx + nx1 * h, my + ny1 * h)
        p2 = (mx + nx2 * h, my + ny2 * h)
        p3 = p1 if dist(p1, current_center) > dist(p2, current_center) else p2
        return ensure_ccw([a, b, p3])
    return polygon_from_shared_edge(a, b, sides_count, current_center)


def reflect_velocity(vx, vy, a, b):
    ex, ey = b[0] - a[0], b[1] - a[1]
    length = math.hypot(ex, ey) or 0.00001
    tx, ty = ex / length, ey / length
    nx, ny = -ty, tx
    dot = vx * nx + vy * ny
    return vx - 2 * dot * nx, vy - 2 * dot * ny


def inward_edge_normal(a, b, center):
    ex, ey = b[0] - a[0], b[1] - a[1]
    length = math.hypot(ex, ey) or 0.00001
    nx, ny = -ey / length, ex / length
    mx, my = midpoint(a, b)
    if (center[0] - mx) * nx + (center[1] - my) * ny < 0:
        nx, ny = -nx, -ny
    return nx, ny


def reflect_velocity_from_normal(vx, vy, nx, ny):
    dot = vx * nx + vy * ny
    return vx - 2 * dot * nx, vy - 2 * dot * ny


def valid_contact_velocity(vx, vy, inward_normals, tolerance=WALL_COLLISION_TOLERANCE):
    normals_by_key = {}
    for nx, ny in inward_normals:
        length = math.hypot(nx, ny)
        if length <= 0.000000001:
            continue
        normal = (nx / length, ny / length)
        normals_by_key[(round(normal[0], 12), round(normal[1], 12))] = normal
    normals = [normals_by_key[key] for key in sorted(normals_by_key)]
    speed = math.hypot(vx, vy)
    if speed <= 0.000000001 or not normals:
        return vx, vy

    incoming = [normal for normal in normals if vx * normal[0] + vy * normal[1] < -tolerance]
    if len(incoming) == 1:
        preferred = reflect_velocity_from_normal(vx, vy, incoming[0][0], incoming[0][1])
    elif len(incoming) >= 2:
        preferred = (-vx, -vy)
    else:
        preferred = (vx, vy)

    def direction_is_valid(direction):
        return all(
            direction[0] * nx + direction[1] * ny >= -tolerance
            for nx, ny in normals
        )

    if direction_is_valid(preferred):
        return preferred

    preferred_length = math.hypot(*preferred)
    preferred_unit = (preferred[0] / preferred_length, preferred[1] / preferred_length)
    candidates = {}

    def add_candidate(x, y):
        length = math.hypot(x, y)
        if length <= 0.000000001:
            return
        direction = (x / length, y / length)
        if not direction_is_valid(direction):
            return
        candidates[(round(direction[0], 12), round(direction[1], 12))] = direction

    for nx, ny in normals:
        add_candidate(-ny, nx)
        add_candidate(ny, -nx)

    for mask in range(1, 1 << len(normals)):
        sum_x = sum(normal[0] for index, normal in enumerate(normals) if mask & (1 << index))
        sum_y = sum(normal[1] for index, normal in enumerate(normals) if mask & (1 << index))
        add_candidate(sum_x, sum_y)

    if not candidates:
        raise ValueError("Contact normals do not admit a speed-preserving feasible direction.")
    direction = min(
        candidates.values(),
        key=lambda item: (
            -round(item[0] * preferred_unit[0] + item[1] * preferred_unit[1], 12),
            round(item[0], 12),
            round(item[1], 12),
        ),
    )
    result = (direction[0] * speed, direction[1] * speed)
    if not direction_is_valid(result):
        raise ValueError("Contact response did not satisfy every wall constraint.")
    return result


def blend(a, b, t):
    return (
        int(a[0] * (1 - t) + b[0] * t),
        int(a[1] * (1 - t) + b[1] * t),
        int(a[2] * (1 - t) + b[2] * t),
    )


def brighten(color, amount=0.25):
    return blend(color, WHITE, amount)


def darken(color, amount=0.35):
    return blend(color, BLACK, amount)


def readable_text_color(bg):
    brightness = bg[0] * 0.299 + bg[1] * 0.587 + bg[2] * 0.114
    return BLACK if brightness > 150 else WHITE


class ShapeAzoidMatch:
    """Serializable server-side match state.

    This is the multiplayer server's replacement for constructing the Pygame
    desktop Game during room start. Keep this class free of display, sound, and
    image concerns.
    """

    def __init__(self, player_count=2, ai_players=None, seat_configs=None, player_color_indices=None):
        self.mode = "setup"
        self.player_count = max(1, min(6, int(player_count or 2)))
        self.ai_players = set(ai_players or [])
        self.player_color_indices = list(player_color_indices or range(len(PLAYER_COLORS)))
        self.players = []
        self.deck = []
        self.discard = []
        self.hands = []
        self.pieces = []
        self.zoids = []
        self.next_zoid_id = 1
        self.open_walls = set()
        self._wall_plane_geometry_version = 0
        self._wall_plane_cache_version = -1
        self._wall_plane_cache = ()
        self.current_player = 0
        self.selected_card = None
        self.cards_used_this_turn = 0
        self.discarded_this_turn = False
        self.last_card_drawn = False
        self.no_discard_turns_after_empty = 0
        self.state_revision = 0
        self.action_log = []
        self.round_scores = [0] * self.player_count
        self.total_scores = [0] * self.player_count
        self.round_light_scores = [0] * self.player_count
        self.last_score_breakdown = []
        self.round_slots = []
        self.round_wild_kind = None
        self.turn_started_at = 0
        self.next_ufo_at = 0
        self.ufo_flight_index = 0
        self.active_ufo = None
        self.explosions = []
        self.message = "Waiting for the host to start."
        self.configure_players(seat_configs or [])

    def ensure_color_choices(self):
        used = []
        for color_idx in self.player_color_indices:
            if color_idx not in used and 0 <= color_idx < len(PLAYER_COLORS):
                used.append(color_idx)
        for color_idx in range(len(PLAYER_COLORS)):
            if color_idx not in used:
                used.append(color_idx)
        self.player_color_indices = used[:len(PLAYER_COLORS)]

    def configure_players(self, seat_configs):
        self.ensure_color_choices()
        self.players = []
        for idx in range(self.player_count):
            seat = seat_configs[idx] if idx < len(seat_configs) else {}
            color_idx = int(seat.get("color_index", self.player_color_indices[idx]))
            if not (0 <= color_idx < len(PLAYER_COLORS)):
                color_idx = self.player_color_indices[idx]
            self.players.append({
                "name": seat.get("name") or PLAYER_COLORS[color_idx][0],
                "color_name": PLAYER_COLORS[color_idx][0],
                "color": PLAYER_COLORS[color_idx][1],
                "color_index": color_idx,
            })
        self.player_color_indices = [player["color_index"] for player in self.players] + [
            idx for idx in range(len(PLAYER_COLORS))
            if idx not in {player["color_index"] for player in self.players}
        ]
        self.ai_players = {
            idx for idx, seat in enumerate(seat_configs[:self.player_count])
            if seat.get("is_ai")
        } | {idx for idx in self.ai_players if 0 <= idx < self.player_count}

    @property
    def current(self):
        return self.players[self.current_player]

    @property
    def current_color_index(self):
        return self.players[self.current_player]["color_index"]

    def current_is_ai(self):
        return self.current_player in self.ai_players

    @staticmethod
    def valid_zoid_id(value):
        return isinstance(value, int) and not isinstance(value, bool) and value > 0

    def ensure_zoid_ids(self):
        """Preserve valid IDs and backfill missing/duplicate IDs from old state."""
        seen = set()
        needs_id = []
        for zoid in self.zoids:
            zoid_id = zoid.get("zoid_id")
            if self.valid_zoid_id(zoid_id) and zoid_id not in seen:
                seen.add(zoid_id)
            else:
                needs_id.append(zoid)

        next_id = self.next_zoid_id if self.valid_zoid_id(self.next_zoid_id) else 1
        if seen:
            next_id = max(next_id, max(seen) + 1)
        for zoid in needs_id:
            while next_id in seen:
                next_id += 1
            zoid["zoid_id"] = next_id
            seen.add(next_id)
            next_id += 1
        self.next_zoid_id = next_id

    def allocate_zoid_id(self):
        self.ensure_zoid_ids()
        zoid_id = self.next_zoid_id
        self.next_zoid_id += 1
        return zoid_id

    def reset_match_sync_state(self):
        self.state_revision = 0
        self.action_log = []

    def record_action(self, actor, command_type, payload):
        self.state_revision += 1
        self.action_log.append({
            "revision": self.state_revision,
            "actor": actor,
            "type": command_type,
            "payload": payload,
            "message": self.message,
        })
        if len(self.action_log) > MAX_ACTION_LOG:
            self.action_log = self.action_log[-MAX_ACTION_LOG:]

    def build_round_deck(self):
        deck = []
        for color_index in range(len(PLAYER_COLORS)):
            for kind in CARD_TYPES:
                deck.append(make_card(kind, color_index, wild=(kind == self.round_wild_kind)))
        for slot_idx, extra_sets in ((0, 1), (1, 2)):
            kind = self.round_slots[slot_idx]
            for _ in range(extra_sets):
                for color_index in range(len(PLAYER_COLORS)):
                    deck.append(make_card(kind, color_index, wild=(kind == self.round_wild_kind)))
        return deck

    def reset_round(self, carry_hands=False):
        carried_hands = [[] for _ in range(self.player_count)]
        if carry_hands:
            for i in range(min(self.player_count, len(self.hands))):
                carried_hands[i] = [dict(card) for card in self.hands[i]]
        self.round_slots = [random.choice(CARD_TYPES) for _ in range(3)]
        self.round_wild_kind = self.round_slots[2]
        self.deck = self.build_round_deck()
        for hand in carried_hands:
            for card in hand:
                card["kind"] = card_base_kind(card)
                card["wild"] = card_base_kind(card) == self.round_wild_kind
        carried_counts = Counter(base_card_key(card) for hand in carried_hands for card in hand)
        if carried_counts:
            kept_deck = []
            for card in self.deck:
                key = base_card_key(card)
                if carried_counts[key] > 0:
                    carried_counts[key] -= 1
                else:
                    kept_deck.append(card)
            self.deck = kept_deck
        random.shuffle(self.deck)
        self.discard = []
        self.hands = carried_hands
        self.pieces = []
        self.zoids = []
        self.open_walls = set()
        self.invalidate_wall_plane_geometry()
        self.current_player = 0
        self.selected_card = None
        self.cards_used_this_turn = 0
        self.discarded_this_turn = False
        self.last_card_drawn = False
        self.no_discard_turns_after_empty = 0
        self.round_scores = [0] * self.player_count
        self.round_light_scores = [0] * self.player_count
        self.last_score_breakdown = []
        for i in range(self.player_count):
            self.draw_to_five(i)

    def start(self):
        self.reset_match_sync_state()
        self.reset_round()
        self.mode = "playing"
        self.reset_ufo_turn_timer()
        self.message = f"{self.current['name']} takes the first turn."

    def start_next_round(self):
        if self.mode != "score":
            return {"ok": False, "error": "The round has not been scored yet."}
        self.action_log = []
        self.reset_round(carry_hands=True)
        self.mode = "playing"
        self.reset_ufo_turn_timer()
        self.message = f"New round. {self.current['name']} takes the first turn."
        return {"ok": True, "revision": self.state_revision, "message": self.message}

    def now_ms(self):
        return int(time.monotonic() * 1000)

    def reset_ufo_turn_timer(self, now=None):
        now = self.now_ms() if now is None else int(now)
        self.turn_started_at = now
        self.next_ufo_at = now + UFO_FIRST_DELAY_MS
        self.ufo_flight_index = 0
        self.active_ufo = None
        self.explosions = []

    def draw_to_five(self, player_idx):
        while len(self.hands[player_idx]) < 5 and self.deck:
            self.hands[player_idx].append(self.deck.pop())
        if self.mode == "playing" and not self.deck:
            self.last_card_drawn = True

    def player_index_for_color(self, color_index):
        for idx, player in enumerate(self.players):
            if player.get("color_index") == color_index:
                return idx
        return None

    def piece_at(self, pos):
        for idx in range(len(self.pieces) - 1, -1, -1):
            if point_in_polygon(pos, self.pieces[idx]["points"]):
                return idx
        return None

    def piece_at_with_hint(self, pos, piece_idx):
        if (
            isinstance(piece_idx, int)
            and 0 <= piece_idx < len(self.pieces)
            and point_in_polygon(pos, self.pieces[piece_idx]["points"])
        ):
            return piece_idx
        return self.piece_at(pos)

    def shared_edges(self):
        edges = {}
        for pi, piece in enumerate(self.pieces):
            for si, (a, b) in enumerate(side_list(piece["points"])):
                edges.setdefault(edge_key(a, b), []).append((pi, si, a, b))
        return edges

    def exposed_edges(self):
        return {k for k, v in self.shared_edges().items() if len(v) == 1}

    def find_clicked_exposed_side(self, pos):
        exposed = self.exposed_edges()
        best = (None, None, float("inf"))
        for pi, piece in enumerate(self.pieces):
            for si, (a, b) in enumerate(side_list(piece["points"])):
                k = edge_key(a, b)
                if k not in exposed:
                    continue
                score = weighted_edge_click_score(pos, a, b)
                if score is not None and score < best[2]:
                    best = (pi, si, score)
        if best[0] is not None:
            return best[0], best[1]
        inside_piece = self.piece_at(pos)
        if inside_piece is not None:
            for si, (a, b) in enumerate(side_list(self.pieces[inside_piece]["points"])):
                if edge_key(a, b) not in exposed:
                    continue
                score = point_segment_distance(pos, a, b)[0]
                if score < best[2]:
                    best = (inside_piece, si, score)
        return best[0], best[1]

    def shape_candidate(self, shape, pos):
        if self.pieces:
            pi, si = self.find_clicked_exposed_side(pos)
            if pi is None:
                return None, None
            a, b = side_list(self.pieces[pi]["points"])[si]
            return build_points_for_shape(shape, a, b, centroid(self.pieces[pi]["points"])), pi
        return build_points_for_shape(shape), None

    def point_in_board(self, point):
        return BOARD_X <= point[0] <= BOARD_X + BOARD_W and BOARD_Y <= point[1] <= BOARD_Y + BOARD_H

    def shape_fits(self, points):
        if any(not self.point_in_board(p) for p in points):
            return False
        return not any(polygons_overlap(points, piece["points"]) for piece in self.pieces)

    def count_lit_connections(self, piece_idx):
        piece = self.pieces[piece_idx]
        shared = self.shared_edges()
        total = 0
        for a, b in side_list(piece["points"]):
            key = edge_key(a, b)
            if key not in self.open_walls:
                continue
            entries = shared.get(key, [])
            if len(entries) != 2:
                continue
            other_idx = entries[0][0] if entries[1][0] == piece_idx else entries[1][0]
            if self.pieces[other_idx].get("owner") == piece.get("owner"):
                total += 1
        return total

    def find_clicked_shared_wall(self, pos):
        best = (None, float("inf"))
        for key, entries in self.shared_edges().items():
            if len(entries) != 2 or key in self.open_walls:
                continue
            _, _, a, b = entries[0]
            score = weighted_edge_click_score(pos, a, b, max_distance=LINE_CLICK_TOLERANCE)
            if score is not None and score < best[1]:
                best = (key, score)
        return best[0]

    def line_click_diagnostics(self, pos):
        def point_data(point):
            return [round(float(point[0]), 3), round(float(point[1]), 3)]

        shared = self.shared_edges()
        nearest = None
        shared_count = 0
        open_count = 0
        closed_count = 0
        for key, entries in shared.items():
            if len(entries) != 2:
                continue
            shared_count += 1
            is_open = key in self.open_walls
            if is_open:
                open_count += 1
            else:
                closed_count += 1
            _, _, a, b = entries[0]
            distance, closest = point_segment_distance(pos, a, b)
            score = weighted_edge_click_score(pos, a, b, max_distance=LINE_CLICK_TOLERANCE)
            pieces = []
            for piece_idx, side_idx, _, _ in entries:
                piece = self.pieces[piece_idx]
                pieces.append({
                    "piece": piece_idx,
                    "side": side_idx,
                    "shape": piece.get("shape"),
                    "owner": piece.get("owner"),
                    "played_by": piece.get("played_by"),
                })
            candidate = {
                "wall": [point_data(point) for point in key],
                "distance": round(float(distance), 3),
                "weighted_score": round(float(score), 3) if score is not None else None,
                "within_tolerance": score is not None,
                "is_open": bool(is_open),
                "closest": point_data(closest),
                "midpoint": point_data(midpoint(a, b)),
                "pieces": pieces,
            }
            if nearest is None or candidate["distance"] < nearest["distance"]:
                nearest = candidate
        return {
            "click": point_data(pos),
            "line_tolerance": LINE_CLICK_TOLERANCE,
            "pieces": len(self.pieces),
            "open_walls": len(self.open_walls),
            "shared_walls": shared_count,
            "open_shared_walls": open_count,
            "closed_shared_walls": closed_count,
            "nearest_shared_wall": nearest,
            "target_found": bool(nearest and nearest["within_tolerance"] and not nearest["is_open"]),
        }

    def play_line(self, pos):
        wall = self.find_clicked_shared_wall(pos)
        if wall is None:
            self.message = "Line cards remove only a shared wall between two shapes."
            return False
        self.open_walls.add(wall)
        self.message = f"{self.current['name']} opened a wall."
        return True

    def play_ball(self, pos, kind, color_index):
        piece_idx = self.piece_at(pos)
        if piece_idx is None:
            self.message = "Click inside a matching colored shape to place the ball."
            return False
        if self.pieces[piece_idx]["owner"] != color_index:
            self.message = f"You can only place that ball on {PLAYER_COLORS[color_index][0]}."
            return False
        angle = random.random() * math.tau
        speed = 2.9 if kind == "zoid" else 2.55
        self.zoids.append({
            "zoid_id": self.allocate_zoid_id(),
            "pos": [float(pos[0]), float(pos[1])],
            "vel": [math.cos(angle) * speed, math.sin(angle) * speed],
            "owner": color_index,
            "played_by": self.current_player,
            "piece": piece_idx,
            "kind": kind,
            "visited": {piece_idx},
        })
        self.pieces[piece_idx]["owner"] = color_index
        ball_name = "Penta-Zoid" if kind == "penta" else "zoid"
        self.message = f"{self.current['name']} placed a {PLAYER_COLORS[color_index][0]} {ball_name}."
        return True

    def owner_region(self, start_piece):
        seen = {start_piece}
        queue = [start_piece]
        shared = self.shared_edges()
        while queue:
            piece_idx = queue.pop(0)
            for a, b in side_list(self.pieces[piece_idx]["points"]):
                key = edge_key(a, b)
                if key not in self.open_walls:
                    continue
                for other_idx, _, _, _ in shared.get(key, []):
                    if other_idx != piece_idx and other_idx not in seen:
                        seen.add(other_idx)
                        queue.append(other_idx)
        return seen

    def ball_radius(self, zoid):
        return PENTA_ZOID_RADIUS if zoid.get("kind") == "penta" else ZOID_RADIUS

    def invalidate_wall_plane_geometry(self):
        """Mark wall planes dirty after changing the piece list or point geometry."""
        self._wall_plane_geometry_version += 1

    def wall_plane_geometry(self):
        if self._wall_plane_cache_version == self._wall_plane_geometry_version:
            return self._wall_plane_cache

        planes = []
        for piece in self.pieces:
            points = piece["points"]
            center = centroid(points)
            piece_planes = []
            for a, b in side_list(points):
                nx, ny = inward_edge_normal(a, b, center)
                mx, my = midpoint(a, b)
                piece_planes.append((edge_key(a, b), nx, ny, mx, my))
            planes.append(tuple(piece_planes))
        self._wall_plane_cache = tuple(planes)
        self._wall_plane_cache_version = self._wall_plane_geometry_version
        return self._wall_plane_cache

    def wall_contacts(self, piece_idx, pos, radius, piece_planes=None):
        if piece_planes is None:
            piece_planes = self.wall_plane_geometry()[piece_idx]
        contacts = []
        for key, nx, ny, mx, my in piece_planes:
            if key in self.open_walls:
                continue
            clearance = (pos[0] - mx) * nx + (pos[1] - my) * ny
            penetration = radius + WALL_COLLISION_MARGIN - clearance
            if penetration > WALL_COLLISION_TOLERANCE:
                contacts.append((key, nx, ny, mx, my, penetration))
        return contacts

    def touching_wall_normals(self, piece_idx, pos, radius, piece_planes=None):
        if piece_planes is None:
            piece_planes = self.wall_plane_geometry()[piece_idx]
        target = radius + WALL_COLLISION_MARGIN
        normals = []
        for key, nx, ny, mx, my in piece_planes:
            if key in self.open_walls:
                continue
            clearance = (pos[0] - mx) * nx + (pos[1] - my) * ny
            if clearance <= target + WALL_COLLISION_TOLERANCE:
                normals.append((key, nx, ny))
        return normals

    def resolve_wall_collision(self, zoid, piece_idx, old_pos, attempted_pos=None, wall_planes=None):
        if not (0 <= piece_idx < len(self.pieces)):
            return False
        if wall_planes is None:
            wall_planes = self.wall_plane_geometry()
        piece_planes = wall_planes[piece_idx]
        radius = self.ball_radius(zoid)
        probe = attempted_pos or old_pos
        contacts = self.wall_contacts(piece_idx, probe, radius, piece_planes)
        if not contacts:
            return False

        fixed_pos = [float(probe[0]), float(probe[1])]
        contact_normals = {contact[0]: (contact[1], contact[2]) for contact in contacts}
        for _ in range(WALL_CORRECTION_MAX_PASSES):
            corrections = sorted(
                self.wall_contacts(piece_idx, fixed_pos, radius, piece_planes),
                key=lambda contact: (
                    round(math.atan2(contact[2], contact[1]), 12),
                    contact[0],
                ),
            )
            if not corrections:
                break
            corrected = False
            for contact in corrections:
                key, nx, ny, mx, my, _ = contact
                clearance = (fixed_pos[0] - mx) * nx + (fixed_pos[1] - my) * ny
                penetration = radius + WALL_COLLISION_MARGIN - clearance
                if penetration <= WALL_COLLISION_TOLERANCE:
                    continue
                contact_normals.setdefault(key, (nx, ny))
                fixed_pos[0] += nx * penetration
                fixed_pos[1] += ny * penetration
                corrected = True
            if not corrected:
                break

        for key, nx, ny in self.touching_wall_normals(piece_idx, fixed_pos, radius, piece_planes):
            contact_normals.setdefault(key, (nx, ny))
        incoming_velocity = (zoid["vel"][0], zoid["vel"][1])
        zoid["vel"][0], zoid["vel"][1] = valid_contact_velocity(
            incoming_velocity[0], incoming_velocity[1], contact_normals.values()
        )

        zoid["pos"][0], zoid["pos"][1] = fixed_pos
        zoid["piece"] = piece_idx
        return True

    def update_zoids(self):
        wall_planes = self.wall_plane_geometry() if self.pieces else ()
        for zoid in self.zoids:
            if not self.pieces:
                continue
            speed = math.hypot(zoid["vel"][0], zoid["vel"][1])
            steps = max(1, int(math.ceil(speed / 1.0)))
            step_vel = (zoid["vel"][0] / steps, zoid["vel"][1] / steps)
            for _ in range(steps):
                old_pos = tuple(zoid["pos"])
                old_piece = self.piece_at_with_hint(old_pos, zoid.get("piece"))
                if old_piece is None:
                    break
                zoid["piece"] = old_piece
                new_pos = (zoid["pos"][0] + step_vel[0], zoid["pos"][1] + step_vel[1])
                if self.resolve_wall_collision(zoid, old_piece, old_pos, new_pos, wall_planes):
                    break
                new_piece = self.piece_at_with_hint(new_pos, old_piece)
                if new_piece is None:
                    zoid["pos"][0], zoid["pos"][1] = old_pos
                    zoid["piece"] = old_piece
                    break
                if new_piece == old_piece or new_piece in self.owner_region(old_piece):
                    zoid["pos"][0], zoid["pos"][1] = new_pos
                    zoid["piece"] = new_piece
                    zoid.setdefault("visited", set()).add(new_piece)
                    self.pieces[new_piece]["owner"] = zoid["owner"]
                else:
                    zoid["pos"][0], zoid["pos"][1] = old_pos
                    zoid["piece"] = old_piece
                    break
        self.resolve_ball_collisions()

    def resolve_ball_collisions(self):
        remove = set()
        for i, a in enumerate(self.zoids):
            if i in remove or a.get("kind") != "penta":
                continue
            for j, b in enumerate(self.zoids):
                if i == j or j in remove:
                    continue
                touch_dist = self.ball_radius(a) + self.ball_radius(b)
                if dist(a["pos"], b["pos"]) > touch_dist:
                    continue
                if b.get("kind") == "penta":
                    remove.add(i)
                    remove.add(j)
                    break
                remove.add(j)
        if remove:
            self.zoids = [zoid for idx, zoid in enumerate(self.zoids) if idx not in remove]

    def place_shape(self, shape, color_index, pos):
        points, _ = self.shape_candidate(shape, pos)
        if points is None:
            self.message = "Click the side you want to attach to."
            return False
        if not self.shape_fits(points):
            self.message = "That shape overlaps another shape. Pick a different side."
            return False
        self.pieces.append({
            "shape": shape,
            "points": points,
            "owner": color_index,
            "played_by": self.current_player,
        })
        self.invalidate_wall_plane_geometry()
        self.message = f"{self.current['name']} placed a {PLAYER_COLORS[color_index][0]} {shape}."
        return True

    def score_round(self, include_control=True):
        return [sum(parts.values()) for parts in self.score_breakdown(include_control=include_control)]

    def circuit_score_breakdown(self):
        lights = [0] * self.player_count
        for key, entries in self.shared_edges().items():
            if key not in self.open_walls or len(entries) != 2:
                continue
            first_idx = entries[0][0]
            second_idx = entries[1][0]
            first_owner = self.pieces[first_idx].get("owner")
            if first_owner != self.pieces[second_idx].get("owner"):
                continue
            owner_idx = self.player_index_for_color(first_owner)
            if owner_idx is not None:
                lights[owner_idx] += 1
        return lights

    def score_breakdown(self, include_control=True):
        circuit_scores = self.circuit_score_breakdown()
        breakdown = [
            {
                "placed": 0,
                "color": 0,
                "zoid": 0,
                "penta": 0,
                "lights": circuit_scores[i] if i < len(circuit_scores) else 0,
            }
            for i in range(self.player_count)
        ]
        for piece in self.pieces:
            if "played_by" in piece:
                placed_idx = piece["played_by"]
                placed_idx = placed_idx if placed_idx is not None and 0 <= placed_idx < self.player_count else None
            else:
                placed_owner = piece.get("placed_owner", piece.get("owner"))
                placed_idx = self.player_index_for_color(placed_owner)
            if placed_idx is not None:
                breakdown[placed_idx]["placed"] += 1
            owner_idx = self.player_index_for_color(piece.get("owner"))
            if include_control and owner_idx is not None:
                breakdown[owner_idx]["color"] += 2
        for zoid in self.zoids:
            owner_idx = self.player_index_for_color(zoid.get("owner"))
            if owner_idx is None:
                played_by = zoid.get("played_by")
                owner_idx = played_by if played_by is not None and 0 <= played_by < self.player_count else None
            if owner_idx is None:
                continue
            if zoid.get("kind") == "penta":
                breakdown[owner_idx]["penta"] += 3
            else:
                breakdown[owner_idx]["zoid"] += 2
        return breakdown

    def finish_round(self):
        self.last_score_breakdown = self.score_breakdown()
        self.round_scores = [sum(parts.values()) for parts in self.last_score_breakdown]
        if len(self.total_scores) != self.player_count:
            self.total_scores = [0] * self.player_count
        for idx, score in enumerate(self.round_scores):
            self.total_scores[idx] += score
        self.selected_card = None
        self.mode = "score"
        self.message = "No-discard cycle complete. Round scored."

    def advance_turn(self):
        if self.last_card_drawn:
            if self.discarded_this_turn:
                self.no_discard_turns_after_empty = 0
            else:
                self.no_discard_turns_after_empty += 1
            if self.no_discard_turns_after_empty >= self.player_count:
                self.finish_round()
                return
        self.current_player = (self.current_player + 1) % self.player_count
        self.draw_to_five(self.current_player)
        if self.mode == "score":
            return
        self.selected_card = None
        self.cards_used_this_turn = 0
        self.discarded_this_turn = False
        self.reset_ufo_turn_timer()
        self.message = f"{self.current['name']}'s turn. Play up to {len(self.hands[self.current_player])} cards."

    def apply_player_command(self, command, actor=None, record=True):
        command_type = command.get("type") if isinstance(command, dict) else None
        actor = self.current_player if actor is None else actor
        def command_card_index():
            raw = command.get("card_index", -1)
            if raw is None:
                return None
            try:
                return int(raw)
            except (TypeError, ValueError):
                return -1

        if self.mode != "playing":
            return {"ok": False, "error": "Game is not in playing mode."}
        if actor != self.current_player:
            return {"ok": False, "error": "It is not that player's turn."}

        payload = {}
        extra = {}
        if command_type == "play_at":
            card_index = command_card_index()
            if card_index is None:
                return {"ok": False, "error": "Select a card first."}
            pos = command.get("pos")
            if not (0 <= card_index < len(self.hands[self.current_player])):
                return {"ok": False, "error": "Card index is not in the current hand."}
            if not pos or len(pos) != 2:
                return {"ok": False, "error": "Play command needs a board position."}
            card = self.hands[self.current_player][card_index]
            kind = card_kind(card)
            color_index = card_color(card)
            if kind in SHAPE_SIDES:
                ok = self.place_shape(kind, color_index, (float(pos[0]), float(pos[1])))
            elif kind == "line":
                line_debug = self.line_click_diagnostics((float(pos[0]), float(pos[1])))
                ok = self.play_line((float(pos[0]), float(pos[1])))
                extra["line_debug"] = line_debug
            elif kind == "zoid":
                ok = self.play_ball((float(pos[0]), float(pos[1])), "zoid", color_index)
            elif kind == "pentagon":
                ok = self.play_ball((float(pos[0]), float(pos[1])), "penta", color_index)
            else:
                return {"ok": False, "error": "That card type is not headless yet."}
            if not ok:
                return {"ok": False, "error": self.message, **extra}
            self.hands[self.current_player].pop(card_index)
            self.cards_used_this_turn += 1
            payload = {"card_index": card_index, "pos": [round(float(pos[0]), 3), round(float(pos[1]), 3)]}
            if "line_debug" in extra:
                payload["line_debug"] = extra["line_debug"]
        elif command_type == "discard":
            card_index = command_card_index()
            if card_index is None:
                return {"ok": False, "error": "Select a card first."}
            if not (0 <= card_index < len(self.hands[self.current_player])):
                return {"ok": False, "error": "Card index is not in the current hand."}
            card = self.hands[self.current_player].pop(card_index)
            self.deck.append(card)
            random.shuffle(self.deck)
            self.cards_used_this_turn += 1
            self.discarded_this_turn = True
            payload = {"card_index": card_index}
            self.message = f"{self.current['name']} discarded {card_label(card)}."
        elif command_type == "cycle_wild":
            card_index = command_card_index()
            if card_index is None:
                return {"ok": False, "error": "Select a card first."}
            if not (0 <= card_index < len(self.hands[self.current_player])):
                return {"ok": False, "error": "Card index is not in the current hand."}
            card = self.hands[self.current_player][card_index]
            ok = cycle_wild_card(card)
            if not ok:
                return {"ok": False, "error": "Only wild cards can change shape."}
            payload = {"card_index": card_index, "kind": card_kind(card)}
            self.message = f"Wild card changed to {card_label(card)}."
        elif command_type == "end_turn":
            self.advance_turn()
        else:
            return {"ok": False, "error": f"Unknown command type: {command_type}"}

        if record:
            self.record_action(actor, command_type, payload)
        return {"ok": True, "revision": self.state_revision, "message": self.message, **extra}

    def choose_ufo_target(self):
        owned = [
            idx for idx, piece in enumerate(self.pieces)
            if piece.get("owner") == self.current_color_index
        ]
        return random.choice(owned) if owned else None

    def start_ufo_flight(self, now):
        lane_cycle = (
            BOARD_Y + BOARD_H * 0.18,
            BOARD_Y + BOARD_H * 0.82,
            BOARD_Y + BOARD_H * 0.50,
        )
        lane = lane_cycle[self.ufo_flight_index % len(lane_cycle)]
        left_to_right = self.ufo_flight_index % 2 == 0
        start_x = -UFO_DRAW_W
        end_x = SCREEN_W + UFO_DRAW_W
        if not left_to_right:
            start_x, end_x = end_x, start_x
        target_idx = self.choose_ufo_target()
        target_pos = centroid(self.pieces[target_idx]["points"]) if target_idx is not None else None
        self.active_ufo = {
            "start": [start_x, lane],
            "end": [end_x, lane],
            "started_at": now,
            "ends_at": now + UFO_FLIGHT_MS,
            "shot_at": now + int(UFO_FLIGHT_MS * 0.32),
            "hit_at": now + int(UFO_FLIGHT_MS * 0.68),
            "target_idx": target_idx,
            "target_pos": [target_pos[0], target_pos[1]] if target_pos is not None else None,
            "hit_done": False,
            "left_to_right": left_to_right,
        }
        self.ufo_flight_index += 1
        self.next_ufo_at = 0

    def remove_piece(self, piece_idx):
        if not (0 <= piece_idx < len(self.pieces)):
            return False
        del self.pieces[piece_idx]
        self.invalidate_wall_plane_geometry()
        new_open_walls = set()
        shared = self.shared_edges()
        for key in self.open_walls:
            if len(shared.get(key, [])) == 2:
                new_open_walls.add(key)
        self.open_walls = new_open_walls

        kept_zoids = []
        for zoid in self.zoids:
            old_piece = zoid.get("piece")
            if old_piece == piece_idx:
                continue
            if old_piece is not None and old_piece > piece_idx:
                zoid["piece"] = old_piece - 1
            if not self.pieces or self.piece_at(zoid.get("pos", (0, 0))) is None:
                continue
            if "visited" in zoid:
                zoid["visited"] = {
                    visited_idx - 1 if visited_idx > piece_idx else visited_idx
                    for visited_idx in zoid["visited"]
                    if visited_idx != piece_idx and visited_idx - (1 if visited_idx > piece_idx else 0) >= 0
                }
                if zoid.get("piece") is not None:
                    zoid["visited"].add(zoid["piece"])
            kept_zoids.append(zoid)
        self.zoids = kept_zoids
        return True

    def update_ufo(self, now=None):
        if self.mode != "playing":
            self.active_ufo = None
            return None
        now = self.now_ms() if now is None else int(now)
        self.explosions = [
            explosion for explosion in self.explosions
            if now - explosion.get("started_at", now) < explosion.get("duration", 0)
        ]
        if self.active_ufo is None and self.next_ufo_at and now >= self.next_ufo_at:
            if self.choose_ufo_target() is None:
                self.message = f"{self.current['name']} has no tiles left. Turn passes."
                self.advance_turn()
                return "turn_passed"
            self.start_ufo_flight(now)
        if self.active_ufo is None:
            return None
        event = self.active_ufo
        if not event.get("hit_done") and event.get("target_idx") is not None and now >= event.get("hit_at", now):
            event["hit_done"] = True
            target_idx = event["target_idx"]
            if (
                0 <= target_idx < len(self.pieces)
                and self.pieces[target_idx].get("owner") == self.current_color_index
            ):
                hit_pos = event.get("target_pos") or centroid(self.pieces[target_idx]["points"])
                if self.remove_piece(target_idx):
                    self.explosions.append({"pos": list(hit_pos), "started_at": now, "duration": 760})
                    self.message = f"UFO blasted one of {self.current['name']}'s tiles."
        if now >= event.get("ends_at", now):
            self.active_ufo = None
            self.next_ufo_at = now + UFO_REPEAT_DELAY_MS
        return event

    def choose_ai_move(self):
        hand = self.hands[self.current_player]

        line_indices = [idx for idx, card in enumerate(hand) if card_kind(card) == "line"]
        if line_indices:
            target = self.best_ai_line_target()
            if target is not None:
                return line_indices[0], target

        penta_indices = [idx for idx, card in enumerate(hand) if card_kind(card) == "pentagon"]
        for card_idx in penta_indices:
            target_piece = self.best_ai_piece_for_color(card_color(hand[card_idx]))
            if target_piece is not None:
                return card_idx, centroid(self.pieces[target_piece]["points"])

        zoid_indices = [idx for idx, card in enumerate(hand) if card_kind(card) == "zoid"]
        for card_idx in zoid_indices:
            target_piece = self.best_ai_piece_for_color(card_color(hand[card_idx]))
            if target_piece is not None:
                return card_idx, centroid(self.pieces[target_piece]["points"])

        shape_cards = [idx for idx, card in enumerate(hand) if card_kind(card) in SHAPE_SIDES]
        if shape_cards:
            if not self.pieces:
                return self.best_shape_card(shape_cards), BOARD_CENTER
            for card_idx in sorted(shape_cards, key=lambda idx: {"hex": 0, "square": 1, "triangle": 2}.get(card_kind(hand[idx]), 9)):
                target = self.best_ai_attach_point(card_kind(hand[card_idx]), card_color(hand[card_idx]))
                if target is not None:
                    return card_idx, target

        return None

    def best_ai_line_target(self):
        best = None
        current_color = self.current_color_index
        ball_pieces = {zoid.get("piece") for zoid in self.zoids if zoid.get("owner") == current_color}
        for key, entries in self.shared_edges().items():
            if len(entries) != 2 or key in self.open_walls:
                continue
            owners = [self.pieces[entry[0]].get("owner") for entry in entries]
            piece_ids = [entry[0] for entry in entries]
            _, _, a, b = entries[0]
            score = dist(midpoint(a, b), BOARD_CENTER) * 0.01
            if current_color in owners:
                score -= 80
            if any(piece_idx in ball_pieces for piece_idx in piece_ids):
                score -= 120
            if owners[0] != owners[1]:
                score -= 35
            if best is None or score < best[0]:
                best = (score, midpoint(a, b))
        return best[1] if best else None

    def best_ai_piece_for_color(self, color_index):
        for idx, piece in enumerate(self.pieces):
            if piece.get("owner") == color_index:
                return idx
        return None

    def best_shape_card(self, shape_cards):
        preferred = {"hex": 0, "square": 1, "triangle": 2}
        return sorted(shape_cards, key=lambda idx: preferred.get(card_kind(self.hands[self.current_player][idx]), 9))[0]

    def best_ai_attach_point(self, shape, color_index):
        exposed = self.exposed_edges()
        best = None
        for _, piece in enumerate(self.pieces):
            owner_bonus = -60 if piece.get("owner") == color_index else 0
            for a, b in side_list(piece["points"]):
                if edge_key(a, b) not in exposed:
                    continue
                target = midpoint(a, b)
                points = build_points_for_shape(shape, a, b, centroid(piece["points"]))
                if not self.shape_fits(points):
                    continue
                center_pull = dist(target, BOARD_CENTER) * 0.02
                score = owner_bonus + center_pull + random.random()
                if best is None or score < best[0]:
                    best = (score, target)
        return best[1] if best else None

    def maybe_ai_turn(self):
        if self.mode != "playing" or not self.current_is_ai():
            return None
        if not self.hands[self.current_player] or self.cards_used_this_turn >= 5:
            self.advance_turn()
            return "end_turn"
        move = self.choose_ai_move()
        if move is None:
            result = self.apply_player_command({"type": "discard", "card_index": 0}, actor=self.current_player, record=True)
        else:
            card_idx, target = move
            result = self.apply_player_command(
                {"type": "play_at", "card_index": card_idx, "pos": [float(target[0]), float(target[1])]},
                actor=self.current_player,
                record=True,
            )
            if not result.get("ok") and 0 <= card_idx < len(self.hands[self.current_player]):
                result = self.apply_player_command({"type": "discard", "card_index": card_idx}, actor=self.current_player, record=True)
        if self.mode == "playing" and (not self.hands[self.current_player] or self.cards_used_this_turn >= 5):
            self.advance_turn()
        return result

    def state_snapshot(self, viewer_player=None, live=False):
        self.ensure_zoid_ids()
        hands = []
        for idx, hand in enumerate(self.hands):
            if viewer_player is None or idx == viewer_player:
                hands.append([dict(card) for card in hand])
            else:
                hands.append({"count": len(hand)})
        action_log = [dict(entry) for entry in self.action_log]
        if live:
            action_log = action_log[-STREAM_ACTION_LOG_LIMIT:]
        return {
            "version": VERSION,
            "state_revision": self.state_revision,
            "next_zoid_id": self.next_zoid_id,
            "mode": self.mode,
            "player_count": self.player_count,
            "current_player": self.current_player,
            "players": [
                {
                    "name": player["name"],
                    "color_name": player["color_name"],
                    "color_index": player["color_index"],
                    "is_ai": idx in self.ai_players,
                    "score_total": self.total_scores[idx] if idx < len(self.total_scores) else 0,
                    "score_round": self.round_scores[idx] if idx < len(self.round_scores) else 0,
                }
                for idx, player in enumerate(self.players)
            ],
            "deck_count": len(self.deck),
            "discard": [dict(card) for card in self.discard],
            "hands": hands,
            "pieces": [
                {
                    "shape": piece["shape"],
                    "points": [[round(float(point[0]), 3), round(float(point[1]), 3)] for point in piece["points"]],
                    "owner": piece.get("owner"),
                    "played_by": piece.get("played_by"),
                }
                for piece in self.pieces
            ],
            "zoids": [
                {
                    "zoid_id": z["zoid_id"],
                    "kind": z.get("kind", "zoid"),
                    "owner": z.get("owner"),
                    "played_by": z.get("played_by"),
                    "piece": z.get("piece"),
                    "pos": [round(float(z.get("pos", [0, 0])[0]), 3), round(float(z.get("pos", [0, 0])[1]), 3)],
                    "vel": [round(float(z.get("vel", [0, 0])[0]), 3), round(float(z.get("vel", [0, 0])[1]), 3)],
                    "visited": sorted(z.get("visited", [])),
                }
                for z in self.zoids
            ],
            "open_walls": [
                [[float(point[0]), float(point[1])] for point in wall]
                for wall in sorted(self.open_walls)
            ],
            "round_slots": list(self.round_slots),
            "round_wild_kind": self.round_wild_kind,
            "last_score_breakdown": [dict(parts) for parts in self.last_score_breakdown],
            "next_ufo_at": self.next_ufo_at,
            "ufo_flight_index": self.ufo_flight_index,
            "active_ufo": dict(self.active_ufo) if self.active_ufo else None,
            "explosions": [dict(explosion) for explosion in self.explosions],
            "cards_used_this_turn": self.cards_used_this_turn,
            "last_card_drawn": self.last_card_drawn,
            "no_discard_turns_after_empty": self.no_discard_turns_after_empty,
            "action_log": action_log,
            "message": self.message,
        }
