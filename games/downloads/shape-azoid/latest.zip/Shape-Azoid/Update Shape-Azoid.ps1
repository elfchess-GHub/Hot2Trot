$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$currentBuildFile = Join-Path $root "BUILD_ID.txt"
$currentBuild = if (Test-Path $currentBuildFile) { (Get-Content $currentBuildFile -Raw).Trim() } else { "" }
$manifestUrl = "https://raw.githubusercontent.com/elfchess-GHub/Hot2Trot/main/games/downloads/shape-azoid/latest-release.json"
$tempRoot = Join-Path $env:TEMP ("ShapeAzoidUpdate_" + [Guid]::NewGuid().ToString("N"))
$zipPath = Join-Path $tempRoot "Shape-Azoid-update.zip"
function Read-PackageFiles([string]$manifestPath) {
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { return @() }
    try {
        $packageManifest = (Get-Content -LiteralPath $manifestPath -Raw) | ConvertFrom-Json
        return @($packageManifest.files | ForEach-Object { [string]$_ })
    } catch {
        return @()
    }
}
try {
    New-Item -ItemType Directory -Force -Path $tempRoot | Out-Null
    try {
        $manifestText = (Invoke-WebRequest -UseBasicParsing -Uri $manifestUrl -TimeoutSec 10).Content
        $manifest = $manifestText | ConvertFrom-Json
    } catch {
        Write-Host "Update check skipped: could not read the Shape-Azoid release manifest."
        exit 0
    }
    $latestBuild = [string]$manifest.build_id
    $downloadUrl = [string]$manifest.download_url
    $expectedSha256 = ([string]$manifest.sha256).ToLowerInvariant()
    if (-not $latestBuild) { throw "Release manifest did not contain a build ID." }
    if ($downloadUrl -notmatch '^https://github\.com/elfchess-GHub/Hot2Trot/releases/download/') {
        throw "Release manifest contained an unapproved download address."
    }
    if ($expectedSha256 -notmatch '^[0-9a-f]{64}$') { throw "Release manifest contained an invalid SHA-256." }
    if ($latestBuild -and $currentBuild -and $latestBuild -eq $currentBuild) {
        Write-Host "Shape-Azoid is already current ($currentBuild)."
        exit 0
    }
    $currentStamp = ""
    $latestStamp = ""
    if ($currentBuild -match "(\d{8}-\d{4})$") { $currentStamp = $Matches[1] }
    if ($latestBuild -match "(\d{8}-\d{4})$") { $latestStamp = $Matches[1] }
    if ($currentStamp -and $latestStamp -and $currentStamp -gt $latestStamp) {
        Write-Host "Update check skipped: local build $currentBuild is newer than published build $latestBuild."
        exit 0
    }
    Invoke-WebRequest -UseBasicParsing -Uri $downloadUrl -OutFile $zipPath -TimeoutSec 300
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    $zipStream = [System.IO.File]::OpenRead($zipPath)
    try {
        $actualSha256 = ([System.BitConverter]::ToString($sha256.ComputeHash($zipStream))).Replace("-", "").ToLowerInvariant()
    } finally {
        $zipStream.Dispose()
        $sha256.Dispose()
    }
    if ($actualSha256 -ne $expectedSha256) {
        throw "Downloaded package failed SHA-256 verification."
    }
    Expand-Archive -LiteralPath $zipPath -DestinationPath $tempRoot -Force
    $candidate = Get-ChildItem -Path $tempRoot -Recurse -Filter "Shape-Azoid.exe" | Select-Object -First 1
    if (-not $candidate) { throw "Downloaded package did not contain Shape-Azoid.exe." }
    $newRoot = Split-Path -Parent $candidate.FullName
    $newBuildFile = Join-Path $newRoot "BUILD_ID.txt"
    $newBuild = if (Test-Path $newBuildFile) { (Get-Content $newBuildFile -Raw).Trim() } else { "" }
    if ($latestBuild -and $newBuild -and $latestBuild -ne $newBuild) { throw "Downloaded build $newBuild did not match published build $latestBuild." }
    Write-Host "Updating Shape-Azoid from $currentBuild to $newBuild..."
    $oldFiles = @(Read-PackageFiles (Join-Path $root "PACKAGE_FILES.json"))
    $newFiles = @(Read-PackageFiles (Join-Path $newRoot "PACKAGE_FILES.json"))
    $rootPrefix = [System.IO.Path]::GetFullPath($root).TrimEnd('\') + '\'
    foreach ($relativePath in $oldFiles) {
        if ($newFiles -contains $relativePath) { continue }
        if ([System.IO.Path]::IsPathRooted($relativePath) -or $relativePath -match '(^|[\\/])\.\.([\\/]|$)') { continue }
        $obsoletePath = [System.IO.Path]::GetFullPath((Join-Path $root ($relativePath -replace '/', '\')))
        if ($obsoletePath.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase) -and (Test-Path -LiteralPath $obsoletePath -PathType Leaf)) {
            Remove-Item -LiteralPath $obsoletePath -Force
        }
    }
    $preserveExisting = @("Play Shape-Azoid.exe", "settings.json")
    Get-ChildItem -LiteralPath $newRoot -Force | Where-Object { $preserveExisting -notcontains $_.Name -or -not (Test-Path (Join-Path $root $_.Name)) } | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $root -Recurse -Force
    }
    foreach ($runtimeFile in @("Shape_Azoid_Network_Server.txt", "HOST_SERVER_ADDRESS.txt", "shape_azoid_online_server.log")) {
        $runtimePath = Join-Path $root $runtimeFile
        if (Test-Path $runtimePath) {
            Remove-Item -LiteralPath $runtimePath -Force -ErrorAction SilentlyContinue
        }
    }
    Write-Host "Shape-Azoid update complete."
} catch {
    Write-Host "Shape-Azoid update skipped: $($_.Exception.Message)"
} finally {
    if (Test-Path $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
