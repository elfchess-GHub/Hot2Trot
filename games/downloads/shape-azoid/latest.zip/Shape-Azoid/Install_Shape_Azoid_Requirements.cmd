@echo off
setlocal
cd /d "%~dp0"
set "SUPPORT_DIR=%~dp0Shape-Azoid Support"
if not exist "%SUPPORT_DIR%" set "SUPPORT_DIR=%~dp0"
cd /d "%SUPPORT_DIR%"
where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found on PATH.
  echo Install Python, then run this file again.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  python -m venv .venv
  if errorlevel 1 (
    echo Could not create .venv.
    pause
    exit /b 1
  )
)
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
echo.
echo Shape-Azoid requirements are installed.
echo You can now run Run_Shape_Azoid_Server.cmd or tools\Run_Network_Smoke_Test.cmd.
pause
